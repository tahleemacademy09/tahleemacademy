// src/lib/otaUpdate.ts
//
// Over-the-air updates for the Android app's WEB layer (no new APK needed).
//
//   publish-ota.mjs uploads  <BASE>/ota/manifest.json  +  <BASE>/ota/<version>.zip
//   app checks manifest → downloads zip in the background → shows a banner
//   user taps Update → bundle is swapped in and the app reloads (a few seconds)
//
// Native changes (Java/Kotlin, plugins, AndroidManifest, permissions) still
// need a new APK — set `minNativeBuild` in the manifest for those releases
// (publish script does this from versionCode) and the existing APK banner
// (AppUpdateBanner) takes over.

import { Capacitor } from "@capacitor/core";
import { App } from "@capacitor/app";
import { CapacitorUpdater } from "@capgo/capacitor-updater";
import { isReloadSafe, onReloadSafe } from "@/lib/reloadGuard";

const BASE = (import.meta.env.VITE_OTA_BASE_URL as string | undefined)?.replace(/\/$/, "");
// Version baked into the APK's built-in bundle (set VITE_OTA_VERSION when building the APK).
const BUILT_IN = (import.meta.env.VITE_OTA_VERSION as string | undefined) ?? "builtin";

interface Manifest {
  version: string;
  url: string;
  minNativeBuild?: number;
  notes?: string;
}

export interface OtaReady {
  bundleId: string;
  version: string;
  notes?: string;
}

let ready: OtaReady | null = null;
let busy = false;
let lastCheck = 0;

export const getOtaReady = () => ready;

async function currentVersion(): Promise<string> {
  const { bundle } = await CapacitorUpdater.current();
  return bundle.version === "builtin" ? BUILT_IN : bundle.version;
}

/** Checks the manifest and, if newer, downloads the bundle in the background. */
export async function checkForOta(force = false): Promise<void> {
  if (!Capacitor.isNativePlatform() || !BASE || busy || ready) return;
  if (!force && Date.now() - lastCheck < 10 * 60_000) return;
  lastCheck = Date.now();
  busy = true;
  try {
    const res = await fetch(`${BASE}/ota/manifest.json?t=${Date.now()}`, { cache: "no-store" });
    if (!res.ok) return;
    const m: Manifest = await res.json();

    const [cur, info] = await Promise.all([currentVersion(), App.getInfo()]);
    if (m.version === cur) return;
    if (m.minNativeBuild && parseInt(info.build, 10) < m.minNativeBuild) return; // needs a new APK

    const bundle = await CapacitorUpdater.download({ url: m.url, version: m.version });
    ready = { bundleId: bundle.id, version: m.version, notes: m.notes };
    window.dispatchEvent(new Event("ta:ota-ready"));
  } catch (e) {
    console.warn("[OTA] check failed", e);
  } finally {
    busy = false;
  }
}

/**
 * Swaps in the downloaded bundle and reloads. Never during a live class/exam:
 * if a reload lock is held, it waits and applies the moment it clears.
 * Returns true if applied now, false if it is waiting for a lock.
 */
export async function applyOta(): Promise<boolean> {
  if (!ready) return false;
  if (!isReloadSafe()) {
    const off = onReloadSafe(() => { off(); void applyOta(); });
    return false;
  }
  await CapacitorUpdater.set({ id: ready.bundleId });
  return true;
}

/** Call once at startup (main.tsx), right after initNativeApp(). */
export function initOta(): void {
  if (!Capacitor.isNativePlatform()) return;
  // MUST run on every launch: if it isn't called within ~10s of starting a new
  // bundle, the plugin assumes it's broken and rolls back to the previous one.
  CapacitorUpdater.notifyAppReady().catch(() => {});
  void checkForOta(true);
  App.addListener("appStateChange", ({ isActive }) => { if (isActive) void checkForOta(); });
}
