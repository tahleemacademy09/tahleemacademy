// src/pages/admin/HifdhHub.tsx
// -------------------------------------------------------------------------
// One tabbed page for everything Hifdh on the admin side:
//
//   o Hifdh Program        -- was /admin/hifdh-program
//   o Sessions & Grading   -- hold read-along, assign portions, mark, grade (all groups)
//   o Daily Tracker        -- was /admin/hifdh-tracker
//   o Recitation Review    -- was /admin/recitation-review
//   o Model Testing        -- NEW: test / compare / choose the transcription models (admin only)
//
// (Recitation Settings belongs to new-student registration, so it now lives
// in the Registration hub, not here.)
//
// The tabs render as one row of coloured icons. Each original route still
// exists in App.tsx and opens this hub on the matching tab.
// -------------------------------------------------------------------------
import { lazy, Suspense } from "react";
import { Loader2, BookOpen, ClipboardCheck, Mic, Video, FlaskConical } from "lucide-react";
import TabbedHub, { HubTab } from "@/components/admin/TabbedHub";
import { useLanguage } from "@/contexts/LanguageContext";

const G = "#064E3B";

const HifdhProgramAdmin = lazy(() => import("./HifdhProgramAdmin"));
const TeacherHifdhProgram = lazy(() => import("../teacher/TeacherHifdhProgram"));
const HifdhRevisionTracker = lazy(() => import("./HifdhRevisionTracker"));
const HifdhAdminReview = lazy(() => import("./HifdhAdminReview"));
const HifdhModelTest = lazy(() => import("./HifdhModelTest"));

const HubLoading = () => (
  <div className="flex items-center justify-center min-h-[40vh]">
    <Loader2 className="w-7 h-7 animate-spin" style={{ color: G }} />
  </div>
);

// Stable module-level wrappers (same reason as StudentsHub / RegistrationHub).
const ProgramTab = () => (
  <Suspense fallback={<HubLoading />}>
    <HifdhProgramAdmin />
  </Suspense>
);
const SessionsTab = () => (
  <Suspense fallback={<HubLoading />}>
    <TeacherHifdhProgram />
  </Suspense>
);
const TrackerTab = () => (
  <Suspense fallback={<HubLoading />}>
    <HifdhRevisionTracker />
  </Suspense>
);
const ReviewTab = () => (
  <Suspense fallback={<HubLoading />}>
    <HifdhAdminReview />
  </Suspense>
);

const ModelTestTab = () => (
  <Suspense fallback={<HubLoading />}>
    <HifdhModelTest />
  </Suspense>
);

export default function HifdhHub() {
  const { t } = useLanguage();

  const tabs: HubTab[] = [
    { key: "program", path: "/admin/hifdh-program", label: t("Hifdh Program", "برنامج الحفظ"), icon: BookOpen, color: "#059669", component: ProgramTab },
    { key: "sessions", path: "/admin/hifdh-sessions", label: t("Sessions & Grading", "الحصص والتقييم"), icon: Video, color: "#D97706", component: SessionsTab },
    { key: "tracker", path: "/admin/hifdh-tracker", label: t("Daily Tracker", "المتابعة اليومية"), icon: ClipboardCheck, color: "#2563EB", component: TrackerTab },
    { key: "review", path: "/admin/recitation-review", label: t("Recitation Review", "مراجعة التلاوة"), icon: Mic, color: "#7C3AED", component: ReviewTab },
    { key: "model-test", path: "/admin/hifdh-model-test", label: t("Model Testing", "اختبار النماذج"), icon: FlaskConical, color: "#DB2777", component: ModelTestTab },
  ];

  return (
    <TabbedHub
      title={t("Hifdh", "الحفظ")}
      tabs={tabs}
      iconOnly
    />
  );
}
