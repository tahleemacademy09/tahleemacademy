#!/bin/sh
# Run from the repo root after unzipping this archive over it:
#   unzip -o registration-update.zip && sh apply.sh && rm apply.sh
rm -f src/pages/admin/StudentRegistration.tsx src/pages/admin/SubjectRegistrationSettings.tsx
echo "Removed StudentRegistration.tsx and SubjectRegistrationSettings.tsx"
