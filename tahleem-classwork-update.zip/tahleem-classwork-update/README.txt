1. Run the SQL in supabase/migrations/20261118090000_assignment_kind_classwork.sql on Supabase FIRST
   (adds subject_assignments.kind = 'assignment' | 'classwork'; existing rows stay assignments).
2. Copy the files in src/ over your project (same paths), then build/deploy.
   changes.patch is the same change as a diff, for review.
