#!/usr/bin/env bash
# Run from the project root:  bash APPLY.sh   (after unzipping this into the project root)
set -e
rm -f src/lib/HifdhDailyRevisionPage.tsx src/lib/RecitationResultGrid.tsx src/lib/recitationAlign.ts
echo "Done. Now: npm run build"
