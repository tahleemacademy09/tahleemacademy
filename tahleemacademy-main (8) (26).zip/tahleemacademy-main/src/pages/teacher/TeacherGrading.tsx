// src/pages/teacher/TeacherGrading.tsx
// Teacher exam grading page — mirrors admin GradingPage, filtered to teacher's subjects

import { useEffect, useState, useRef } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { useStaffTermId, useStaffTermKey } from "@/hooks/useCurrentTermId";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { sanitizeHtml } from "@/lib/sanitize";
import AdminAudioPlayer from "@/components/exam/AdminAudioPlayer";
import {
  CheckCircle, XCircle, Search, FileText, Download,
  Send, Unlock, Loader2, Eye, BarChart2, AlertTriangle,
  ArrowRight, RefreshCw, ClipboardList, Users, ChevronLeft, Bell, RotateCcw,
} from "lucide-react";

const G    = "#064E3B";
const GM   = "#075E54";
const GOLD = "#C9A84C";

type GradingTab = "pending" | "graded" | "released";

const TeacherGrading = () => {
  const { t, language } = useLanguage();
  const { toast }       = useToast();
  const { user }        = useAuth();
  const staffTermId = useStaffTermId(); // the term this teacher is working in
  const staffTermKey = useStaffTermKey(); // "first" | "second" | "third"

  const [allAttempts,    setAllAttempts]    = useState<any[]>([]);
  const [selectedAttempt,setSelectedAttempt]= useState<any>(null);
  const [answers,        setAnswers]        = useState<any[]>([]);
  const [questions,      setQuestions]      = useState<any[]>([]);
  const [scores,         setScores]         = useState<Record<string, string>>({});
  const [feedbacks,      setFeedbacks]      = useState<Record<string, string>>({});
  const [examFeedback,   setExamFeedback]   = useState("");
  const [submitting,     setSubmitting]     = useState(false);
  const [examIds,        setExamIds]        = useState<string[]>([]);
  const [gradingTab,     setGradingTab]     = useState<GradingTab>("pending");
  const [search,         setSearch]         = useState("");
  const [typeFilter,     setTypeFilter]     = useState<"all"|"exam"|"test">("all");
  const [loading,        setLoading]        = useState(true);
  const [examsList,      setExamsList]      = useState<any[]>([]);
  const [resetting,      setResetting]      = useState<string | null>(null);

  const tabCounts = {
    pending:  allAttempts.filter(a => a.status === "submitted").length,
    graded:   allAttempts.filter(a => a.status === "graded").length,
    released: allAttempts.filter(a => a.status === "released").length,
  };

  // ── Load teacher's exam IDs ────────────────────────────────────
  useEffect(() => {
    if (!user || !staffTermId) return;
    const load = async () => {
      // A subject counts as "theirs" whether they own it directly
      // (subjects.teacher_id) or the admin assigned them to it via the
      // timetable (subject_timetable.teacher_id) — grading shouldn't care
      // who set up the exam's questions, only whose subject it's on.
      const { data: subs } = await supabase.from("subjects").select("id").eq("teacher_id", user.id);
      // subject_timetable stores co-teachers in `teacher_ids[]`; the legacy
      // singular `teacher_id` column only ever holds the FIRST teacher an
      // admin picked (see TimetableManagement.tsx), so a second/co-teacher
      // must be matched via the array too — otherwise their subjects (and
      // every exam/attempt under them) are invisible on this page.
      const { data: ttSlots } = await supabase.from("subject_timetable" as any).select("subject_id, teacher_id, teacher_ids").eq("term_id", staffTermId!);
      const myTtSlots = (ttSlots || []).filter((s: any) =>
        s.teacher_id === user.id || (Array.isArray(s.teacher_ids) && s.teacher_ids.includes(user.id))
      );
      const subjectIds = [...new Set([
        ...((subs || []).map((s: any) => s.id)),
        ...(myTtSlots.map((s: any) => s.subject_id).filter(Boolean)),
      ])];
      // Exams are attached via exams.subject_id (set by ExamEditor), not the
      // legacy course_id column which the editor never populates.
      // Some oral exams (e.g. Musabaqah-style ones) are created with no
      // subject_id at all, so they can never match the subjectIds filter for
      // ANY teacher — pull those in separately for whoever created/graded
      // them (exams.created_by), same fallback as TeacherResults/TeacherOralExams.
      const examQueries = [];
      if (subjectIds.length > 0) {
        examQueries.push(supabase.from("exams").select("id, title, title_ar, session").in("subject_id", subjectIds));
      }
      examQueries.push(supabase.from("exams").select("id, title, title_ar, session").is("subject_id", null).eq("created_by", user.id));
      const examResults = await Promise.all(examQueries);
      const exams = [...new Map(examResults.flatMap(r => r.data || []).map((e: any) => [e.id, e])).values()];
      const ids = exams.map((e: any) => e.id);
      setExamIds(ids);
      setExamsList(exams);
      setLoading(false);
    };
    load();
  }, [user]);

  useEffect(() => {
    if (examIds.length > 0) loadAttempts();
  }, [examIds]);

  const loadAttempts = async () => {
    if (!examIds.length) return;
    // NOTE: exam_attempts has no foreign key directly to `profiles` (both
    // exam_attempts.user_id and profiles.user_id point separately at
    // auth.users), so `profiles!exam_attempts_user_id_fkey(...)` is not a
    // resolvable embed — PostgREST rejects it and the whole query used to
    // fail silently (data ended up undefined, tab always showed "0 pending"
    // even for attempts that were correctly scoped to this teacher's
    // subjects). Fetch attempts and profiles separately and merge in JS,
    // same approach the admin GradingPage already uses.
    const { data: attempts, error: attemptsErr } = await supabase.from("exam_attempts")
      .select(`*,
        exams(id, title, title_ar, type, passing_score, allow_review, term,
              subject_id, subjects(title))`)
      .in("exam_id", examIds)
      .in("status", ["submitted", "graded", "released"])
      .order("submitted_at", { ascending: false });

    if (attemptsErr) {
      console.error("loadAttempts: exam_attempts fetch failed", attemptsErr);
      toast({ title: "Error loading attempts", description: attemptsErr.message, variant: "destructive" });
      setAllAttempts([]);
      return;
    }

    const userIds = [...new Set((attempts || []).map((a: any) => a.user_id).filter(Boolean))];
    let profilesById: Record<string, any> = {};
    if (userIds.length) {
      const { data: profiles, error: profilesErr } = await supabase
        .from("profiles")
        .select("user_id, full_name, email, student_id")
        .in("user_id", userIds);
      if (profilesErr) {
        console.error("loadAttempts: profiles fetch failed", profilesErr);
      } else {
        profilesById = Object.fromEntries((profiles || []).map((p: any) => [p.user_id, p]));
      }
    }

    const merged = (attempts || []).map((a: any) => ({
      ...a,
      profiles: profilesById[a.user_id] || {},
    }));
    setAllAttempts(merged);
  };

  const openAttempt = async (attempt: any) => {
    setSelectedAttempt(attempt);
    setExamFeedback(attempt.feedback || "");
    // Use the same pooled subset the student was actually shown (respects
    // "section::pick=N" question-pool tags) instead of just whichever
    // questions happen to have an exam_answers row — otherwise a SKIPPED
    // pool question has no answer row, so it silently disappeared from
    // this screen entirely: no player, no score, and it didn't even count
    // against the max points, which unfairly inflated the percentage.
    // Same fix as the admin GradingPage.tsx.
    const [qRes, aRes] = await Promise.all([
      supabase.rpc("get_exam_questions_for_attempt", { _attempt_id: attempt.id }),
      supabase.from("exam_answers").select("*").eq("attempt_id", attempt.id),
    ]);
    let qs = qRes.data || [];
    if (qRes.error) {
      console.error("openAttempt: get_exam_questions_for_attempt failed, falling back to full bank:", qRes.error);
      const { data: fallbackQs } = await supabase.from("exam_questions").select("*").eq("exam_id", attempt.exam_id).order("sort_order");
      qs = fallbackQs || [];
    } else {
      qs = [...qs].sort((a: any, b: any) => (a.sort_order ?? 0) - (b.sort_order ?? 0));
    }
    const data = aRes.data || [];
    // The audioUrl saved in answer_data is a signed URL that was only ever
    // valid for 7 days from submission (see ExamTaking.tsx) — grading that
    // happens after that window sees "Audio file unavailable" for a
    // recording that's actually still sitting fine in Storage. Re-sign it
    // here from answer_data.storagePath so the player works regardless of
    // how long ago the student submitted. (Recordings that never made it to
    // Storage in the first place — no storagePath — have nothing to re-sign;
    // those are genuinely gone.)
    await Promise.all(data.map(async (a: any) => {
      const path = a.answer_data?.storagePath;
      if (!path) return;
      const { data: signed } = await supabase.storage.from("exam-media").createSignedUrl(path, 3600);
      if (signed?.signedUrl) a.answer_data = { ...a.answer_data, audioUrl: signed.signedUrl };
    }));
    setQuestions(qs);
    setAnswers(data);
    const sc: Record<string, string> = {};
    const fb: Record<string, string> = {};
    qs.forEach((q: any) => {
      const a = data.find((x: any) => x.question_id === q.id);
      sc[q.id] = String(a?.points_awarded ?? "");
      fb[q.id] = a?.feedback || "";
    });
    setScores(sc);
    setFeedbacks(fb);
  };

  const submitGrade = async () => {
    if (!selectedAttempt) return;
    setSubmitting(true);
    try {
      let totalEarned = 0, totalPossible = 0;
      for (const q of questions) {
        const ans = answers.find(a => a.question_id === q.id);
        const pts = parseFloat(scores[q.id] ?? "0") || 0;
        const maxPts = q.points || 1;
        totalEarned += pts;
        totalPossible += maxPts;
        if (ans?.id) {
          await supabase.from("exam_answers").update({
            points_awarded: pts,
            feedback: feedbacks[q.id] || null,
            is_correct: pts >= maxPts,
            graded_by: user?.id,
            graded_at: new Date().toISOString(),
          }).eq("id", ans.id);
        } else {
          // Skipped pool question — no exam_answers row exists yet. A
          // direct insert is blocked by RLS (exam_answers only allows
          // UPDATE of an existing row), so create/set it via the same
          // SECURITY DEFINER RPC the admin grading page uses.
          const { error: upsertErr } = await supabase.rpc("admin_upsert_exam_answer" as any, {
            _attempt_id: selectedAttempt.id, _question_id: q.id,
            _points: pts, _is_correct: pts >= maxPts,
          });
          if (upsertErr) console.error("submitGrade: upsert failed for skipped question", q.id, upsertErr);
        }
      }
      const pct = totalPossible > 0 ? (totalEarned / totalPossible) * 100 : 0;
      // Continuous-assessment convention: a "test" is always scored out of 30
      // and a full "exam" out of 70, regardless of how many raw points the
      // questions add up to — scale the earned total proportionally. Any
      // other exam type (e.g. entrance) isn't part of that CA scheme and
      // keeps its raw point total unscaled.
      const examType    = selectedAttempt.exams?.type;
      const scaledTotal = examType === "test" ? 30 : examType === "exam" ? 70 : totalPossible;
      const scaledEarned = totalPossible > 0 ? Number(((totalEarned / totalPossible) * scaledTotal).toFixed(2)) : 0;
      const passing = selectedAttempt.exams?.passing_score || 50;
      // Releasing is admin-only — a teacher's grading always lands as
      // "graded" and waits for an admin to release it to the student.
      // (Released attempts aren't editable here — see the read-only guard
      // in the detail view.)
      await supabase.from("exam_attempts").update({
        status: "graded",
        score: scaledEarned,
        total_points: scaledTotal,
        percentage: pct,
        passed: pct >= passing,
        feedback: examFeedback || null,
        graded_by: user?.id,
        graded_by_role: "teacher",
      }).eq("id", selectedAttempt.id);
      toast({ title: t("✅ Graded successfully", "✅ تم التصحيح بنجاح") });
      setSelectedAttempt(null);
      loadAttempts();
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
    setSubmitting(false);
  };

  // Releasing results to students is admin-only (see GradingPage.tsx). A
  // teacher's job stops at grading — the attempt then sits in "Graded"
  // waiting for an admin to release it.

  // ── Reset an attempt so the student can retake the exam ────────────────
  // Mirrors the admin GradingPage.resetAttempt. RLS ("Teachers can reset
  // attempts for their subjects") already restricts this to attempts on
  // exams whose subject this teacher teaches, excludes 'released' attempts,
  // and respects the private-student assignment check — so no extra
  // client-side scoping is needed beyond what loadAttempts already fetches.
  const resetAttempt = async (attempt: any) => {
    const name = attempt.profiles?.full_name || t("this student", "هذا الطالب");
    if (!confirm(
      t(
        `Reset ${name}'s attempt for "${attempt.exams?.title || "this exam"}"? Their score and answers will be permanently deleted and they'll be able to retake it.`,
        `إعادة تعيين محاولة ${name} في "${attempt.exams?.title_ar || attempt.exams?.title || "هذا الامتحان"}"؟ سيتم حذف درجتهم وإجاباتهم نهائيًا وسيتمكنون من إعادة المحاولة.`
      )
    )) return;
    setResetting(attempt.id);
    try {
      const { error } = await supabase.from("exam_attempts").delete().eq("id", attempt.id);
      if (error) throw new Error(error.message);
      toast({ title: t(`✅ Attempt reset — ${name} can retake the exam`, `✅ تمت إعادة التعيين — يمكن لـ ${name} إعادة المحاولة`) });
      if (selectedAttempt?.id === attempt.id) setSelectedAttempt(null);
      loadAttempts();
    } catch (e: any) {
      toast({ title: t("Reset failed", "فشلت إعادة التعيين"), description: e.message, variant: "destructive" });
    } finally {
      setResetting(null);
    }
  };

  const filtered = allAttempts.filter(a => {
    if (gradingTab === "pending"  && a.status !== "submitted") return false;
    if (gradingTab === "graded"   && a.status !== "graded") return false;
    if (gradingTab === "released" && a.status !== "released") return false;
    if (typeFilter !== "all" && (a.exams?.type || "exam") !== typeFilter) return false;
    if (search && !(a.profiles?.full_name || "").toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const inp: React.CSSProperties = {
    width: "100%", padding: "8px 12px", borderRadius: 10,
    border: "1.5px solid #E5E7EB", fontSize: 13, outline: "none",
    background: "#FAFAFA", boxSizing: "border-box" as const,
  };

  // ── Loading ───────────────────────────────────────────────────
  if (loading) return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: 400 }}>
      <Loader2 size={32} style={{ animation: "spin .8s linear infinite", color: GOLD }} />
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  // ── Attempt detail view ───────────────────────────────────────
  if (selectedAttempt) {
    // Released results are admin's territory from here on — a teacher can
    // still open one to review it, but the form is read-only so they can't
    // accidentally flip it back to "graded" and hide it from the student.
    const isAlreadyGraded = selectedAttempt.status === "graded" || selectedAttempt.status === "released";
    const isReleased = selectedAttempt.status === "released";
    const totalPossible = questions.reduce((s, q) => s + (q.points || 1), 0);
    const totalEntered  = questions.reduce((s, q) => s + (parseFloat(scores[q.id] || "0") || 0), 0);
    // The live preview shown while grading should track what submitGrade
    // actually saves — a "test" always scores out of 30 and a full "exam"
    // out of 70 (the CA convention), regardless of how many raw points the
    // pooled questions happen to sum to. Showing the raw sum here (e.g.
    // /25) while the saved score is scaled to /30 made the on-screen total
    // look wrong even though the underlying math was correct.
    const examTypeForScale = selectedAttempt.exams?.type;
    const scaledTotalPreview  = examTypeForScale === "test" ? 30 : examTypeForScale === "exam" ? 70 : totalPossible;
    const scaledEarnedPreview = totalPossible > 0 ? Number(((totalEntered / totalPossible) * scaledTotalPreview).toFixed(2)) : 0;

    return (
      <div style={{ minHeight: "100vh", background: "#F3F4F6", fontFamily: "system-ui, sans-serif" }}>
        <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>

        {/* Header */}
        <div style={{ background: "#fff", borderBottom: "1px solid #E5E7EB", padding: "14px 20px", display: "flex", alignItems: "center", gap: 12, position: "sticky", top: 0, zIndex: 10 }}>
          <button onClick={() => setSelectedAttempt(null)} style={{ width: 34, height: 34, borderRadius: 10, border: "1.5px solid #E5E7EB", background: "#fff", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <ChevronLeft size={16} color="#6B7280" />
          </button>
          <div style={{ flex: 1 }}>
            <h2 style={{ fontSize: 15, fontWeight: 800, color: G, margin: 0 }}>
              {selectedAttempt.profiles?.full_name} — {selectedAttempt.exams?.title}
            </h2>
            <p style={{ fontSize: 11, color: "#9CA3AF", margin: "2px 0 0" }}>
              {selectedAttempt.exams?.type === "test" ? t("Test", "تمرين") : t("Exam", "امتحان")} •{" "}
              {selectedAttempt.submitted_at ? new Date(selectedAttempt.submitted_at).toLocaleString() : "—"}
            </p>
          </div>
          {!isAlreadyGraded && (
            <div style={{ fontSize: 13, fontWeight: 700, color: G }}>
              {scaledEarnedPreview} / {scaledTotalPreview}
            </div>
          )}
        </div>

        <div style={{ maxWidth: 760, margin: "0 auto", padding: "20px" }}>
          {/* Already graded banner */}
          {isAlreadyGraded && (
            <div style={{
              padding: "12px 16px", borderRadius: 12, marginBottom: 16,
              background: isReleased ? "#EFF6FF" : "#F0FDF4",
              border: `1px solid ${isReleased ? "#BFDBFE" : "#BBF7D0"}`,
              display: "flex", alignItems: "center", gap: 10,
            }}>
              <CheckCircle size={16} color={isReleased ? "#2563EB" : "#16A34A"} />
              <span style={{ fontSize: 13, color: isReleased ? "#2563EB" : "#16A34A", fontWeight: 700 }}>
                {isReleased
                  ? t("Released to student — view only", "تم إرسالها للطالب — للعرض فقط")
                  : t("Already graded", "تم التصحيح مسبقاً")} • {Math.round(selectedAttempt.percentage || 0)}% •{" "}
                {selectedAttempt.passed ? t("Passed", "ناجح") : t("Failed", "راسب")}
              </span>
            </div>
          )}

          {/* Questions */}
          {questions.map((q, i) => {
            const ans = answers.find(a => a.question_id === q.id);
            const isMCQ      = q.question_type === "mcq" || q.question_type === "image_mcq";
            const isTF       = q.question_type === "true_false";
            const isSubjective = ["short_answer", "essay", "audio", "dictation"].includes(q.question_type);
            const opts = Array.isArray(q.options) ? q.options : (typeof q.options === "string" ? JSON.parse(q.options) : []);
            const correct = isMCQ ? opts.find((o: any) => o.is_correct)?.text : q.correct_answer;
            const studentAns = ans?.answer_text || "";
            // The recorded clip's real URL lives in answer_data.audioUrl
            // (or the legacy audio_url column) — answer_text for an audio
            // question only ever holds a "[audio_recorded]" placeholder,
            // never a playable URL. Same fix as admin GradingPage.tsx.
            const audioSrc = (ans as any)?.answer_data?.audioUrl || (ans as any)?.audio_url || null;
            const notAnswered = !studentAns && !audioSrc;

            return (
              <div key={q.id} style={{ background: "#fff", borderRadius: 16, border: `1px solid ${notAnswered ? "#FDE68A" : "#E5E7EB"}`, padding: 20, marginBottom: 14, boxShadow: "0 1px 4px rgba(0,0,0,.04)" }}>
                {/* Q header */}
                <div style={{ display: "flex", alignItems: "flex-start", gap: 12, marginBottom: 14 }}>
                  <div style={{ width: 28, height: 28, borderRadius: 8, background: G, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 900, color: "#fff", flexShrink: 0 }}>{i + 1}</div>
                  <div style={{ flex: 1 }}>
                    {(q.reading_passage || q.reading_passage_ar) && (
                      <div style={{ marginBottom: 8, padding: "10px 12px", borderRadius: 10, background: "#FFFBEB", border: "1px solid #FDE68A", borderLeft: "4px solid #C9A84C" }}>
                        <div style={{ fontSize: 10, fontWeight: 700, color: "#C9A84C", letterSpacing: 1, marginBottom: 4 }}>📖 {t("READING PASSAGE", "نص القراءة")}</div>
                        {q.reading_passage && (
                          <div dir="auto" style={{ fontSize: 13, lineHeight: 1.8, fontFamily: "'Amiri',serif" }} dangerouslySetInnerHTML={{ __html: sanitizeHtml(q.reading_passage) }} />
                        )}
                        {q.reading_passage_ar && (
                          <div dir="rtl" style={{ fontSize: 13, lineHeight: 1.8, fontFamily: "'Amiri',serif", marginTop: q.reading_passage ? 6 : 0 }} dangerouslySetInnerHTML={{ __html: sanitizeHtml(q.reading_passage_ar) }} />
                        )}
                      </div>
                    )}
                    {(q.instruction_text || q.instruction_text_ar) && (
                      <div style={{ fontSize: 11, color: "#9CA3AF", fontStyle: "italic", marginBottom: 4 }}>
                        {language === "ar" && q.instruction_text_ar ? q.instruction_text_ar : q.instruction_text}
                      </div>
                    )}
                    <div
                      style={{ fontSize: 14, color: G, lineHeight: 1.6, fontWeight: 500 }}
                      dangerouslySetInnerHTML={{ __html: sanitizeHtml(language === "ar" && q.question_text_ar ? q.question_text_ar : q.question_text) }}
                    />
                    <div style={{ fontSize: 11, color: "#9CA3AF", marginTop: 4 }}>
                      {q.question_type} • {q.points || 1} {t("pts", "نقطة")}
                    </div>
                  </div>
                </div>

                {/* Media */}
                {q.media_url && <AdminAudioPlayer src={q.media_url} />}

                {/* MCQ options */}
                {isMCQ && opts.length > 0 && (
                  <div style={{ marginBottom: 12, display: "flex", flexDirection: "column", gap: 6 }}>
                    {opts.map((o: any) => {
                      const isStudentChoice = o.id === studentAns || o.text === studentAns;
                      const isCorrectOpt    = o.is_correct;
                      return (
                        <div key={o.id} style={{
                          padding: "8px 12px", borderRadius: 10, fontSize: 13,
                          background: isCorrectOpt ? "#F0FDF4" : isStudentChoice && !isCorrectOpt ? "#FEF2F2" : "#F9FAFB",
                          border: `1px solid ${isCorrectOpt ? "#86EFAC" : isStudentChoice && !isCorrectOpt ? "#FECACA" : "#E5E7EB"}`,
                          display: "flex", alignItems: "center", gap: 8,
                          color: isCorrectOpt ? "#16A34A" : isStudentChoice && !isCorrectOpt ? "#DC2626" : "#374151",
                        }}>
                          {isCorrectOpt ? <CheckCircle size={13} color="#16A34A" /> : isStudentChoice && !isCorrectOpt ? <XCircle size={13} color="#DC2626" /> : <div style={{ width: 13 }} />}
                          {language === "ar" && o.text_ar ? o.text_ar : o.text}
                          {isStudentChoice && <span style={{ marginLeft: "auto", fontSize: 10, fontWeight: 700 }}>{t("Student's answer", "إجابة الطالب")}</span>}
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Text / audio answer */}
                {!isMCQ && (
                  <div style={{ padding: "10px 14px", borderRadius: 10, background: "#F9FAFB", border: "1px solid #E5E7EB", marginBottom: 12 }}>
                    <p style={{ fontSize: 11, fontWeight: 700, color: "#9CA3AF", margin: "0 0 4px" }}>{t("Student's Answer", "إجابة الطالب")}:</p>
                    {notAnswered && (
                      <div style={{ padding: "6px 10px", background: "#FFF7ED", borderRadius: 8, border: "1px solid #FDE68A", fontSize: 11, color: "#92400E", fontWeight: 700 }}>
                        ⚠️ {t("Not answered — skipped", "لم تتم الإجابة — تم التخطي")}
                      </div>
                    )}
                    {q.question_type === "audio" && audioSrc ? (
                      <AdminAudioPlayer src={audioSrc} />
                    ) : !notAnswered ? (
                      <p style={{ fontSize: 13, color: G, margin: 0, lineHeight: 1.6 }}>{studentAns}</p>
                    ) : null}
                  </div>
                )}

                {/* Correct answer for TF/fill */}
                {(isTF || q.question_type === "fill_blank") && correct && (
                  <div style={{ padding: "8px 12px", borderRadius: 10, background: "#F0FDF4", border: "1px solid #86EFAC", marginBottom: 12, fontSize: 12, color: "#16A34A" }}>
                    {t("Correct answer", "الإجابة الصحيحة")}: <strong>{correct}</strong>
                  </div>
                )}

                {/* Auto-grade note for MCQ/true-false, so it's clear what the
                    score below is overriding rather than setting from scratch. */}
                {!isSubjective && !isAlreadyGraded && (isMCQ || isTF) && (
                  <div style={{ marginBottom: 8, display: "flex", alignItems: "center", gap: 6 }}>
                    {ans?.is_correct
                      ? <span style={{ fontSize: 12, color: "#16A34A", fontWeight: 700, display: "flex", alignItems: "center", gap: 4 }}><CheckCircle size={13} /> {t("Auto-graded: Correct", "تصحيح تلقائي: صحيح")}</span>
                      : <span style={{ fontSize: 12, color: "#DC2626", fontWeight: 700, display: "flex", alignItems: "center", gap: 4 }}><XCircle size={13} /> {t("Auto-graded: Incorrect", "تصحيح تلقائي: خطأ")}</span>}
                  </div>
                )}

                {/* Grading — every question type, not just subjective ones,
                    so a teacher can overwrite a wrongly auto-graded MCQ or
                    true/false answer too, not only score essays/audio.
                    Quick-select buttons mirror the admin grading screen so
                    scoring is a tap instead of typing a number by hand. */}
                {!isAlreadyGraded && (
                  <div style={{ marginTop: 4, background: "#F0FDF4", borderRadius: 12, padding: "14px 16px", border: "1.5px solid #BBDDC8" }}>
                    <p style={{ fontSize: 12, fontWeight: 800, color: G, margin: "0 0 10px" }}>
                      ✏️ {isSubjective ? t("Grade this answer", "صحّح هذه الإجابة") : t("Override score", "تعديل الدرجة")}{" "}
                      <span style={{ fontSize: 11, fontWeight: 600, color: "#6B7280" }}>({q.points || 1} {t("pts max", "نقطة كحد أقصى")})</span>
                    </p>
                    {(q.points || 1) <= 10 && (
                      <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap", marginBottom: 10 }}>
                        {Array.from({ length: (q.points || 1) + 1 }, (_, n) => (
                          <button key={n} onClick={() => setScores(s => ({ ...s, [q.id]: String(n) }))} style={{
                            width: 40, height: 40, borderRadius: 10,
                            border: `2px solid ${Number(scores[q.id]) === n ? G : "#D1D5DB"}`,
                            background: Number(scores[q.id]) === n ? G : "#fff",
                            cursor: "pointer", fontSize: 14, fontWeight: 800,
                            color: Number(scores[q.id]) === n ? "#fff" : "#374151",
                          }}>{n}</button>
                        ))}
                        <span style={{ fontSize: 12, color: "#9CA3AF", marginLeft: 4 }}>/ {q.points || 1}</span>
                      </div>
                    )}
                    <div style={{ display: "flex", alignItems: "center", gap: 10, background: "#fff", borderRadius: 10, padding: "10px 12px", border: "1.5px solid #BBDDC8", marginBottom: 10 }}>
                      <span style={{ fontSize: 12, color: "#6B7280", fontWeight: 700, whiteSpace: "nowrap" as const }}>{t("Score", "الدرجة")}:</span>
                      <input
                        type="number" min={0} max={q.points || 1} step={0.5}
                        value={scores[q.id] ?? ""}
                        onChange={e => setScores(s => ({ ...s, [q.id]: e.target.value }))}
                        style={{ width: 72, padding: "6px 10px", borderRadius: 8, border: "1.5px solid #D1D5DB", fontSize: 16, fontWeight: 800, color: G, textAlign: "center" as const, outline: "none" }}
                      />
                      <span style={{ fontSize: 13, color: "#6B7280" }}>/ {q.points || 1} pts</span>
                    </div>
                    <div>
                      <label style={{ fontSize: 11, fontWeight: 700, color: "#374151", display: "block", marginBottom: 4 }}>
                        {t("Feedback", "ملاحظة")}
                      </label>
                      <input
                        value={feedbacks[q.id] ?? ""}
                        onChange={e => setFeedbacks(f => ({ ...f, [q.id]: e.target.value }))}
                        placeholder={t("Optional feedback…", "ملاحظة اختيارية…")}
                        style={inp}
                      />
                    </div>
                  </div>
                )}

                {/* Already graded score */}
                {isAlreadyGraded && (
                  <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, fontWeight: 700 }}>
                    {ans?.is_correct ? <CheckCircle size={14} color="#16A34A" /> : <XCircle size={14} color="#DC2626" />}
                    <span style={{ color: G }}>{ans?.points_awarded ?? 0} / {q.points || 1} {t("pts", "نقطة")}</span>
                    {ans?.feedback && <span style={{ fontSize: 12, color: "#9CA3AF", fontWeight: 400 }}>— {ans.feedback}</span>}
                  </div>
                )}
              </div>
            );
          })}

          {/* Overall feedback & submit */}
          {!isAlreadyGraded && (
            <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #E5E7EB", padding: 20, marginTop: 4 }}>
              <label style={{ fontSize: 13, fontWeight: 700, color: G, display: "block", marginBottom: 8 }}>
                {t("Overall Feedback (Optional)", "ملاحظة عامة (اختياري)")}
              </label>
              <textarea
                value={examFeedback} rows={3}
                onChange={e => setExamFeedback(e.target.value)}
                placeholder={t("Write feedback for the student…", "اكتب ملاحظتك للطالب…")}
                style={{ ...inp, resize: "vertical" as const }}
              />
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 16 }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: G }}>
                  {t("Total", "المجموع")}: {scaledEarnedPreview} / {scaledTotalPreview}
                  {" "}({totalPossible > 0 ? Math.round((totalEntered / totalPossible) * 100) : 0}%)
                </div>
                <button
                  onClick={submitGrade} disabled={submitting}
                  style={{
                    padding: "11px 24px", borderRadius: 12, border: "none",
                    background: submitting ? "#E5E7EB" : `linear-gradient(135deg, ${G}, ${GM})`,
                    color: submitting ? "#9CA3AF" : "#fff",
                    fontSize: 14, fontWeight: 800, cursor: submitting ? "not-allowed" : "pointer",
                    display: "flex", alignItems: "center", gap: 8,
                  }}
                >
                  {submitting ? <Loader2 size={14} style={{ animation: "spin .8s linear infinite" }} /> : <Send size={14} />}
                  {submitting ? t("Saving…", "جاري الحفظ…") : t("Submit Grade", "إرسال الدرجة")}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ── Attempt list ──────────────────────────────────────────────
  return (
    <div style={{ minHeight: "100vh", background: "#F3F4F6", fontFamily: "system-ui, sans-serif" }}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>

      {/* Header */}
      <div style={{ background: "#fff", borderBottom: "1px solid #E5E7EB", padding: "16px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
          <div>
            <h1 style={{ fontSize: 22, fontWeight: 900, color: G, margin: 0 }}>{t("Grading", "التصحيح")}</h1>
            <p style={{ fontSize: 13, color: "#9CA3AF", margin: "2px 0 0" }}>
              {tabCounts.pending} {t("pending", "بانتظار التصحيح")}
            </p>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
            {/* Type filter */}
            {(["all", "exam", "test"] as const).map(tp => (
              <button key={tp} onClick={() => setTypeFilter(tp)} style={{
                padding: "6px 14px", borderRadius: 20, fontSize: 12, fontWeight: 700,
                border: `1.5px solid ${typeFilter === tp ? G : "#E5E7EB"}`,
                background: typeFilter === tp ? G : "#fff",
                color: typeFilter === tp ? "#fff" : "#6B7280",
                cursor: "pointer",
              }}>
                {tp === "all" ? t("All", "الكل") : tp === "exam" ? t("Exams", "امتحانات") : t("Tests", "تمرينات")}
              </button>
            ))}
            {/* Search */}
            <div style={{ position: "relative" }}>
              <Search size={13} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "#9CA3AF" }} />
              <input
                value={search} onChange={e => setSearch(e.target.value)}
                placeholder={t("Search student…", "ابحث بالاسم…")}
                style={{ ...inp, paddingLeft: 30, width: 180 }}
              />
            </div>
            <button onClick={loadAttempts} style={{ width: 36, height: 36, borderRadius: 10, border: "1.5px solid #E5E7EB", background: "#fff", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <RefreshCw size={14} color="#6B7280" />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 0, marginTop: 12 }}>
          {(["pending", "graded", "released"] as GradingTab[]).map(tab => (
            <button key={tab} onClick={() => setGradingTab(tab)} style={{
              padding: "8px 16px", border: "none", background: "none", cursor: "pointer",
              fontSize: 13, fontWeight: gradingTab === tab ? 800 : 500,
              color: gradingTab === tab ? G : "#6B7280",
              borderBottom: gradingTab === tab ? `3px solid ${GOLD}` : "3px solid transparent",
              display: "flex", alignItems: "center", gap: 6,
            }}>
              {tab === "pending" ? t("Pending", "بانتظار التصحيح") : tab === "graded" ? t("Graded", "تم التصحيح") : t("Released", "تم الإرسال")}
              {tabCounts[tab] > 0 && (
                <span style={{
                  padding: "1px 6px", borderRadius: 20, fontSize: 10, fontWeight: 900,
                  background: tab === "pending" ? "#FEF2F2" : "#F0FDF4",
                  color: tab === "pending" ? "#DC2626" : "#16A34A",
                }}>
                  {tabCounts[tab]}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Graded results wait here for an admin to release them to students */}
        {gradingTab === "graded" && tabCounts.graded > 0 && (
          <div style={{ marginTop: 10, padding: "8px 14px", borderRadius: 10, background: "#FFFBEB", border: "1px solid #FDE68A", fontSize: 12, fontWeight: 600, color: "#92400E", display: "flex", alignItems: "center", gap: 6, width: "fit-content" }}>
            <Bell size={13} /> {t("Waiting for an admin to release these to students", "بانتظار أن يقوم المسؤول بإرسال هذه النتائج للطلاب")}
          </div>
        )}
      </div>

      {/* List */}
      <div style={{ maxWidth: 800, margin: "20px auto", padding: "0 20px 40px", display: "flex", flexDirection: "column", gap: 12 }}>
        {filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "64px 24px", borderRadius: 20, border: "2px dashed #E5E7EB", background: "#FAFAFA" }}>
            <CheckCircle size={48} style={{ margin: "0 auto 16px", display: "block", opacity: 0.2, color: "#16A34A" }} />
            <p style={{ fontWeight: 700, fontSize: 16, color: "#374151", margin: "0 0 4px" }}>
              {gradingTab === "pending" ? t("All caught up! 🎉", "أحسنت! لا يوجد ما ينتظر 🎉") : t("Nothing here yet", "لا يوجد شيء بعد")}
            </p>
            <p style={{ fontSize: 13, color: "#9CA3AF", margin: 0 }}>
              {gradingTab === "pending" ? t("No pending exams to grade", "لا توجد امتحانات بانتظار التصحيح") : ""}
            </p>
          </div>
        ) : filtered.map(attempt => {
          const examType = attempt.exams?.type || "exam";
          const isTest   = examType === "test";
          const subject  = attempt.exams?.subjects?.title || "";
          return (
            <div key={attempt.id} style={{
              background: "#fff", borderRadius: 16, border: "1px solid #E5E7EB",
              padding: 18, display: "flex", alignItems: "center", gap: 14,
              boxShadow: "0 1px 4px rgba(0,0,0,.04)", flexWrap: "wrap",
            }}>
              {/* Avatar */}
              <div style={{ width: 44, height: 44, borderRadius: "50%", background: G, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 900, color: "#fff", flexShrink: 0 }}>
                {(attempt.profiles?.full_name || "S")[0].toUpperCase()}
              </div>

              {/* Info */}
              <div style={{ flex: 1, minWidth: 160 }}>
                <div style={{ fontWeight: 800, fontSize: 14, color: G, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {attempt.profiles?.full_name || "Student"}
                </div>
                <div style={{ fontSize: 12, color: "#9CA3AF", marginTop: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {attempt.exams?.title} {subject && `• ${subject}`} {attempt.exams?.session && `• 📅 ${attempt.exams.session}`}
                </div>
                <div style={{ fontSize: 11, color: "#9CA3AF", marginTop: 2 }}>
                  {attempt.submitted_at ? new Date(attempt.submitted_at).toLocaleDateString() : "—"}
                  {attempt.status === "graded" && ` • ${Math.round(attempt.percentage || 0)}% — ${attempt.passed ? t("Pass", "ناجح") : t("Fail", "راسب")}`}
                </div>
                {(attempt.status === "graded" || attempt.status === "released") && attempt.graded_by_role === "admin" && (
                  <div style={{ fontSize: 11, color: "#7C3AED", marginTop: 2, fontWeight: 700 }}>
                    {t("Graded by admin", "صححها المسؤول")}
                  </div>
                )}
              </div>

              {/* Badge */}
              <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6, flexShrink: 0 }}>
                <span style={{
                  padding: "3px 10px", borderRadius: 20, fontSize: 10, fontWeight: 700,
                  background: isTest ? "#EFF6FF" : "#FEF2F2",
                  color: isTest ? "#2563EB" : "#DC2626",
                  border: `1px solid ${isTest ? "#93C5FD" : "#FECACA"}`,
                }}>
                  {isTest ? t("Test", "تمرين") : t("Exam", "امتحان")}
                </span>
                {attempt.status === "graded" && (
                  <span style={{
                    padding: "3px 10px", borderRadius: 20, fontSize: 10, fontWeight: 700,
                    background: attempt.passed ? "#F0FDF4" : "#FEF2F2",
                    color: attempt.passed ? "#16A34A" : "#DC2626",
                  }}>
                    {Math.round(attempt.percentage || 0)}%
                  </span>
                )}
              </div>

              {/* Actions */}
              <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                <button onClick={() => openAttempt(attempt)} style={{
                  padding: "8px 16px", borderRadius: 10, border: "none",
                  background: gradingTab === "pending"
                    ? `linear-gradient(135deg, ${G}, ${GM})`
                    : "#F3F4F6",
                  color: gradingTab === "pending" ? "#fff" : G,
                  fontSize: 12, fontWeight: 700, cursor: "pointer",
                  display: "flex", alignItems: "center", gap: 6,
                }}>
                  {gradingTab === "pending" ? <><Send size={12} /> {t("Grade", "صحّح")}</> : <><Eye size={12} /> {t("View", "عرض")}</>}
                </button>
                {gradingTab === "graded" && (
                  <span style={{
                    padding: "8px 14px", borderRadius: 10, border: "1.5px solid #E5E7EB",
                    background: "#FAFAFA", color: "#9CA3AF", fontSize: 12, fontWeight: 700,
                    display: "flex", alignItems: "center", gap: 6,
                  }}>
                    <Unlock size={12} /> {t("Awaiting release", "بانتظار الإرسال")}
                  </span>
                )}
                {gradingTab !== "released" && (
                  <button onClick={() => resetAttempt(attempt)} disabled={resetting === attempt.id}
                    title={t("Reset attempt — deletes this attempt so the student can retake the exam", "إعادة تعيين المحاولة — يحذف هذه المحاولة ليتمكن الطالب من إعادة المحاولة")}
                    style={{
                      display: "flex", alignItems: "center", justifyContent: "center",
                      padding: "7px 10px", borderRadius: 9, border: "1.5px solid #FECACA",
                      background: "#FEF2F2", cursor: resetting === attempt.id ? "not-allowed" : "pointer",
                      opacity: resetting === attempt.id ? .6 : 1,
                    }}>
                    {resetting === attempt.id
                      ? <Loader2 size={13} color="#DC2626" style={{ animation: "spin .8s linear infinite" }} />
                      : <RotateCcw size={13} color="#DC2626" />}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};

export default TeacherGrading;
