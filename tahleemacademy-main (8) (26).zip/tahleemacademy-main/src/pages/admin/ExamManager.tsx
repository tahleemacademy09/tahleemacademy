/* src/pages/admin/ExamManager.tsx
   FIXED: Exam assignment now properly creates exam_assignments rows AND sends in-app
          notifications so StudentExams page shows the assigned exam.
   FIXED: Individual assign loads students from user_roles table (not just profiles)
   FIXED: Notification insert uses correct schema fields
*/
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { useAcademicLevels, getLevelConfig, getLevelDisplay } from "@/hooks/useAcademicLevels";
import { useAcademySettings } from "@/hooks/useAcademySettings";
import { publishExam, splitLevels } from "@/lib/examPublish";
import {
  Plus, Edit, Trash2, Copy, Clock, Search, Send,
  Eye, EyeOff, BarChart2, Loader2, CheckCircle2,
  XCircle, Users, BookOpen, Filter, RotateCcw, CalendarClock
} from "lucide-react";

const G = "#064E3B";

const toLocalDatetimeInput = (iso: string): string => {
  const date = new Date(iso);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  const h = String(date.getHours()).padStart(2, "0");
  const min = String(date.getMinutes()).padStart(2, "0");
  return `${y}-${m}-${d}T${h}:${min}`;
};


export default function ExamManager() {
  const { t, language } = useLanguage();
  const { toast }       = useToast();
  const { user }        = useAuth();
  const navigate        = useNavigate();
  const { data: academicLevels = [] } = useAcademicLevels();
  const LEVELS = academicLevels.map(l => l.slug);

  const [exams, setExams]               = useState<any[]>([]);
  const [loading, setLoading]           = useState(true);
  const [search, setSearch]             = useState("");
  const [termFilter, setTermFilter]     = useState("all");

  // Follow the academy's Current Term setting so this list opens already
  // filtered to the term the admin currently has active, and re-filters
  // live if they advance the term while this page is open.
  const { settings: academySettings } = useAcademySettings();
  useEffect(() => {
    if (academySettings.current_term) setTermFilter(academySettings.current_term);
  }, [academySettings.current_term]);
  const [sessionFilter, setSessionFilter] = useState("all");
  const [typeFilter, setTypeFilter]     = useState("all");
  const [levelFilter, setLevelFilter]   = useState("all");

  // Assign dialog
  const [assignExam, setAssignExam]     = useState<any | null>(null);
  const [assignMode, setAssignMode]     = useState<"level" | "individual">("level");
  const [assignLevel, setAssignLevel]   = useState("");
  const [allStudents, setAllStudents]   = useState<any[]>([]);
  const [selectedStudents, setSelectedStudents] = useState<Set<string>>(new Set());
  const [assigning, setAssigning]       = useState(false);
  const [studentsLoading, setStudentsLoading] = useState(false);
  const [studentSearch, setStudentSearch] = useState("");

  // Counts per exam
  const [counts, setCounts]             = useState<Record<string, { assigned: number; attempts: number }>>({});

  // Manage-students dialog — per-assigned-student view for a single exam:
  // see who has/hasn't attempted, extend an individual student's deadline
  // past the exam's own end_date, or reset an attempt so they can retake.
  const [manageExam, setManageExam]     = useState<any | null>(null);
  const [manageStudents, setManageStudents] = useState<any[]>([]);
  const [manageLoading, setManageLoading] = useState(false);
  const [extendInputs, setExtendInputs] = useState<Record<string, string>>({});
  const [savingExtend, setSavingExtend] = useState<string | null>(null);
  const [resettingAttempt, setResettingAttempt] = useState<string | null>(null);

  const fetchExams = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("exams").select("*, exam_questions(id)").order("created_at", { ascending: false });
    setExams(data || []);
    setLoading(false);

    if (data?.length) {
      const ids = data.map((e: any) => e.id);
      const [ar, at] = await Promise.all([
        supabase.from("exam_assignments").select("exam_id").in("exam_id", ids),
        supabase.from("exam_attempts").select("exam_id").in("exam_id", ids),
      ]);
      const c: Record<string, { assigned: number; attempts: number }> = {};
      (ar.data || []).forEach((a: any) => { c[a.exam_id] = c[a.exam_id] || { assigned: 0, attempts: 0 }; c[a.exam_id].assigned++; });
      (at.data || []).forEach((a: any) => { c[a.exam_id] = c[a.exam_id] || { assigned: 0, attempts: 0 }; c[a.exam_id].attempts++; });
      setCounts(c);
    }
  };

  useEffect(() => { fetchExams(); }, []);

  // Load ALL students when assign dialog opens
  const openAssign = async (exam: any) => {
    setAssignExam(exam);
    setAssignMode("level");
    setAssignLevel("");
    setSelectedStudents(new Set());
    setStudentSearch("");
    setStudentsLoading(true);

    // FIX: Two-step query — the FK join user_roles→profiles is not always configured
    // Step 1: get all student user_ids
    const { data: roles } = await supabase
      .from("user_roles" as any)
      .select("user_id")
      .eq("role", "student");

    const userIds = (roles || []).map((r: any) => r.user_id);

    // Step 2: fetch profiles separately using .in()
    let students: any[] = [];
    if (userIds.length > 0) {
      const { data: profiles } = await supabase
        .from("profiles")
        .select("user_id, full_name, full_name_ar, level")
        .in("user_id", userIds);

      students = (profiles || []).map((p: any) => ({
        user_id: p.user_id,
        full_name: p.full_name || "Unknown",
        full_name_ar: p.full_name_ar || "",
        level: p.level || "—",
      }));
    }

    setAllStudents(students);
    setStudentsLoading(false);
  };

  // Manage-students dialog: every assigned student for this exam, with
  // their attempt status and any per-student deadline extension.
  const openManage = async (exam: any) => {
    setManageExam(exam);
    setManageStudents([]);
    setExtendInputs({});
    setManageLoading(true);
    try {
      const asnRes = await supabase.from("exam_assignments" as any).select("user_id, extended_until").eq("exam_id", exam.id);
      if (asnRes.error) throw new Error(`Loading assigned students failed: ${asnRes.error.message}`);
      const assignments = asnRes.data || [];
      const userIds = assignments.map((a: any) => a.user_id);

      const [attRes, profRes] = await Promise.all([
        supabase.from("exam_attempts").select("id, user_id, status, score, percentage, passed, created_at")
          .eq("exam_id", exam.id).order("created_at", { ascending: false }),
        userIds.length
          ? supabase.from("profiles").select("user_id, full_name").in("user_id", userIds)
          : Promise.resolve({ data: [] as any[], error: null }),
      ]);
      if (attRes.error)  console.warn("Loading attempts failed:", attRes.error.message);
      if (profRes.error) console.warn("Loading student names failed:", profRes.error.message);

      const attempts = attRes.data || [];
      const profiles = (profRes as any).data || [];

      const rows = assignments.map((a: any) => {
        const myAttempts = attempts.filter((at: any) => at.user_id === a.user_id);
        const profile = profiles.find((p: any) => p.user_id === a.user_id);
        return {
          user_id: a.user_id,
          full_name: profile?.full_name || `Unknown (${String(a.user_id).slice(0, 8)})`,
          extended_until: a.extended_until,
          attempts: myAttempts,
        };
      });
      rows.sort((a, b) => a.full_name.localeCompare(b.full_name));
      setManageStudents(rows);
      if ((profRes as any).error) {
        toast({ title: "Some student names failed to load", description: (profRes as any).error.message, variant: "destructive" });
      }
    } catch (e: any) {
      toast({ title: "Failed to load students", description: e.message, variant: "destructive" });
    } finally {
      setManageLoading(false);
    }
  };

  const saveExtend = async (userId: string) => {
    if (!manageExam) return;
    setSavingExtend(userId);
    try {
      const raw = extendInputs[userId];
      const value = raw ? new Date(raw).toISOString() : null;
      const { error } = await supabase.from("exam_assignments" as any)
        .update({ extended_until: value } as any)
        .eq("exam_id", manageExam.id).eq("user_id", userId);
      if (error) throw new Error(error.message);
      setManageStudents(rows => rows.map(r => r.user_id === userId ? { ...r, extended_until: value } : r));
      toast({ title: value ? "✅ Deadline extended for this student" : "✅ Extension cleared" });
    } catch (e: any) {
      toast({ title: "Failed to save extension", description: e.message, variant: "destructive" });
    } finally {
      setSavingExtend(null);
    }
  };

  // Same effect as the reset icon in Grading: deletes the attempt (and its
  // answers, via cascade) so it no longer counts against max_attempts.
  const resetStudentAttempt = async (attemptId: string, studentName: string) => {
    if (!confirm(`Reset ${studentName}'s attempt? Their score and answers will be permanently deleted and they'll be able to retake it.`)) return;
    setResettingAttempt(attemptId);
    try {
      const { error } = await supabase.from("exam_attempts").delete().eq("id", attemptId);
      if (error) throw new Error(error.message);
      setManageStudents(rows => rows.map(r => ({ ...r, attempts: r.attempts.filter((a: any) => a.id !== attemptId) })));
      toast({ title: `✅ Attempt reset — ${studentName} can retake the exam` });
    } catch (e: any) {
      toast({ title: "Reset failed", description: e.message, variant: "destructive" });
    } finally {
      setResettingAttempt(null);
    }
  };

  const togglePublish = async (id: string, current: boolean) => {
    const exam = exams.find(e => e.id === id);
    const { newlyAssignedCount } = await publishExam(
      { id, title: exam?.title || "", type: exam?.type, level: exam?.level },
      !current,
      user?.id
    );
    setExams(es => es.map(e => e.id === id ? { ...e, is_published: !current } : e));
    toast({
      title: !current ? "✅ Exam published" : "✅ Exam unpublished",
      description: !current && newlyAssignedCount > 0
        ? `Assigned to ${newlyAssignedCount} student${newlyAssignedCount !== 1 ? "s" : ""} and notified them + admins.`
        : undefined,
    });
  };

  const duplicateExam = async (exam: any) => {
    try {
      const { data: qs } = await supabase.from("exam_questions").select("*").eq("exam_id", exam.id);
      // Strip auto-generated fields to avoid insert conflicts
      const cleanExam: any = { ...exam };
      delete cleanExam.id; delete cleanExam.created_at; delete cleanExam.updated_at; delete cleanExam.exam_questions;
      const { data: ne, error: neErr } = await supabase.from("exams").insert({
        ...cleanExam,
        title: exam.title + " (Copy)",
        title_ar: exam.title_ar ? exam.title_ar + " (نسخة)" : null,
        is_published: false,
      }).select("id").single();
      if (neErr) throw neErr;
      if (ne && qs?.length) {
        const qRows = qs.map((q: any) => {
          const clean: any = { ...q }; delete clean.id; delete clean.created_at; delete clean.updated_at;
          return { ...clean, exam_id: ne.id };
        });
        const { error: qErr } = await supabase.from("exam_questions").insert(qRows);
        if (qErr) console.warn("Questions copy warning:", qErr.message);
      }
      toast({ title: "✅ Exam duplicated with all questions!" });
      fetchExams();
    } catch (e: any) {
      toast({ title: "Duplicate failed", description: e.message, variant: "destructive" });
    }
  };

  const deleteExam = async (id: string) => {
    if (!confirm("Delete this exam and all its questions?")) return;
    await supabase.from("exam_assignments").delete().eq("exam_id", id);
    await supabase.from("exam_questions").delete().eq("exam_id", id);
    await supabase.from("exams").delete().eq("id", id);
    setExams(es => es.filter(e => e.id !== id));
    toast({ title: "✅ Exam deleted" });
  };

  // FIX: Assignment with guaranteed notification insert
  const doAssign = async () => {
    if (!assignExam) return;
    setAssigning(true);

    try {
      let userIds: string[] = [];

      if (assignMode === "level") {
        if (!assignLevel) { toast({ title: "Select a level", variant: "destructive" }); setAssigning(false); return; }
        userIds = allStudents.filter(s => s.level === assignLevel).map(s => s.user_id);
      } else {
        userIds = Array.from(selectedStudents);
      }

      if (userIds.length === 0) {
        toast({ title: "No students found for this selection", variant: "destructive" });
        setAssigning(false); return;
      }

      // FIX: Allow retake — delete old in-progress attempts so student starts fresh
      await supabase.from("exam_attempts")
        .delete().eq("exam_id", assignExam.id).in("user_id", userIds).eq("status", "in_progress");

      // Upsert assignments — one row per (exam, user). Re-clicking "Assign" on a
      // student who's already assigned just refreshes assigned_by/assigned_at
      // instead of creating a duplicate row (which used to show as repeated
      // exam cards on the student's exam list).
      const { error: assignErr } = await supabase.from("exam_assignments")
        .upsert(
          userIds.map(uid => ({ exam_id: assignExam.id, user_id: uid, assigned_by: user?.id })),
          { onConflict: "exam_id,user_id" }
        );
      if (assignErr) console.warn("Assign upsert:", assignErr.message);

      // Notify all students — try bulk first, fall back to individual if RLS blocks bulk
      // NOTE: the notifications table has no "reference_id" column — inserting one
      // silently fails every row (bulk AND the one-by-one fallback), which is why
      // no notifications were ever showing up. Use "link" instead, which exists.
      const isTest = (assignExam.type || "exam") === "test";
      const kindLabel = isTest ? "Test" : "Exam";
      const notifRows = userIds.map(uid => ({
        user_id: uid,
        title: `📝 ${kindLabel} assigned: ${assignExam.title}`,
        message: `You have been assigned "${assignExam.title}". ${assignExam.start_date ? `Opens: ${new Date(assignExam.start_date).toLocaleDateString()}` : "You can take it now."}`,
        type: "exam_assigned", link: "/student/exams", is_read: false,
      }));
      const { error: bulkNotifErr } = await supabase.from("notifications" as any).insert(notifRows);
      if (bulkNotifErr) {
        // Bulk failed (likely RLS) — insert one-by-one so at least some get through
        console.warn("Bulk notification insert failed, trying individually:", bulkNotifErr.message);
        let notifOk = 0;
        for (const row of notifRows) {
          const { error: singleErr } = await supabase.from("notifications" as any).insert(row);
          if (!singleErr) notifOk++;
          else console.warn("Single notif insert failed:", singleErr.message);
        }
        if (notifOk === 0) console.error("All notification inserts failed — check RLS policy on notifications table");
      }

      toast({ title: `✅ Assigned to ${userIds.length} student${userIds.length !== 1 ? "s" : ""}` });
      setAssignExam(null);
      fetchExams();
    } catch (e: any) {
      toast({ title: "Assignment failed", description: e.message, variant: "destructive" });
    } finally {
      setAssigning(false);
    }
  };

  const qCount = (e: any) => e.exam_questions?.length ?? 0;

  const sessionOptions = Array.from(new Set(exams.map(e => e.session).filter(Boolean))).sort().reverse();

  const filtered = exams.filter(e => {
    const name = language === "ar" ? (e.title_ar || e.title) : e.title;
    if (search && !name.toLowerCase().includes(search.toLowerCase())) return false;
    if (termFilter !== "all" && e.term !== termFilter) return false;
    if (sessionFilter !== "all" && (e.session || "") !== sessionFilter) return false;
    if (typeFilter !== "all" && e.type !== typeFilter) return false;
    if (levelFilter !== "all" && !splitLevels(e.level).includes(levelFilter)) return false;
    return true;
  });

  const TERM_ORDER: Record<string, number> = { first: 0, second: 1, final: 2 };
  const TERM_LABEL: Record<string, string> = { first: "First Term", second: "Second Term", final: "Final Term" };
  const groupedSections = (() => {
    const bySession: Record<string, Record<string, any[]>> = {};
    for (const e of filtered) {
      const s = e.session || "Unspecified session";
      const tm = e.term || "unspecified";
      (bySession[s] ??= {})[tm] ??= [];
      bySession[s][tm].push(e);
    }
    return Object.keys(bySession).sort().reverse().map(session => ({
      session,
      terms: Object.keys(bySession[session])
        .sort((a, b) => (TERM_ORDER[a] ?? 99) - (TERM_ORDER[b] ?? 99))
        .map(term => ({ term, exams: bySession[session][term] })),
    }));
  })();

  const filteredStudents = allStudents.filter(s =>
    s.full_name.toLowerCase().includes(studentSearch.toLowerCase()) ||
    s.full_name_ar.includes(studentSearch)
  );

  const inp: React.CSSProperties = {
    padding: "8px 12px", borderRadius: 10, border: "1.5px solid #E5E7EB",
    fontSize: 13, outline: "none", background: "#fff",
  };

  return (
    <div style={{ minHeight: "100vh", background: "#F3F4F6" }}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}} @keyframes livePulse{0%,100%{opacity:1}50%{opacity:.35}}`}</style>

      {/* Header */}
      <div style={{ background: "#fff", borderBottom: "1px solid #E5E7EB", padding: "14px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 18, fontWeight: 800, color: "#111", margin: 0 }}>Exam Manager</h1>
          <p style={{ fontSize: 12, color: "#6B7280", margin: 0 }}>Create, publish, and assign exams to students</p>
        </div>
        <button onClick={() => navigate("/admin/exams/create")}
          style={{ display: "flex", alignItems: "center", gap: 7, padding: "9px 16px", borderRadius: 11, border: "none", background: G, color: "#fff", cursor: "pointer", fontWeight: 800, fontSize: 13 }}>
          <Plus size={15} /> New Exam
        </button>
      </div>

      <div style={{ padding: 16, maxWidth: 800, margin: "0 auto" }}>

        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, marginBottom: 16 }}>
          {[
            { v: exams.length, l: "Total", icon: "📋", bg: "#EFF6FF", c: "#1D4ED8" },
            { v: exams.filter(e => e.is_published).length, l: "Published", icon: "🌐", bg: "#F0FDF4", c: "#166534" },
            { v: exams.filter(e => !e.is_published).length, l: "Draft", icon: "✏️", bg: "#FFF7ED", c: "#C2410C" },
            { v: exams.reduce((s, e) => s + (counts[e.id]?.attempts || 0), 0), l: "Attempts", icon: "📊", bg: "#F5F3FF", c: "#6D28D9" },
          ].map((s, i) => (
            <div key={i} style={{ background: s.bg, borderRadius: 12, padding: "12px 14px" }}>
              <div style={{ fontSize: 20, marginBottom: 4 }}>{s.icon}</div>
              <div style={{ fontSize: 20, fontWeight: 900, color: s.c }}>{s.v}</div>
              <div style={{ fontSize: 11, color: s.c, opacity: .7, fontWeight: 600 }}>{s.l}</div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div style={{ display: "flex", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
          <div style={{ flex: 1, minWidth: 180, position: "relative" }}>
            <Search size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "#9CA3AF" }} />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search exams…"
              style={{ ...inp, width: "100%", paddingLeft: 32, boxSizing: "border-box" }} />
          </div>
          {[
            { val: sessionFilter, set: setSessionFilter, opts: [["all", "All Sessions"], ...sessionOptions.map(s => [s, s])] },
            { val: termFilter, set: setTermFilter, opts: [["all", "All Terms"], ["first", "First"], ["second", "Second"], ["third", "Third"]] },
            { val: typeFilter, set: setTypeFilter, opts: [["all", "All Types"], ["exam", "Exam"], ["test", "Test"], ["quiz", "Quiz"]] },
            { val: levelFilter, set: setLevelFilter, opts: [["all", "All Levels"], ...academicLevels.map(l => [l.slug, l.name_en])] },
          ].map((f, i) => (
            <select key={i} value={f.val} onChange={e => f.set(e.target.value)}
              style={{ ...inp, minWidth: 120 }}>
              {f.opts.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          ))}
        </div>

        {/* Exam list */}
        {loading ? (
          <div style={{ textAlign: "center", padding: 48 }}>
            <Loader2 size={32} style={{ animation: "spin .8s linear infinite", color: G }} />
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "48px 24px", background: "#fff", borderRadius: 16, border: "2px dashed #E5E7EB" }}>
            <div style={{ fontSize: 40, marginBottom: 10 }}>📋</div>
            <p style={{ fontWeight: 700, color: "#374151" }}>No exams found</p>
            <button onClick={() => navigate("/admin/exams/create")}
              style={{ marginTop: 12, padding: "9px 20px", borderRadius: 10, border: "none", background: G, color: "#fff", cursor: "pointer", fontWeight: 700 }}>
              Create Your First Exam
            </button>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 22 }}>
            {groupedSections.map(({ session, terms }) => (
              <div key={session}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                  <span style={{ fontSize: 13, fontWeight: 900, color: "#0E7490" }}>📅 {session}</span>
                  <div style={{ flex: 1, height: 1, background: "#E5E7EB" }} />
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
                  {terms.map(({ term, exams: termExams }) => (
                    <div key={term}>
                      <p style={{ fontSize: 11, fontWeight: 700, color: "#6D28D9", textTransform: "uppercase", letterSpacing: .4, margin: "0 0 8px" }}>
                        {TERM_LABEL[term] || term}
                      </p>
                      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                        {termExams.map(exam => {
                          const qc   = qCount(exam);
                          const stat = counts[exam.id] || { assigned: 0, attempts: 0 };
                          return (
                <div key={exam.id} style={{ background: "#fff", borderRadius: 16, border: "1.5px solid #E5E7EB", padding: 16, boxShadow: "0 1px 4px rgba(0,0,0,.04)" }}>
                  <div style={{ display: "flex", alignItems: "flex-start", gap: 12, flexWrap: "wrap" }}>
                    <div style={{ flex: 1, minWidth: 200 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4, flexWrap: "wrap" }}>
                        <span style={{ fontWeight: 800, fontSize: 14, color: "#111" }}>
                          {language === "ar" ? exam.title_ar || exam.title : exam.title}
                        </span>
                        <span style={{ fontSize: 10, fontWeight: 700, padding: "2px 8px", borderRadius: 20, background: exam.is_published ? "#DCFCE7" : "#F3F4F6", color: exam.is_published ? "#166534" : "#6B7280" }}>
                          {exam.is_published ? "✓ Published" : "Draft"}
                        </span>
                        {exam.type && <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 20, background: "#EFF6FF", color: "#1D4ED8", fontWeight: 600 }}>{exam.type}</span>}
                        {exam.session && <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 20, background: "#ECFEFF", color: "#0E7490", fontWeight: 700 }}>📅 {exam.session}</span>}
                        {exam.term && <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 20, background: "#F5F3FF", color: "#6D28D9", fontWeight: 600 }}>{exam.term}</span>}
                        {exam.level && <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 20, background: "#FFF7ED", color: "#C2410C", fontWeight: 600, textTransform: "capitalize" }}>📚 {splitLevels(exam.level).join(" + ")}</span>}
                      </div>
                      {exam.title_ar && language !== "ar" && <p style={{ fontSize: 11, color: "#9CA3AF", margin: "2px 0 6px", fontFamily: "'Amiri',serif", direction: "rtl" }}>{exam.title_ar}</p>}
                      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 6 }}>
                        {[
                          { icon: "❓", v: qc, l: `q${qc !== 1 ? "s" : ""}`, c: qc === 0 ? "#DC2626" : "#374151" },
                          { icon: "⏱️", v: exam.time_limit_minutes || "—", l: "min" },
                          { icon: "🎯", v: `${exam.passing_score || 60}%`, l: "pass" },
                          { icon: "👥", v: stat.assigned, l: "registered" },
                          { icon: "📊", v: stat.attempts, l: "attempts" },
                        ].map((s, i) => (
                          <span key={i} style={{ fontSize: 11, display: "flex", alignItems: "center", gap: 3 }}>
                            {s.icon} <strong style={{ color: (s as any).c || "#374151" }}>{s.v}</strong> <span style={{ color: "#9CA3AF" }}>{s.l}</span>
                          </span>
                        ))}
                      </div>
                    </div>

                    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", flexShrink: 0 }}>
                      <button onClick={() => openAssign(exam)} title="Assign to students"
                        style={{ display: "flex", alignItems: "center", gap: 5, padding: "8px 13px", borderRadius: 9, border: "none", background: G, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 700 }}>
                        <Send size={12} /> Assign
                      </button>
                      <button onClick={() => navigate(`/admin/exams/${exam.id}/live`)} title="Live monitor — track students taking this exam right now"
                        style={{ display: "flex", alignItems: "center", gap: 5, padding: "8px 13px", borderRadius: 9, border: "none", background: "#dc2626", color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 700 }}>
                        <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#fff", display: "inline-block", animation: "livePulse 1.4s ease-in-out infinite" }} /> Live
                      </button>
                      <button onClick={() => navigate(`/admin/exams/${exam.id}/edit`)} title="Edit exam"
                        style={{ display: "flex", alignItems: "center", gap: 5, padding: "8px 11px", borderRadius: 9, border: "1.5px solid #E5E7EB", background: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600, color: "#374151" }}>
                        <Edit size={13} color="#6B7280" /> Edit
                      </button>
                      <button onClick={() => togglePublish(exam.id, exam.is_published)} title={exam.is_published ? "Unpublish" : "Publish"}
                        style={{ padding: "8px 10px", borderRadius: 9, border: "1.5px solid #E5E7EB", background: exam.is_published ? "#FFF7ED" : "#F0FDF4", cursor: "pointer" }}>
                        {exam.is_published ? <EyeOff size={13} color="#C2410C" /> : <Eye size={13} color="#16A34A" />}
                      </button>
                      <button onClick={() => duplicateExam(exam)} title="Duplicate"
                        style={{ padding: "8px 10px", borderRadius: 9, border: "1.5px solid #E5E7EB", background: "#fff", cursor: "pointer" }}>
                        <Copy size={13} color="#6B7280" />
                      </button>
                      <button onClick={() => navigate("/admin/grading")} title="View grading"
                        style={{ padding: "8px 10px", borderRadius: 9, border: "1.5px solid #E5E7EB", background: "#EFF6FF", cursor: "pointer" }}>
                        <BarChart2 size={13} color="#1D4ED8" />
                      </button>
                      <button onClick={() => openManage(exam)} title="Extend deadline / manage students — extend a missed deadline or reset an attempt"
                        style={{ padding: "8px 10px", borderRadius: 9, border: "1.5px solid #E5E7EB", background: "#F5F3FF", cursor: "pointer" }}>
                        <CalendarClock size={13} color="#6D28D9" />
                      </button>
                      <button onClick={() => deleteExam(exam.id)} title="Delete exam"
                        style={{ padding: "8px 10px", borderRadius: 9, border: "1.5px solid #FECACA", background: "#FEF2F2", cursor: "pointer" }}>
                        <Trash2 size={13} color="#DC2626" />
                      </button>
                    </div>
                  </div>
                </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ── Assign Dialog ── */}
      <Dialog open={!!assignExam} onOpenChange={v => !v && setAssignExam(null)}>
        <DialogContent style={{ maxWidth: 520, borderRadius: 20, padding: 0, maxHeight: "90vh", display: "flex", flexDirection: "column" }}>
          <div style={{ background: G, padding: "16px 20px", borderRadius: "20px 20px 0 0", flexShrink: 0 }}>
            <h2 style={{ fontWeight: 800, fontSize: 15, color: "#fff", margin: 0 }}>
              📋 Assign: {assignExam?.title}
            </h2>
            <p style={{ fontSize: 11, color: "rgba(255,255,255,.7)", margin: "4px 0 0" }}>
              Students will receive an in-app notification and see this exam immediately.
            </p>
          </div>

          <div style={{ padding: 16, overflow: "auto", flex: 1 }}>
            {/* Mode selector */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
              {[
                { id: "level" as const, icon: "🎓", label: "By Level", sub: "Assign to all students at a level" },
                { id: "individual" as const, icon: "👤", label: "Individual", sub: "Select specific students" },
              ].map(m => (
                <button key={m.id} onClick={() => setAssignMode(m.id)}
                  style={{ padding: "12px", borderRadius: 12, border: `1.5px solid ${assignMode === m.id ? G : "#E5E7EB"}`, background: assignMode === m.id ? "#F0FDF4" : "#fff", cursor: "pointer", textAlign: "left" }}>
                  <p style={{ fontSize: 18, margin: "0 0 4px" }}>{m.icon}</p>
                  <p style={{ fontWeight: 700, fontSize: 13, color: assignMode === m.id ? G : "#374151", margin: 0 }}>{m.label}</p>
                  <p style={{ fontSize: 11, color: "#9CA3AF", margin: 0 }}>{m.sub}</p>
                </button>
              ))}
            </div>

            {/* Level mode */}
            {assignMode === "level" && (
              <div>
                <p style={{ fontSize: 12, fontWeight: 700, color: "#6B7280", marginBottom: 8 }}>Select Level</p>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {LEVELS.map(lv => {
                    const count = allStudents.filter(s => s.level === lv).length;
                    return (
                      <button key={lv} onClick={() => setAssignLevel(lv)}
                        style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 14px", borderRadius: 12, border: `1.5px solid ${assignLevel === lv ? G : "#E5E7EB"}`, background: assignLevel === lv ? "#F0FDF4" : "#fff", cursor: "pointer" }}>
                        <span style={{ fontWeight: 700, fontSize: 13, color: assignLevel === lv ? G : "#374151", textTransform: "capitalize" }}>{lv}</span>
                        <span style={{ fontSize: 12, color: "#9CA3AF" }}>{studentsLoading ? "…" : `${count} student${count !== 1 ? "s" : ""}`}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Individual mode */}
            {assignMode === "individual" && (
              <div>
                <div style={{ position: "relative", marginBottom: 10 }}>
                  <Search size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "#9CA3AF" }} />
                  <input value={studentSearch} onChange={e => setStudentSearch(e.target.value)} placeholder="Search students…"
                    style={{ ...inp, width: "100%", paddingLeft: 32, boxSizing: "border-box" as const }} />
                </div>
                {studentsLoading ? (
                  <div style={{ textAlign: "center", padding: 24 }}><Loader2 size={24} style={{ animation: "spin .8s linear infinite", color: G }} /></div>
                ) : (
                  <>
                    <div style={{ fontSize: 11, color: "#9CA3AF", marginBottom: 6 }}>{selectedStudents.size} selected of {filteredStudents.length}</div>
                    <div style={{ maxHeight: 280, overflowY: "auto", display: "flex", flexDirection: "column", gap: 6 }}>
                      {filteredStudents.map(s => {
                        const sel = selectedStudents.has(s.user_id);
                        return (
                          <button key={s.user_id}
                            onClick={() => {
                              const next = new Set(selectedStudents);
                              if (sel) next.delete(s.user_id); else next.add(s.user_id);
                              setSelectedStudents(next);
                            }}
                            style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 11, border: `1.5px solid ${sel ? G : "#E5E7EB"}`, background: sel ? "#F0FDF4" : "#fff", cursor: "pointer", textAlign: "left" }}>
                            <div style={{ width: 32, height: 32, borderRadius: "50%", background: sel ? G : "#EFF6FF", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                              <span style={{ fontSize: 12, fontWeight: 700, color: sel ? "#fff" : "#1D4ED8" }}>{s.full_name[0]}</span>
                            </div>
                            <div style={{ flex: 1 }}>
                              <p style={{ fontWeight: 700, fontSize: 13, color: sel ? G : "#374151", margin: 0 }}>{s.full_name}</p>
                              {s.full_name_ar && <p style={{ fontSize: 11, color: "#9CA3AF", margin: 0, fontFamily: "'Amiri',serif", direction: "rtl" }}>{s.full_name_ar}</p>}
                            </div>
                            <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 20, background: "#F5F3FF", color: "#6D28D9", fontWeight: 600, flexShrink: 0 }}>{s.level}</span>
                            {sel && <CheckCircle2 size={16} color={G} />}
                          </button>
                        );
                      })}
                    </div>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          <div style={{ padding: "14px 16px", borderTop: "1px solid #E5E7EB", flexShrink: 0, display: "flex", gap: 10 }}>
            <button onClick={() => setAssignExam(null)}
              style={{ flex: 1, padding: 12, borderRadius: 11, border: "1.5px solid #E5E7EB", background: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 13 }}>
              Cancel
            </button>
            <button onClick={doAssign}
              disabled={assigning || (assignMode === "level" && !assignLevel) || (assignMode === "individual" && selectedStudents.size === 0)}
              style={{ flex: 2, padding: 12, borderRadius: 11, border: "none", cursor: assigning ? "not-allowed" : "pointer", fontWeight: 800, fontSize: 13, color: "#fff",
                background: assigning ? "#9CA3AF" : G, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
              {assigning
                ? <><Loader2 size={14} style={{ animation: "spin .8s linear infinite" }} /> Assigning…</>
                : <><Send size={14} /> Assign & Notify Students</>}
            </button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Manage Students Dialog ── */}
      <Dialog open={!!manageExam} onOpenChange={v => !v && setManageExam(null)}>
        <DialogContent style={{ maxWidth: 560, borderRadius: 20, padding: 0, maxHeight: "90vh", display: "flex", flexDirection: "column" }}>
          <div style={{ background: "#6D28D9", padding: "16px 20px", borderRadius: "20px 20px 0 0", flexShrink: 0 }}>
            <h2 style={{ fontWeight: 800, fontSize: 15, color: "#fff", margin: 0 }}>
              👥 Students: {manageExam?.title}
            </h2>
            <p style={{ fontSize: 11, color: "rgba(255,255,255,.7)", margin: "4px 0 0" }}>
              Extend a missed deadline for one student, or reset an attempt so they can retake.
            </p>
          </div>

          <div style={{ padding: 16, overflow: "auto", flex: 1 }}>
            {manageLoading ? (
              <div style={{ textAlign: "center", padding: 24 }}><Loader2 size={24} style={{ animation: "spin .8s linear infinite", color: G }} /></div>
            ) : manageStudents.length === 0 ? (
              <p style={{ textAlign: "center", color: "#9CA3AF", fontSize: 13, padding: 24 }}>No students assigned to this exam yet.</p>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {manageStudents.map(s => {
                  const latest = s.attempts[0];
                  const max = manageExam?.max_attempts || 1;
                  const done = s.attempts.filter((a: any) => a.status !== "in_progress").length;
                  let statusLabel = "Not started";
                  let statusColor = "#6B7280";
                  if (latest) {
                    if (latest.status === "in_progress")      { statusLabel = "In progress"; statusColor = "#D97706"; }
                    else if (latest.status === "submitted")   { statusLabel = "Pending grading"; statusColor = "#1D4ED8"; }
                    else if (latest.status === "graded")      { statusLabel = `Graded — ${Math.round(latest.percentage || 0)}%`; statusColor = latest.passed ? "#16A34A" : "#DC2626"; }
                    else if (latest.status === "released")    { statusLabel = `Released — ${Math.round(latest.percentage || 0)}%`; statusColor = latest.passed ? "#16A34A" : "#DC2626"; }
                  }
                  const missedDeadline = done === 0 && manageExam?.end_date && new Date(manageExam.end_date).getTime() < Date.now() && !s.extended_until;
                  return (
                    <div key={s.user_id} style={{ padding: 12, borderRadius: 12, border: "1.5px solid #E5E7EB", background: "#fff" }}>
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}>
                        <div>
                          <p style={{ fontWeight: 700, fontSize: 13, color: "#111", margin: 0 }}>{s.full_name}</p>
                          <p style={{ fontSize: 11, margin: "2px 0 0" }}>
                            <span style={{ color: statusColor, fontWeight: 700 }}>{statusLabel}</span>
                            <span style={{ color: "#9CA3AF" }}> · {done}/{max} attempts</span>
                            {missedDeadline && <span style={{ color: "#DC2626", fontWeight: 700 }}> · missed deadline</span>}
                          </p>
                        </div>
                        {latest && latest.status !== "in_progress" && (
                          <button onClick={() => resetStudentAttempt(latest.id, s.full_name)} disabled={resettingAttempt === latest.id}
                            title="Reset this attempt so they can retake"
                            style={{ display: "flex", alignItems: "center", gap: 5, padding: "6px 10px", borderRadius: 8, border: "1.5px solid #FECACA", background: "#FEF2F2", cursor: resettingAttempt === latest.id ? "not-allowed" : "pointer", fontSize: 11, fontWeight: 700, color: "#DC2626", opacity: resettingAttempt === latest.id ? .6 : 1 }}>
                            {resettingAttempt === latest.id ? <Loader2 size={11} style={{ animation: "spin .8s linear infinite" }} /> : <RotateCcw size={11} />} Reset
                          </button>
                        )}
                      </div>

                      <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                        <input type="datetime-local"
                          value={extendInputs[s.user_id] ?? (s.extended_until ? toLocalDatetimeInput(s.extended_until) : "")}
                          onChange={e => setExtendInputs(inp => ({ ...inp, [s.user_id]: e.target.value }))}
                          style={{ ...inp, flex: 1, fontSize: 12, padding: "6px 8px" }} />
                        <button onClick={() => saveExtend(s.user_id)} disabled={savingExtend === s.user_id}
                          style={{ display: "flex", alignItems: "center", gap: 5, padding: "6px 12px", borderRadius: 8, border: "none", background: G, color: "#fff", fontSize: 11, fontWeight: 700, cursor: "pointer", opacity: savingExtend === s.user_id ? .6 : 1 }}>
                          {savingExtend === s.user_id
                            ? <Loader2 size={11} style={{ animation: "spin .8s linear infinite" }} />
                            : <CalendarClock size={11} />}
                          {savingExtend === s.user_id ? "…" : s.extended_until ? "Update" : "Extend"}
                        </button>
                      </div>
                      {s.extended_until && (
                        <p style={{ fontSize: 10, color: "#16A34A", margin: "6px 0 0" }}>
                          ✓ Extended until {new Date(s.extended_until).toLocaleString(language === "ar" ? "ar-SA" : "en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })} — clear the field and press Update to remove.
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div style={{ padding: "14px 16px", borderTop: "1px solid #E5E7EB", flexShrink: 0 }}>
            <button onClick={() => setManageExam(null)}
              style={{ width: "100%", padding: 12, borderRadius: 11, border: "1.5px solid #E5E7EB", background: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 13 }}>
              Close
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}