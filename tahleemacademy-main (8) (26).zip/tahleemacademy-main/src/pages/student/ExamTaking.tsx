/*
  src/pages/student/ExamTaking.tsx
  ENHANCED VERSION — New question types, confidence indicator,
  keyboard navigation, section support, better mobile UX
*/
import { useEffect, useState, useCallback, useRef } from "react";
import { lockReload, unlockReload } from "@/lib/reloadGuard";
import { useParams, useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { storageSupabase } from "../../integrations/supabase/storageClient";
import { useToast } from "@/hooks/use-toast";
import { logger } from "@/lib/logger";
import { sanitizeHtml } from "@/lib/sanitize";
import {
  Clock, Flag, AlertTriangle, BookOpen, CheckCircle2,
  Lock, ChevronLeft, ChevronRight, Save, Eye, Grid, Send,
  Zap, ThumbsUp, ThumbsDown, Minus, RotateCcw, Keyboard
} from "lucide-react";
import AudioPlayer from "@/components/exam/AudioPlayer";
import AudioRecorder from "@/components/exam/AudioRecorder";
import { uploadExamAudioToR2 } from "@/lib/examAudioUpload";
import ProctoringOverlay from "@/components/exam/ProctoringOverlay";
import ExamFocusGuard from "@/components/exam/ExamFocusGuard";
import { enableExamPrivacyScreen, disableExamPrivacyScreen } from "@/lib/examPrivacyScreen";
import { useProctoring } from "@/hooks/useProctoring";
import { useIsMobile } from "@/hooks/use-mobile";

const G = "#0f2d1f", GM = "#1a4731", GOLD = "#c9a84c", BORDER = "rgba(15,45,31,0.12)";
const CONFIDENT = "#22c55e", UNSURE = "#f59e0b", GUESSING = "#ef4444";

type Confidence = "confident" | "unsure" | "guessing" | null;
type AnswerState = { text: string; data: any; flagged: boolean; confidence: Confidence };

/* ── Deterministic per-student option shuffle ───────────────────────
   Seeds off (userId + questionId) so the order is stable across
   reloads/re-renders within the same attempt, but differs student
   to student — mirrors how the RPC deterministically randomizes
   question selection via md5(auth.uid() || question.id).
─────────────────────────────────────────────────────────────────── */
function seededShuffle<T>(items: T[], seedStr: string): T[] {
  let seed = 0;
  for (let i = 0; i < seedStr.length; i++) seed = (seed * 31 + seedStr.charCodeAt(i)) >>> 0;
  const rand = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/* ── Bilingual question renderer ────────────────────────────────────
   Splits "Arabic (English)" → Arabic first, English below, no brackets.
─────────────────────────────────────────────────────────────────── */
function splitBilingual(text: string): { ar: string; en: string } | null {
  if (!text) return null;
  const t = text.trim();
  const m1 = t.match(/^([\s\S]*?[؀-ۿ][\s\S]*?)\s*\(([^)]+)\)\s*$/);
  if (m1 && /[a-zA-Z]/.test(m1[2])) return { ar: m1[1].trim(), en: m1[2].trim() };
  const m2 = t.match(/^\(([^)]+)\)\s*([\s\S]*[؀-ۿ][\s\S]*)$/);
  if (m2 && /[a-zA-Z]/.test(m2[1])) return { ar: m2[2].trim(), en: m2[1].trim() };
  const lines = t.split("\n");
  if (lines.length >= 2) {
    const arParts: string[] = [], enParts: string[] = [];
    for (const l of lines) {
      const s = l.replace(/[()]/g, "").trim(); if (!s) continue;
      if (/[؀-ۿ]/.test(s)) arParts.push(s);
      else if (/[a-zA-Z]/.test(s)) enParts.push(s);
    }
    if (arParts.length && enParts.length) return { ar: arParts.join(" "), en: enParts.join(" ") };
  }
  return null;
}

const QText = ({ text, textAr }: { text?: string; textAr?: string }) => {
  const primary = text || textAr || "";
  const secondary = textAr && textAr !== text ? textAr : null;
  const split = !secondary ? splitBilingual(primary) : null;
  const arStyle: React.CSSProperties = {
    fontFamily: "'Scheherazade New','Amiri Quran','Amiri',serif",
    fontSize: 22, fontWeight: 700, lineHeight: 2.3, color: G,
    textAlign: "right", direction: "rtl",
    padding: "4px 0 4px 12px", borderRight: `3px solid ${GOLD}`, marginBottom: 8,
  };
  const enStyle: React.CSSProperties = {
    fontFamily: "'Cairo',sans-serif", fontSize: 16, fontWeight: 600,
    lineHeight: 1.9, color: G, padding: "4px 0 4px 12px",
    borderLeft: `3px solid ${GOLD}`,
  };
  if (secondary) return (
    <div>
      <div style={arStyle} dir="rtl" dangerouslySetInnerHTML={{ __html: secondary }} />
      <div style={enStyle} dir="ltr" dangerouslySetInnerHTML={{ __html: primary }} />
    </div>
  );
  if (split) return (
    <div>
      {split.ar && <div style={arStyle} dir="rtl">{split.ar}</div>}
      {split.en && <div style={enStyle} dir="ltr">{split.en}</div>}
    </div>
  );
  const isAr = /[؀-ۿ]/.test(primary);
  return (
    <div style={isAr ? arStyle : enStyle} dir={isAr ? "rtl" : "ltr"}
      dangerouslySetInnerHTML={{ __html: primary }} />
  );
};

const logActivity = async (uid: string, a: string, et: string, ei: string, m?: any) => {
  try { await supabase.from("activity_logs").insert({ user_id: uid, action: a, entity_type: et, entity_id: ei, metadata: m || null }); } catch (_) {}
};

function isImageUrl(url: string) {
  return [".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".bmp"].some(e => url.toLowerCase().split("?")[0].endsWith(e));
}

// ── Confidence Badge ─────────────────────────────────────────────
const ConfidenceSelector = ({ value, onChange }: { value: Confidence; onChange: (v: Confidence) => void }) => (
  <div style={{ display: "flex", gap: 6, alignItems: "center", marginTop: 14, padding: "10px 14px", background: "#f8fafb", borderRadius: 12, border: `1px solid ${BORDER}` }}>
    <span style={{ fontSize: 11, color: "#9ca3af", fontWeight: 600, marginRight: 4 }}>Confidence:</span>
    {([
      { v: "confident" as Confidence, label: "Confident", icon: <ThumbsUp style={{ width: 12, height: 12 }} />, color: CONFIDENT, bg: "#f0fff4" },
      { v: "unsure" as Confidence, label: "Unsure", icon: <Minus style={{ width: 12, height: 12 }} />, color: UNSURE, bg: "#fffbeb" },
      { v: "guessing" as Confidence, label: "Guessing", icon: <ThumbsDown style={{ width: 12, height: 12 }} />, color: GUESSING, bg: "#fff5f5" },
    ]).map(opt => {
      const sel = value === opt.v;
      return (
        <button key={opt.v} onClick={() => onChange(sel ? null : opt.v)}
          style={{ display: "flex", alignItems: "center", gap: 4, padding: "5px 10px", borderRadius: 20, border: `1.5px solid ${sel ? opt.color : BORDER}`, background: sel ? opt.bg : "transparent", color: sel ? opt.color : "#9ca3af", fontSize: 11, fontWeight: sel ? 700 : 500, cursor: "pointer", transition: "all .15s" }}>
          {opt.icon}{opt.label}
        </button>
      );
    })}
  </div>
);

// ── Matching Question ─────────────────────────────────────────────
const MatchingQuestion = ({ question, answer, onAnswer }: { question: any; answer: AnswerState; onAnswer: (text: string, data: any) => void }) => {
  const pairs: { left: string; right: string; id: string }[] = question.matching_pairs || [];
  // FIX: Stabilise shuffle with useState so it doesn't re-randomise on every render
  const [rights] = useState<string[]>(() => [...pairs.map(p => p.right)].sort(() => Math.random() - 0.5));
  const saved: Record<string, string> = answer?.data?.matches || {};
  const [matches, setMatches] = useState<Record<string, string>>(saved);
  const [dragging, setDragging] = useState<string | null>(null);

  const setMatch = (leftId: string, right: string) => {
    const newM = { ...matches, [leftId]: right };
    setMatches(newM);
    const text = pairs.map(p => `${p.left}=${newM[p.id] || ""}`).join("|");
    onAnswer(text, { matches: newM });
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <p style={{ fontSize: 12, color: "#9ca3af", marginBottom: 4 }}>Match each item on the left with the correct answer on the right.</p>
      {pairs.map((pair, i) => (
        <div key={pair.id} style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ flex: 1, padding: "12px 16px", background: "#f8fafb", borderRadius: 12, border: `1.5px solid ${BORDER}`, fontSize: 15, fontWeight: 600, color: G, fontFamily: "'Amiri',serif" }}>
            {String.fromCharCode(65 + i)}. {pair.left}
          </div>
          <div style={{ fontSize: 18, color: "#d1d5db" }}>→</div>
          <select value={matches[pair.id] || ""} onChange={e => setMatch(pair.id, e.target.value)}
            style={{ flex: 1, padding: "12px 16px", borderRadius: 12, border: `1.5px solid ${matches[pair.id] ? GM : BORDER}`, background: matches[pair.id] ? "#f0fff4" : "#f8fafb", fontSize: 15, color: G, outline: "none", cursor: "pointer" }}>
            <option value="">— Select —</option>
            {rights.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
      ))}
    </div>
  );
};

// ── Ordering Question ─────────────────────────────────────────────
const OrderingQuestion = ({ question, answer, onAnswer }: { question: any; answer: AnswerState; onAnswer: (text: string, data: any) => void }) => {
  const items: string[] = question.ordering_items || [];
  // FIX: Use lazy useState initialiser so shuffle only runs once, not on every render
  const [order, setOrder] = useState<string[]>(() => answer?.data?.order || [...items].sort(() => Math.random() - 0.5));
  const [dragIdx, setDragIdx] = useState<number | null>(null);

  const move = (from: number, to: number) => {
    const newOrder = [...order];
    const [item] = newOrder.splice(from, 1);
    newOrder.splice(to, 0, item);
    setOrder(newOrder);
    onAnswer(newOrder.join("|"), { order: newOrder });
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <p style={{ fontSize: 12, color: "#9ca3af", marginBottom: 4 }}>Drag or use arrows to arrange in the correct order.</p>
      {order.map((item, i) => (
        <div key={item} style={{ display: "flex", alignItems: "center", gap: 8, padding: "12px 16px", background: "#f8fafb", borderRadius: 12, border: `1.5px solid ${BORDER}`, cursor: "grab" }}>
          <div style={{ width: 28, height: 28, borderRadius: 8, background: GM, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 800, flexShrink: 0 }}>{i + 1}</div>
          <div style={{ flex: 1, fontSize: 15, fontWeight: 600, color: G, fontFamily: "'Amiri',serif" }}>{item}</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            <button onClick={() => i > 0 && move(i, i - 1)} disabled={i === 0}
              style={{ width: 24, height: 22, borderRadius: 6, border: `1px solid ${BORDER}`, background: "#fff", color: i === 0 ? "#d1d5db" : G, cursor: i === 0 ? "not-allowed" : "pointer", fontSize: 12, display: "flex", alignItems: "center", justifyContent: "center" }}>▲</button>
            <button onClick={() => i < order.length - 1 && move(i, i + 1)} disabled={i === order.length - 1}
              style={{ width: 24, height: 22, borderRadius: 6, border: `1px solid ${BORDER}`, background: "#fff", color: i === order.length - 1 ? "#d1d5db" : G, cursor: i === order.length - 1 ? "not-allowed" : "pointer", fontSize: 12, display: "flex", alignItems: "center", justifyContent: "center" }}>▼</button>
          </div>
        </div>
      ))}
    </div>
  );
};

// ── Multi-Select Question ─────────────────────────────────────────
const MultiSelectQuestion = ({ question, answer, onAnswer }: { question: any; answer: AnswerState; onAnswer: (text: string, data: any) => void }) => {
  const opts: any[] = question.options || [];
  const selected: string[] = answer?.data?.selected || (answer?.text ? answer.text.split(",") : []);
  const [sel, setSel] = useState<string[]>(selected);

  const toggle = (id: string) => {
    const newSel = sel.includes(id) ? sel.filter(s => s !== id) : [...sel, id];
    setSel(newSel);
    onAnswer(newSel.join(","), { selected: newSel });
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <p style={{ fontSize: 12, color: "#9ca3af", marginBottom: 4 }}>Select all that apply. Multiple answers may be correct.</p>
      {opts.map((opt, idx) => {
        const isSel = sel.includes(opt.id);
        return (
          <div key={opt.id} onClick={() => toggle(opt.id)}
            style={{ display: "flex", alignItems: "center", gap: 14, padding: "14px 18px", borderRadius: 14, cursor: "pointer", transition: "all .15s", background: isSel ? "#f0fff4" : "#f8fafb", border: `2px solid ${isSel ? "#22c55e" : BORDER}`, boxShadow: isSel ? "0 2px 12px rgba(34,197,94,.18)" : "none" }}>
            <div style={{ width: 22, height: 22, borderRadius: 6, border: `2px solid ${isSel ? "#22c55e" : BORDER}`, background: isSel ? "#22c55e" : "#fff", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              {isSel && <span style={{ color: "#fff", fontSize: 13, fontWeight: 900 }}>✓</span>}
            </div>
            <div style={{ width: 32, height: 32, borderRadius: "50%", background: isSel ? GM : "rgba(15,45,31,.08)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 900, color: isSel ? "#fff" : G, flexShrink: 0 }}>
              {String.fromCharCode(65 + idx)}
            </div>
            {opt.image_url && <img src={opt.image_url} alt="" style={{ height: 56, borderRadius: 8, objectFit: "contain" }} />}
            <div style={{ flex: 1 }}>
              {opt.text_ar && opt.text_ar !== opt.text && <div dir="rtl" style={{ fontSize: 17, fontFamily: "'Amiri Quran',serif", color: G, lineHeight: 2.1, marginBottom: 2 }} dangerouslySetInnerHTML={{ __html: sanitizeHtml(opt.text_ar) }} />}
              {opt.text && <div dir="ltr" style={{ fontSize: 16, fontWeight: isSel ? 700 : 500, color: isSel ? G : "#374151", fontFamily: "'Amiri',serif", lineHeight: 1.9 }} dangerouslySetInnerHTML={{ __html: sanitizeHtml(opt.text) }} />}
            </div>
          </div>
        );
      })}
    </div>
  );
};

// ── Reading Comprehension ─────────────────────────────────────────
const ReadingQuestion = ({ question, answer, onAnswer }: { question: any; answer: AnswerState; onAnswer: (text: string, data: any) => void }) => {
  const passage: string = question.reading_passage || "";
  const [highlighted, setHighlighted] = useState<string>("");

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      {passage && (
        <div style={{ padding: "16px 20px", background: "#fffbeb", borderRadius: 14, border: `1px solid ${GOLD}44`, borderLeft: `4px solid ${GOLD}` }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: GOLD, letterSpacing: 1, marginBottom: 8 }}>📖 READING PASSAGE</div>
          <div dir="auto" style={{ fontSize: 16, lineHeight: 2, color: G, fontFamily: "'Amiri',serif" }} dangerouslySetInnerHTML={{ __html: sanitizeHtml(passage) }} />
        </div>
      )}
      <textarea dir="auto" rows={5} placeholder="Write your answer based on the passage above…"
        value={answer?.text || ""} onChange={e => onAnswer(e.target.value, answer?.data)}
        style={{ width: "100%", padding: "15px 16px", borderRadius: 14, border: `2px solid ${BORDER}`, fontSize: 16, outline: "none", color: G, background: "#f8fafb", resize: "vertical", lineHeight: 1.9, fontFamily: "'Amiri',serif", transition: "border .15s" }}
        onFocus={e => (e.target.style.borderColor = GM)} onBlur={e => (e.target.style.borderColor = BORDER)} />
    </div>
  );
};

// ══════════════════════════════════════════════════════════════════
const ExamTaking = () => {
  const { attemptId } = useParams<{ attemptId: string }>();
  const { t, language } = useLanguage();
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  const [exam, setExam] = useState<any>(null);
  const [questions, setQuestions] = useState<any[]>([]);
  const [answers, setAnswers] = useState<Record<string, AnswerState>>({});
  const [currentIdx, setIdx] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submissionResult, setSR] = useState<any>(null);
  const [tabSwitches, setTabSw] = useState(0);
  const [phase, setPhase] = useState<"exam" | "review">("exam");
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [saving, setSaving] = useState(false);
  const [showNav, setShowNav] = useState(false);
  const [deductedPoints, setDeducted] = useState(0);
  const [showProcLog, setShowProcLog] = useState(false);
  const [showKeyboardHelp, setShowKeyboardHelp] = useState(false);
  const [questionStartTime, setQuestionStartTime] = useState<Record<string, number>>({});
  const [timePerQuestion, setTimePerQuestion] = useState<Record<string, number>>({});

  const qScrollRef = useRef<HTMLDivElement>(null);
  const qCardRef = useRef<HTMLDivElement>(null);


  const submittedRef = useRef(false);
  const answersRef = useRef(answers);
  const questionsRef = useRef(questions);
  const examRef = useRef(exam);
  const submitRef = useRef<() => Promise<void>>(() => Promise.resolve());
  const extraTimeRef = useRef(0); // extra_time_minutes an admin has granted, live-tracked
  const startedAtRef = useRef<number>(0);

  useEffect(() => { answersRef.current = answers; }, [answers]);
  useEffect(() => { questionsRef.current = questions; }, [questions]);
  useEffect(() => { examRef.current = exam; }, [exam]);

  // Track time per question
  useEffect(() => {
    if (!questions[currentIdx]) return;
    const qId = questions[currentIdx].id;
    const now = Date.now();
    setQuestionStartTime(p => ({ ...p, [qId]: now }));
    return () => {
      setTimePerQuestion(p => ({
        ...p,
        [qId]: (p[qId] || 0) + Math.round((Date.now() - (questionStartTime[qId] || now)) / 1000)
      }));
    };
  }, [currentIdx]);

  // Screen capture on question navigation (skip the very first question —
  // there's no "move" yet, and proc isn't initialized on first render).
  // Declared before useProctoring() below and kept in sync via the effect
  // right after it, so this effect (which runs on every currentIdx change)
  // always calls whatever the latest proc instance's captureScreenshot is.
  const procRef = useRef<{ captureScreenshot?: (trigger?: string) => void }>({});
  const prevIdxRef = useRef<number | null>(null);
  useEffect(() => {
    if (prevIdxRef.current !== null && prevIdxRef.current !== currentIdx && procRef.current?.captureScreenshot) {
      procRef.current.captureScreenshot("question_change");
    }
    prevIdxRef.current = currentIdx;
  }, [currentIdx]);

  const procEnabled = exam?.proctoring_enabled === true;
  const proc = useProctoring({
    attemptId: attemptId || "", userId: user?.id || "",
    examId: exam?.id,
    proctoring_enabled: exam?.proctoring_enabled,
    fullscreen_required: exam?.fullscreen_required,
    tab_switch_limit: exam?.tab_switch_limit,
    max_warnings: exam?.max_warnings,
    auto_submit_on_violation: exam?.auto_submit_on_violation,
    screenshot_interval_seconds: exam?.screenshot_interval_seconds,
    screen_capture_interval_seconds: exam?.screen_capture_interval_seconds ?? 5,
    webcam_required: exam?.webcam_required,
    record_audio: exam?.record_audio,
  }, procEnabled && !submitted && !loading, () => { if (!submittedRef.current) submitRef.current(); });

  useEffect(() => { procRef.current = proc; }, [proc]);

  useEffect(() => {
    if (proc.cameraReady && (proc as any).getStream) {
      setTimeout(() => {
        const stream = (proc as any).getStream();
        if (!stream) return;
        const el = document.getElementById("proctor-display-video") as HTMLVideoElement;
        if (el && !el.srcObject) { el.srcObject = stream; el.play().catch(() => {}); }
      }, 600);
    }
  }, [proc.cameraReady]);

  const handlePointDeduction = useCallback((pts: number) => {
    setDeducted(p => p + pts);
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    if (submitted || phase === "review") return;
    const handler = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement) return;
      if (e.key === "ArrowRight" || e.key === "ArrowDown") { e.preventDefault(); setIdx(p => Math.min(questionsRef.current.length - 1, p + 1)); }
      if (e.key === "ArrowLeft" || e.key === "ArrowUp") { e.preventDefault(); setIdx(p => Math.max(0, p - 1)); }
      if (e.key === "f" || e.key === "F") {
        const q = questionsRef.current[currentIdx];
        if (q) toggleFlag(q.id);
      }
      if (e.key === "1") setConfidence(questionsRef.current[currentIdx]?.id, "confident");
      if (e.key === "2") setConfidence(questionsRef.current[currentIdx]?.id, "unsure");
      if (e.key === "3") setConfidence(questionsRef.current[currentIdx]?.id, "guessing");
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [submitted, phase, currentIdx]);

  // Block right-click & copy
  useEffect(() => {
    if (submitted) return;
    const noRC = (e: MouseEvent) => e.preventDefault();
    const noCP = (e: ClipboardEvent) => e.preventDefault();
    const noKey = (e: KeyboardEvent) => { if ((e.ctrlKey || e.metaKey) && ["c", "v", "x", "a"].includes(e.key.toLowerCase())) e.preventDefault(); };
    document.addEventListener("contextmenu", noRC);
    document.addEventListener("copy", noCP); document.addEventListener("cut", noCP); document.addEventListener("paste", noCP);
    document.addEventListener("keydown", noKey);
    return () => {
      document.removeEventListener("contextmenu", noRC); document.removeEventListener("copy", noCP);
      document.removeEventListener("cut", noCP); document.removeEventListener("paste", noCP);
      document.removeEventListener("keydown", noKey);
    };
  }, [submitted]);

  // Load exam — wrapped in try/catch so loading always clears
  useEffect(() => {
    if (!attemptId || !user) return;
    (async () => {
      try {
        const { data: ad, error: ae } = await supabase.from("exam_attempts").select("*,exams(*)").eq("id", attemptId).single();
        if (ae || !ad || ad.user_id !== user.id) { navigate("/student/exams"); return; }
        if (ad.status !== "in_progress") {
          setSubmitted(true); setExam(ad.exams);
          setSR({ status: ad.status, score: ad.score, totalPoints: ad.total_points, percentage: ad.percentage, passed: ad.passed });
          setLoading(false); return;
        }
        setExam(ad.exams);
        startedAtRef.current = new Date(ad.started_at).getTime();
        extraTimeRef.current = ad.extra_time_minutes || 0;
        setTimeLeft(Math.max(0, ((ad.exams.time_limit_minutes || 60) + extraTimeRef.current) * 60 - Math.floor((Date.now() - startedAtRef.current) / 1000)));
        setTabSw(ad.tab_switches || 0);
        logActivity(user.id, "exam_started", "exam_attempt", attemptId, { exam_id: ad.exam_id });

        // Try RPC first, fall back to a direct query if it errors OR returns
        // nothing. (supabase.rpc() resolves with { error } instead of throwing,
        // so the old try/catch fallback never ran and students saw a blank exam.)
        let ql: any[] = [];
        let rpcFailed = false;
        try {
          const { data: qs, error: qe } = await supabase.rpc("get_exam_questions_for_student", { _exam_id: ad.exam_id });
          if (qe) { rpcFailed = true; console.error("get_exam_questions_for_student failed:", qe); }
          ql = (qs as any[]) || [];
        } catch (rpcErr) {
          rpcFailed = true;
          console.error("get_exam_questions_for_student threw:", rpcErr);
        }
        if (rpcFailed || ql.length === 0) {
          // Fall back to direct query, applying the same question_group
          // "name::pick=N" draw logic as the RPC so students never see the
          // full question bank here either.
          const { data: qs2, error: qe2 } = await supabase
            .from("exam_questions")
            .select("*")
            .eq("exam_id", ad.exam_id)
            .order("sort_order");
          if (qe2) console.error("exam_questions fallback failed:", qe2);
          const all = qs2 || [];
          const groups: Record<string, { pick: number; items: any[] }> = {};
          const ungrouped: any[] = [];
          all.forEach((q: any) => {
            if (!q.question_group) { ungrouped.push(q); return; }
            const m = String(q.question_group).match(/^(.*?)(?:::pick=(\d+))?$/);
            const key = m?.[1] || q.question_group;
            const pick = m?.[2] ? parseInt(m[2], 10) : 1;
            if (!groups[key]) groups[key] = { pick, items: [] };
            groups[key].items.push(q);
          });
          const picked: any[] = [...ungrouped];
          Object.values(groups).forEach(({ pick, items }) => {
            const shuffled = seededShuffle(items, `${user.id}:${ad.exam_id}`);
            picked.push(...shuffled.slice(0, pick));
          });
          picked.sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));
          if (picked.length) ql = picked;
        }
        // FIX: refresh signed media_url for audio questions (signed URLs expire after 1h)
        ql = await Promise.all(ql.map(async (q: any) => {
          if (q.media_url && q.media_url.includes("/storage/v1/object/sign/")) {
            // Extract bucket and path from signed URL
            const match = q.media_url.match(/\/storage\/v1\/object\/sign\/([^/]+)\/(.+?)\?/);
            if (match) {
              const [, bucket, path] = match;
              const { data: fresh } = await storageSupabase.storage.from(bucket).createSignedUrl(decodeURIComponent(path), 7200);
              return { ...q, media_url: fresh?.signedUrl || q.media_url };
            }
          }
          return q;
        }));
        if (ad.exams.randomize_questions) ql = ql.sort(() => Math.random() - 0.5);
        if (ad.exams.randomize_answers) {
          ql = ql.map((q: any) => {
            if ((q.question_type === "mcq" || q.question_type === "image_mcq" || q.question_type === "comprehension") && Array.isArray(q.options)) {
              return { ...q, options: seededShuffle(q.options, `${user.id}:${q.id}`) };
            }
            return q;
          });
        }
        setQuestions(ql);

        const { data: ea } = await supabase.from("exam_answers").select("*").eq("attempt_id", attemptId);
        const am: Record<string, AnswerState> = {};
        (ea || []).forEach((a: any) => { am[a.question_id] = { text: a.answer_text || "", data: a.answer_data, flagged: a.is_flagged || false, confidence: a.answer_data?.confidence || null }; });
        setAnswers(am);
      } catch (err) {
        console.error("Exam load error:", err);
      } finally {
        setLoading(false); // ALWAYS clear loading
      }
    })();
  }, [attemptId, user]);

  // Timer
  useEffect(() => {
    if (submitted || loading || !exam) return;
    if (timeLeft <= 0) { if (!submittedRef.current) submitRef.current(); return; }
    const iv = setInterval(() => setTimeLeft(tt => { const n = Math.max(0, tt - 1); if (n === 0 && !submittedRef.current) setTimeout(() => submitRef.current(), 0); return n; }), 1000);
    return () => clearInterval(iv);
  }, [timeLeft, loading, submitted, exam]);

  // Live extra-time grants — an admin can add minutes mid-exam from the Live
  // Monitor. Listen for it in real time so the countdown updates immediately
  // instead of the student having to refresh.
  useEffect(() => {
    if (submitted || !attemptId) return;
    const channel = supabase
      .channel(`exam-attempt-extra-time-${attemptId}`)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "exam_attempts", filter: `id=eq.${attemptId}` }, (payload: any) => {
        const newExtra = payload.new?.extra_time_minutes ?? extraTimeRef.current;
        if (newExtra !== extraTimeRef.current) {
          const deltaMin = newExtra - extraTimeRef.current;
          extraTimeRef.current = newExtra;
          if (deltaMin > 0) {
            setTimeLeft(t => t + deltaMin * 60);
            toast({ title: `⏱️ ${t("Extra time added","تمت إضافة وقت إضافي")}`, description: `+${deltaMin} ${t("minutes","دقيقة")}` });
          }
        }
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [attemptId, submitted]);

  // Heartbeat — lets the admin Live Monitor tell "online now" from "idle/
  // disconnected". Also reports which question the student is currently on.
  useEffect(() => {
    if (submitted || !attemptId) return;
    const beat = () => supabase.from("exam_attempts").update({
      last_activity_at: new Date().toISOString(),
      current_question_index: currentIdx,
    }).eq("id", attemptId);
    beat();
    const iv = setInterval(beat, 15000);
    return () => clearInterval(iv);
  }, [attemptId, submitted, currentIdx]);

  // Tab switch
  useEffect(() => {
    if (submitted) return;
    const h = () => { if (document.hidden) setTabSw(p => { const n = p + 1; supabase.from("exam_attempts").update({ tab_switches: n }).eq("id", attemptId!); if (n >= 3) toast({ title: "⚠️ Warning!", description: "Tab switching detected!", variant: "destructive" }); return n; }); };
    document.addEventListener("visibilitychange", h); return () => document.removeEventListener("visibilitychange", h);
  }, [attemptId, submitted]);

  // Auto-save every 30s
  useEffect(() => {
    if (submitted) return;
    const iv = setInterval(async () => { await saveAnswers(true); }, 30000); return () => clearInterval(iv);
  }, [answers, submitted]);

  // FIX BUG 13: Add pagehide to save answers when tab is closed/navigated away
  const saveAnswersRef = useRef<((silent?: boolean) => Promise<void>) | null>(null);
  useEffect(() => {
    if (submitted) return;
    const h = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = ""; };
    const ph = () => { saveAnswersRef.current?.(true); };
    window.addEventListener("beforeunload", h);
    window.addEventListener("pagehide", ph);
    return () => {
      window.removeEventListener("beforeunload", h);
      window.removeEventListener("pagehide", ph);
    };
  }, [submitted]);

  // Reload safety net: never let an SW update force-reload mid-exam.
  useEffect(() => {
    if (loading || submitted) return;
    lockReload("exam-taking");
    return () => unlockReload("exam-taking");
  }, [loading, submitted]);

  // Native screenshot / screen-recording block for the duration of the
  // attempt (Android FLAG_SECURE + iOS app-switcher cover). No-op on web.
  useEffect(() => {
    if (loading || submitted) return;
    enableExamPrivacyScreen();
    return () => { disableExamPrivacyScreen(); };
  }, [loading, submitted]);

  /* Persist answer rows. Uses a single upsert, but if the DB has no
     (attempt_id, question_id) unique index the upsert errors out and every
     answer would be silently lost — so fall back to a per-row
     update-then-insert. Returns true when everything saved. */
  const persistAnswers = async (rows: any[]): Promise<boolean> => {
    if (!rows.length) return true;
    const { error } = await supabase.from("exam_answers").upsert(rows, { onConflict: "attempt_id,question_id" });
    if (!error) return true;
    console.error("answer upsert failed, falling back to per-row save:", error);
    let ok = true;
    for (const row of rows) {
      const { data: upd, error: ue } = await supabase.from("exam_answers")
        .update(row).eq("attempt_id", row.attempt_id).eq("question_id", row.question_id).select("id");
      if (ue) { ok = false; console.error("answer update failed:", ue); continue; }
      if (!upd || upd.length === 0) {
        const { error: ie } = await supabase.from("exam_answers").insert(row);
        if (ie) { ok = false; console.error("answer insert failed:", ie); }
      }
    }
    return ok;
  };

  const saveAnswers = async (silent = false) => {
    if (!attemptId || submittedRef.current) return;
    if (!silent) setSaving(true);
    const rows = Object.entries(answersRef.current).map(([qId, ans]) => ({
      attempt_id: attemptId,
      question_id: qId,
      answer_text: ans.text,
      answer_data: { ...ans.data, confidence: ans.confidence, timeSpent: timePerQuestion[qId] || 0 },
      is_flagged: ans.flagged,
    }));
    const ok = await persistAnswers(rows);
    if (!ok && !silent) toast({ title: t("Could not save answers", "لم يتم حفظ الإجابات"), description: t("Check your connection — we'll keep retrying.", "تحقق من اتصالك — سنحاول مرة أخرى."), variant: "destructive" });
    if (ok) setLastSaved(new Date());
    if (!silent) setSaving(false);
  };

  const setAnswer = (qId: string, text: string, data?: any) => {
    if (submitted) return;
    setAnswers(p => ({ ...p, [qId]: { ...p[qId], text, data: data ?? p[qId]?.data, flagged: p[qId]?.flagged || false, confidence: p[qId]?.confidence || null } }));
  };
  const toggleFlag = (qId: string) => {
    if (submitted) return;
    setAnswers(p => ({ ...p, [qId]: { ...p[qId], text: p[qId]?.text || "", data: p[qId]?.data, flagged: !p[qId]?.flagged, confidence: p[qId]?.confidence || null } }));
  };
  const setConfidence = (qId: string | undefined, c: Confidence) => {
    if (!qId || submitted) return;
    setAnswers(p => ({ ...p, [qId]: { ...p[qId], text: p[qId]?.text || "", data: p[qId]?.data, flagged: p[qId]?.flagged || false, confidence: p[qId]?.confidence === c ? null : c } }));
  };

  const handleSubmit = useCallback(async () => {
    if (submittedRef.current) return;
    submittedRef.current = true; setSubmitting(true); setPhase("exam");
    if (attemptId) {
      const rows = Object.entries(answersRef.current)
        .filter(([, ans]) => ans.text || ans.data)
        .map(([qId, ans]) => ({
          attempt_id: attemptId,
          question_id: qId,
          answer_text: ans.text || null,
          answer_data: ans.data ? { ...ans.data, confidence: ans.confidence, timeSpent: timePerQuestion[qId] || 0 } : null,
          is_flagged: ans.flagged || false,
        }));
      // Never grade before the answers are safely stored — grading a partially
      // saved attempt would score the student zero on saved-but-missing answers.
      let saved = await persistAnswers(rows);
      if (!saved) saved = await persistAnswers(rows);
      if (!saved) {
        toast({ title: t("Could not save your answers", "لم يتم حفظ إجاباتك"), description: t("Your exam was NOT submitted. Check your connection and try again.", "لم يتم تقديم امتحانك. تحقق من اتصالك وحاول مرة أخرى."), variant: "destructive" });
        submittedRef.current = false; setSubmitting(false); return;
      }
    }
    const { data: gr, error: ge } = await supabase.rpc("grade_exam_attempt", { _attempt_id: attemptId! });
    if (ge || !gr) {
      console.error("grade_exam_attempt failed:", ge);
      // The RPC only succeeds while status is still 'in_progress'. If it's
      // already submitted/graded — e.g. a prior call actually succeeded
      // server-side but the response never made it back over a flaky
      // connection, or an auto-submit fired in the background — retrying
      // hits this same guard forever with no way out for the student.
      // Check the attempt's real status before treating this as a failure.
      const { data: recheck } = await supabase.from("exam_attempts")
        .select("status,score,total_points,percentage,passed").eq("id", attemptId!).single();
      if (recheck && recheck.status !== "in_progress") {
        setSR({ status: recheck.status, score: recheck.score, totalPoints: recheck.total_points, percentage: recheck.percentage, passed: recheck.passed });
        setSubmitted(true); setSubmitting(false); toast({ title: "✅ " + t("Exam Submitted!", "تم تقديم الامتحان!") });
        return;
      }
      toast({ title: t("Submission failed", "فشل التقديم"), description: ge?.message || t("Please try again.", "يرجى المحاولة مرة أخرى."), variant: "destructive" });
      submittedRef.current = false; setSubmitting(false); return;
    }
    const r = (Array.isArray(gr) ? gr[0] : gr) as any;
    setSR({ status: r?.status || "submitted", score: r?.score, totalPoints: r?.total_points, percentage: r?.percentage, passed: r?.passed });
    setSubmitted(true); setSubmitting(false); toast({ title: "✅ " + t("Exam Submitted!", "تم تقديم الامتحان!") });
    if (user) logActivity(user.id, "exam_submitted", "exam_attempt", attemptId!, { score: r?.score, percentage: Math.round(r?.percentage || 0) });
  }, [attemptId, user, timePerQuestion]);

  // Keep saveAnswersRef current so pagehide can call the latest version
  useEffect(() => { saveAnswersRef.current = saveAnswers; });
  useEffect(() => { submitRef.current = handleSubmit; }, [handleSubmit]);

  const answeredCount = Object.keys(answers).filter(k => answers[k]?.text).length;
  const flaggedCount = Object.values(answers).filter(a => a?.flagged).length;
  const confidentCount = Object.values(answers).filter(a => a?.confidence === "confident").length;
  const progressPct = questions.length > 0 ? (answeredCount / questions.length) * 100 : 0;
  const isTimeCrit = timeLeft < 300;
  const isTimeWarn = timeLeft < 600 && timeLeft >= 300;
  const fmt = (s: number) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;
  const timerColor = isTimeCrit ? "#ef4444" : isTimeWarn ? "#f59e0b" : "#22c55e";
  const timerBg = isTimeCrit ? "rgba(239,68,68,.15)" : isTimeWarn ? "rgba(245,158,11,.15)" : "rgba(34,197,94,.12)";
  const q = questions[currentIdx];

  // ── SUBMITTED ──
  if (submitted && !loading) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(135deg,#f8fafb,#f0f4f8)", fontFamily: "'Cairo',sans-serif", padding: 20 }}>
      <div style={{ background: "#fff", borderRadius: 24, padding: "48px 36px", maxWidth: 480, width: "100%", textAlign: "center", boxShadow: "0 12px 48px rgba(0,0,0,.1)" }}>
        <div style={{ width: 96, height: 96, borderRadius: "50%", background: submissionResult?.passed ? "linear-gradient(135deg,#f0fff4,#dcfce7)" : submissionResult?.status === "submitted" ? "linear-gradient(135deg,#fefce8,#fef9c3)" : "linear-gradient(135deg,#fff5f5,#fee2e2)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px", boxShadow: submissionResult?.passed ? "0 4px 20px rgba(34,197,94,.25)" : "none" }}>
          {submissionResult?.status === "graded" ? submissionResult?.passed ? <CheckCircle2 style={{ width: 48, height: 48, color: "#22c55e" }} /> : <AlertTriangle style={{ width: 48, height: 48, color: "#ef4444" }} /> : <Lock style={{ width: 48, height: 48, color: GOLD }} />}
        </div>
        <h2 style={{ fontSize: 26, fontWeight: 900, color: G, marginBottom: 8 }}>
          {submissionResult?.status === "graded" ? submissionResult?.passed ? t("Exam Passed! 🎉", "نجحت في الامتحان! 🎉") : t("Not Passed", "لم تجتز الامتحان") : t("Exam Submitted", "تم تقديم الامتحان")}
        </h2>
        {submissionResult?.status === "graded" && (
          <>
            <div style={{ fontSize: 64, fontWeight: 900, color: submissionResult.passed ? "#22c55e" : "#ef4444", marginBottom: 4, lineHeight: 1 }}>{Math.round(submissionResult.percentage || 0)}%</div>
            <div style={{ fontSize: 15, color: "#7a9e88", marginBottom: 20 }}>{submissionResult.score}/{submissionResult.totalPoints} {t("points", "نقاط")}</div>
            {deductedPoints > 0 && <div style={{ fontSize: 13, color: "#ef4444", marginBottom: 16, padding: "8px 16px", background: "#fff5f5", borderRadius: 10 }}>−{deductedPoints} pts deducted for violations</div>}
          </>
        )}
        {submissionResult?.status === "submitted" && (
          <div style={{ background: "#fffbeb", borderRadius: 12, padding: 16, marginBottom: 20, border: `1px solid ${GOLD}44` }}>
            <p style={{ fontSize: 14, color: "#7a9e88", lineHeight: 1.7, margin: 0 }}>{t("Your exam has been submitted and is awaiting grading by your teacher.", "تم تقديم امتحانك وبانتظار تصحيح المعلم.")}</p>
          </div>
        )}
        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={() => navigate("/student/exams")} style={{ flex: 1, padding: "14px 0", borderRadius: 14, background: "#f8fafb", border: `1.5px solid ${BORDER}`, color: G, fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'Cairo',sans-serif" }}>{t("Back to Exams", "العودة")}</button>
          <button onClick={() => navigate(`/student/results/${attemptId}`)} style={{ flex: 1, padding: "14px 0", borderRadius: 14, background: G, border: "none", color: "#fff", fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'Cairo',sans-serif" }}>{t("View Results", "عرض النتيجة")}</button>
        </div>
      </div>
    </div>
  );

  if (loading) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#f8fafb" }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ width: 52, height: 52, border: `4px solid ${G}`, borderTopColor: "transparent", borderRadius: "50%", animation: "spin .8s linear infinite", margin: "0 auto 16px" }} />
        <p style={{ color: "#7a9e88", fontSize: 14, fontFamily: "'Cairo',sans-serif" }}>{t("Loading exam…", "جارٍ تحميل الامتحان…")}</p>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  // ── REVIEW PHASE ──
  if (phase === "review") return (
    <div style={{ height: "100dvh", display: "flex", flexDirection: "column", background: "#f5f7fa", fontFamily: "'Cairo',sans-serif", overflow: "hidden" }}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      {procEnabled && !submitted && (
        <ProctoringOverlay cameraReady={proc.cameraReady} faceDetected={proc.faceDetected}
          integrityScore={proc.integrityScore} suspicionLevel={proc.suspicionLevel}
          strikes={proc.strikes} maxStrikes={proc.maxStrikes} violations={proc.violations}
          lastWarningType={proc.lastWarningType} tooClose={(proc as any).tooClose} audioMonitoring={proc.audioMonitoring}
          recentViolations={(proc as any).recentViolations} getStream={(proc as any).getStream}
          attemptId={attemptId || ""} onPointDeduction={handlePointDeduction} />
      )}
      <ExamFocusGuard
        active={!submitted}
        language={language === "ar" ? "ar" : "en"}
        onViolation={(awaySeconds) => {
          if (procEnabled) (proc as any).logViolation?.("tab_switch", 2, `Locked out — away ${awaySeconds}s`);
        }}
      />
      <div style={{ background: G, padding: "14px 16px", display: "flex", alignItems: "center", gap: 12, flexShrink: 0 }}>
        <button onClick={() => setPhase("exam")} style={{ background: "rgba(255,255,255,.15)", border: "none", color: "#fff", borderRadius: 10, padding: "7px 14px", fontSize: 13, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 5, fontFamily: "'Cairo',sans-serif" }}>
          <ChevronLeft style={{ width: 14, height: 14 }} />{t("Back", "عودة")}
        </button>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: "#fff" }}>{t("Review Your Answers", "مراجعة إجاباتك")}</div>
          <div style={{ fontSize: 11, color: "rgba(255,255,255,.6)" }}>{answeredCount}/{questions.length} answered · {flaggedCount} flagged · {confidentCount} confident</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 5, background: timerBg, borderRadius: 20, padding: "4px 12px" }}>
          <Clock style={{ width: 12, height: 12, color: timerColor }} /><span style={{ fontSize: 13, fontWeight: 900, color: timerColor, fontVariantNumeric: "tabular-nums" }}>{fmt(timeLeft)}</span>
        </div>
      </div>
      <div style={{ flex: 1, overflow: "auto", padding: 16 }}>
        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10, marginBottom: 16 }}>
          {[
            { l: t("Answered", "مُجاب"), v: answeredCount, c: "#22c55e", bg: "#f0fff4" },
            { l: t("Flagged", "مُعلّم"), v: flaggedCount, c: GOLD, bg: "#fffbeb" },
            { l: t("Unanswered", "غير مُجاب"), v: questions.length - answeredCount, c: "#ef4444", bg: "#fff5f5" },
            { l: t("Confident", "واثق"), v: confidentCount, c: "#6366f1", bg: "#eef2ff" },
          ].map((s, i) => (
            <div key={i} style={{ background: s.bg, borderRadius: 12, padding: "12px 8px", textAlign: "center", border: `1px solid ${s.c}22` }}>
              <div style={{ fontSize: 26, fontWeight: 900, color: s.c }}>{s.v}</div>
              <div style={{ fontSize: 10, color: "#7a9e88" }}>{s.l}</div>
            </div>
          ))}
        </div>

        {/* Question grid */}
        <div style={{ background: "#fff", borderRadius: 16, padding: 16, marginBottom: 14, border: `1px solid ${BORDER}` }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: G, marginBottom: 12 }}>{t("All Questions", "جميع الأسئلة")}</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(48px,1fr))", gap: 6 }}>
            {questions.map((qq, i) => {
              const a = answers[qq.id];
              const confColor = a?.confidence === "confident" ? "#6366f1" : a?.confidence === "unsure" ? GOLD : a?.confidence === "guessing" ? "#ef4444" : null;
              return (
                <button key={qq.id} onClick={() => { setIdx(i); setPhase("exam"); }}
                  style={{ height: 48, borderRadius: 10, border: "none", fontSize: 12, fontWeight: 700, cursor: "pointer", position: "relative", flexDirection: "column", display: "flex", alignItems: "center", justifyContent: "center", gap: 2,
                    background: a?.flagged ? "#fffbeb" : a?.text ? "#f0fff4" : "#f8fafb",
                    color: a?.flagged ? GOLD : a?.text ? "#22c55e" : "#7a9e88",
                    outline: i === currentIdx ? `2px solid ${G}` : "" }}>
                  {i + 1}
                  {confColor && <div style={{ width: 6, height: 6, borderRadius: "50%", background: confColor }} />}
                  {a?.flagged && <span style={{ position: "absolute", top: 2, right: 3, fontSize: 8 }}>🚩</span>}
                </button>
              );
            })}
          </div>
        </div>

        {/* Warnings */}
        {questions.length - answeredCount > 0 && (
          <div style={{ background: "#fff5f5", borderRadius: 12, padding: "12px 16px", marginBottom: 12, display: "flex", alignItems: "center", gap: 10, border: "1px solid #fca5a5" }}>
            <AlertTriangle style={{ width: 17, height: 17, color: "#ef4444", flexShrink: 0 }} />
            <span style={{ fontSize: 13, fontWeight: 700, color: "#ef4444" }}>{questions.length - answeredCount} {t("questions unanswered — are you sure you want to submit?", "أسئلة لم تُجب عليها — هل أنت متأكد من التقديم؟")}</span>
          </div>
        )}
        {deductedPoints > 0 && (
          <div style={{ background: "#fff5f5", borderRadius: 12, padding: "12px 16px", marginBottom: 12, display: "flex", alignItems: "center", gap: 10, border: "1px solid #fca5a5" }}>
            <AlertTriangle style={{ width: 17, height: 17, color: "#ef4444", flexShrink: 0 }} />
            <span style={{ fontSize: 13, fontWeight: 700, color: "#ef4444" }}>−{deductedPoints} {t("points deducted for violations", "نقاط خُصمت بسبب المخالفات")}</span>
          </div>
        )}
        {Object.values(answers).some((a: any) => a?.data?.uploadFailed) && (
          <div style={{ background: "#fff5f5", borderRadius: 12, padding: "12px 16px", marginBottom: 12, display: "flex", alignItems: "center", gap: 10, border: "1px solid #fca5a5" }}>
            <AlertTriangle style={{ width: 17, height: 17, color: "#ef4444", flexShrink: 0 }} />
            <span style={{ fontSize: 13, fontWeight: 700, color: "#ef4444" }}>{t("One or more audio recordings didn't upload — go back and re-record before submitting, or it will be lost.", "لم يتم رفع تسجيل صوتي واحد أو أكثر — يرجى الرجوع وإعادة التسجيل قبل التقديم، وإلا سيُفقد.")}</span>
          </div>
        )}

        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={() => setPhase("exam")} style={{ flex: 1, padding: "14px 0", borderRadius: 12, background: "#f8fafb", border: `1.5px solid ${BORDER}`, color: G, fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'Cairo',sans-serif" }}>← {t("Continue Exam", "متابعة الامتحان")}</button>
          <button onClick={() => {
            const hasFailedAudio = Object.values(answersRef.current).some((a: any) => a?.data?.uploadFailed);
            if (hasFailedAudio) {
              toast({ title: t("Fix your recording first", "أصلح تسجيلك أولاً"), description: t("Go back and re-record the failed audio answer before submitting.", "يرجى الرجوع وإعادة تسجيل الإجابة الصوتية الفاشلة قبل التقديم."), variant: "destructive" });
              return;
            }
            handleSubmit();
          }} disabled={submitting}
            style={{ flex: 1, padding: "14px 0", borderRadius: 12, background: submitting ? "#9ca3af" : "#dc2626", border: "none", color: "#fff", fontSize: 14, fontWeight: 700, cursor: submitting ? "not-allowed" : "pointer", fontFamily: "'Cairo',sans-serif" }}>
            {submitting ? t("Submitting…", "جارٍ التقديم…") : t("Submit Exam ✓", "تقديم الامتحان ✓")}
          </button>
        </div>
      </div>
    </div>
  );

  // ── MAIN EXAM ──
  return (
    <div style={{ height: "100dvh", display: "flex", flexDirection: "column", background: "#f0f2f5", fontFamily: "'Cairo',sans-serif", userSelect: "none", WebkitUserSelect: "none", overflow: "hidden" }} onContextMenu={e => e.preventDefault()}>
      <style>{`
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes pulseTimer{0%,100%{opacity:1}50%{opacity:.5}}
        @keyframes slideIn{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:translateX(0)}}
        *{box-sizing:border-box}
        @media print { body { display:none !important; } }
      `}</style>

      {procEnabled && !submitted && (
        <ProctoringOverlay cameraReady={proc.cameraReady} faceDetected={proc.faceDetected}
          integrityScore={proc.integrityScore} suspicionLevel={proc.suspicionLevel}
          strikes={proc.strikes} maxStrikes={proc.maxStrikes} violations={proc.violations}
          lastWarningType={proc.lastWarningType} tooClose={(proc as any).tooClose} audioMonitoring={proc.audioMonitoring}
          recentViolations={(proc as any).recentViolations} getStream={(proc as any).getStream}
          attemptId={attemptId || ""} onPointDeduction={handlePointDeduction} />
      )}

      {/* Lockdown — covers the screen whenever the tab loses focus/visibility,
          on every exam regardless of whether webcam proctoring is on. */}
      <ExamFocusGuard
        active={!submitted && !loading}
        language={language === "ar" ? "ar" : "en"}
        onViolation={(awaySeconds) => {
          if (procEnabled) (proc as any).logViolation?.("tab_switch", 2, `Locked out — away ${awaySeconds}s`);
        }}
      />

      {/* HEADER */}
      <div style={{ height: 56, background: G, display: "flex", alignItems: "center", padding: "0 10px", gap: 8, flexShrink: 0, zIndex: 40, boxShadow: "0 2px 8px rgba(0,0,0,.3)" }}>
        <BookOpen style={{ width: 15, height: 15, color: GOLD, flexShrink: 0 }} />
        <span style={{ fontSize: 13, fontWeight: 800, color: "#fff", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1, minWidth: 0 }}>
          {language === "ar" ? exam?.title_ar || exam?.title : exam?.title}
        </span>
        {/* Timer */}
        <div style={{ display: "flex", alignItems: "center", gap: 4, background: timerBg, border: `1.5px solid ${timerColor}66`, borderRadius: 20, padding: "4px 10px", flexShrink: 0, animation: isTimeCrit ? "pulseTimer 1s infinite" : "none" }}>
          <Clock style={{ width: 12, height: 12, color: timerColor }} />
          <span style={{ fontSize: 14, fontWeight: 900, color: timerColor, fontVariantNumeric: "tabular-nums" }}>{fmt(timeLeft)}</span>
        </div>
        {/* Save indicator */}
        <div style={{ fontSize: 9, color: "rgba(255,255,255,.4)", display: "flex", alignItems: "center", gap: 2, flexShrink: 0 }}>
          {saving ? <div style={{ width: 7, height: 7, border: "1px solid rgba(255,255,255,.3)", borderTopColor: "transparent", borderRadius: "50%", animation: "spin .8s linear infinite" }} /> : lastSaved ? <div style={{ width: 5, height: 5, borderRadius: "50%", background: "#22c55e" }} /> : null}
        </div>
        <span style={{ fontSize: 11, color: "rgba(255,255,255,.65)", background: "rgba(255,255,255,.1)", borderRadius: 16, padding: "2px 8px", flexShrink: 0, whiteSpace: "nowrap" }}>{answeredCount}/{questions.length}</span>
        {deductedPoints > 0 && <span style={{ fontSize: 10, color: "#fca5a5", fontWeight: 700, flexShrink: 0 }}>−{deductedPoints}pts</span>}

        {/* Proctoring pill */}
        {procEnabled && (
          <div style={{ display: "flex", alignItems: "center", gap: 3, background: "rgba(0,0,0,.3)", borderRadius: 16, padding: "3px 7px", flexShrink: 0, cursor: "pointer" }} onClick={() => setShowProcLog(v => !v)}>
            <div style={{ width: 5, height: 5, borderRadius: "50%", background: proc.suspicionLevel === "low" ? "#22c55e" : proc.suspicionLevel === "medium" ? "#f59e0b" : "#ef4444" }} />
            <span style={{ fontSize: 9, fontWeight: 700, color: "rgba(255,255,255,.7)" }}>{Math.round(proc.integrityScore)}%</span>
            {proc.violations > 0 && <span style={{ fontSize: 8, background: "#dc2626", color: "#fff", borderRadius: 8, padding: "0 4px", fontWeight: 900 }}>{proc.violations}</span>}
          </div>
        )}

        {/* Keyboard help */}
        {!isMobile && (
          <button onClick={() => setShowKeyboardHelp(v => !v)} title="Keyboard shortcuts" style={{ background: "rgba(255,255,255,.1)", border: "none", color: "rgba(255,255,255,.6)", borderRadius: 8, padding: "5px 7px", cursor: "pointer", flexShrink: 0 }}>
            <Keyboard style={{ width: 12, height: 12 }} />
          </button>
        )}

        <button onClick={() => setShowNav(v => !v)} style={{ background: "rgba(255,255,255,.12)", border: "none", color: "rgba(255,255,255,.8)", borderRadius: 8, padding: "5px 7px", cursor: "pointer", flexShrink: 0 }}>
          <Grid style={{ width: 13, height: 13 }} />
        </button>

        <button onClick={() => { saveAnswers(true); setPhase("review"); }}
          style={{ background: "#dc2626", border: "none", color: "#fff", borderRadius: 9, padding: "6px 10px", fontSize: 11, fontWeight: 800, cursor: "pointer", display: "flex", alignItems: "center", gap: 4, fontFamily: "'Cairo',sans-serif", flexShrink: 0 }}>
          <Eye style={{ width: 12, height: 12 }} />{t("Submit", "تقديم")}
        </button>
      </div>

      {/* Keyboard help overlay */}
      {showKeyboardHelp && (
        <div style={{ position: "fixed", top: 64, right: 10, background: "#1a1a2e", borderRadius: 14, padding: "14px 18px", zIndex: 100, boxShadow: "0 8px 32px rgba(0,0,0,.4)", minWidth: 200 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: GOLD, marginBottom: 10, letterSpacing: 1 }}>KEYBOARD SHORTCUTS</div>
          {[["→ / ↓", "Next question"], ["← / ↑", "Previous question"], ["F", "Flag/unflag"], ["1", "Mark Confident"], ["2", "Mark Unsure"], ["3", "Mark Guessing"]].map(([k, v]) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", gap: 16, marginBottom: 5, fontSize: 11 }}>
              <span style={{ color: "#fff", background: "rgba(255,255,255,.1)", padding: "2px 8px", borderRadius: 4, fontFamily: "monospace" }}>{k}</span>
              <span style={{ color: "rgba(255,255,255,.6)" }}>{v}</span>
            </div>
          ))}
        </div>
      )}

      {/* Progress bar */}
      <div style={{ height: 4, background: "rgba(0,0,0,.15)", flexShrink: 0 }}>
        <div style={{ height: "100%", width: `${progressPct}%`, background: `linear-gradient(90deg,${GM},${GOLD})`, transition: "width .5s" }} />
      </div>

      {/* BODY */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden", minHeight: 0 }}>

        {/* LEFT: Question nav (desktop) */}
        {!isMobile && (
          <div style={{ width: 180, background: "#fff", borderRight: `1px solid ${BORDER}`, display: "flex", flexDirection: "column", overflow: "hidden", flexShrink: 0 }}>
            <div style={{ padding: "10px 10px 8px", borderBottom: `1px solid ${BORDER}` }}>
              <div style={{ fontSize: 9, fontWeight: 800, color: "#7a9e88", letterSpacing: 1.5, marginBottom: 8 }}>QUESTIONS</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 4, maxHeight: 300, overflowY: "auto" }}>
                {questions.map((qq, i) => {
                  const a = answers[qq.id];
                  const confDot = a?.confidence === "confident" ? "#6366f1" : a?.confidence === "unsure" ? GOLD : a?.confidence === "guessing" ? "#ef4444" : null;
                  return (
                    <button key={qq.id} onClick={() => setIdx(i)} title={`Q${i + 1} — ${a?.text ? "Answered" : "Unanswered"}${a?.flagged ? " · Flagged" : ""}${a?.confidence ? ` · ${a.confidence}` : ""}`}
                      style={{ height: 38, borderRadius: 8, border: "none", fontSize: 11, fontWeight: 800, cursor: "pointer", position: "relative", flexDirection: "column", display: "flex", alignItems: "center", justifyContent: "center", gap: 1.5, transition: "all .12s",
                        background: i === currentIdx ? G : a?.flagged ? "#fffbeb" : a?.text ? "#f0fff4" : "#f8fafb",
                        color: i === currentIdx ? "#fff" : a?.flagged ? GOLD : a?.text ? "#22c55e" : "#7a9e88",
                        outline: i === currentIdx ? `2px solid ${GOLD}` : a?.flagged ? `1px solid ${GOLD}` : a?.text ? `1px solid #86efac` : `1px solid transparent` }}>
                      {i + 1}
                      {confDot && <div style={{ width: 4, height: 4, borderRadius: "50%", background: confDot }} />}
                      {a?.flagged && <span style={{ position: "absolute", top: 1, right: 2, fontSize: 7 }}>🚩</span>}
                    </button>
                  );
                })}
              </div>
            </div>
            <div style={{ padding: "8px 10px", display: "flex", flexDirection: "column", gap: 4 }}>
              {[["#f0fff4", "#86efac", "#22c55e", `Answered (${answeredCount})`], ["#fffbeb", GOLD, GOLD, `Flagged (${flaggedCount})`], ["#f8fafb", BORDER, "#9ca3af", `Unanswered (${questions.length - answeredCount})`], ["#eef2ff", "#a5b4fc", "#6366f1", `Confident (${confidentCount})`]].map(([bg, bd, c, lb], i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 9 }}>
                  <div style={{ width: 10, height: 10, borderRadius: 3, background: bg, border: `1px solid ${bd}`, flexShrink: 0 }} />
                  <span style={{ color: "#7a9e88" }}>{lb}</span>
                </div>
              ))}
            </div>
            <div style={{ marginTop: "auto", padding: "8px 10px", borderTop: `1px solid ${BORDER}`, fontSize: 9, display: "flex", flexDirection: "column", gap: 4 }}>
              <div style={{ display: "flex", justifyContent: "space-between", color: "#7a9e88" }}><span>Pass Mark</span><span style={{ fontWeight: 800, color: G }}>{exam?.passing_score}%</span></div>
              <div style={{ display: "flex", justifyContent: "space-between", color: "#7a9e88" }}><span>Questions</span><span style={{ fontWeight: 800, color: G }}>{questions.length}</span></div>
              {deductedPoints > 0 && <div style={{ display: "flex", justifyContent: "space-between", color: "#ef4444" }}><span>Deducted</span><span style={{ fontWeight: 800 }}>−{deductedPoints}pts</span></div>}
            </div>
          </div>
        )}

        {/* CENTER: QUESTION */}
        <div ref={qScrollRef} style={{ flex: 1, overflow: "auto", padding: "10px 6px", display: "flex", flexDirection: "column", position: "relative" }}>
          {q && (
            <div style={{ width: "100%" }}>
              <div ref={qCardRef} key={currentIdx} style={{ animation: "slideIn .2s ease", transform: "scale(0.8)", transformOrigin: "top left", width: "125%" } as React.CSSProperties}>
              <div>

                {/* Question header */}
                <div style={{ background: `linear-gradient(135deg,${G} 0%,${GM} 100%)`, padding: "16px 20px", display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{ width: 40, height: 40, borderRadius: "50%", background: "rgba(255,255,255,.18)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17, fontWeight: 900, color: "#fff", flexShrink: 0, border: "2px solid rgba(255,255,255,.25)" }}>{currentIdx + 1}</div>
                  <div style={{ flex: 1, display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
                    <span style={{ fontSize: 11, padding: "3px 10px", borderRadius: 20, background: "rgba(255,255,255,.15)", color: "rgba(255,255,255,.9)", fontWeight: 700, textTransform: "capitalize" }}>
                      {q.question_type?.replace(/_/g, " ")}
                    </span>
                    {q.difficulty && (
                      <span style={{ fontSize: 11, padding: "3px 10px", borderRadius: 20, background: q.difficulty === "hard" ? "rgba(239,68,68,.35)" : q.difficulty === "easy" ? "rgba(34,197,94,.35)" : "rgba(255,255,255,.15)", color: "#fff", fontWeight: 700 }}>{q.difficulty}</span>
                    )}
                    {q.section_title && (
                      <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 20, background: "rgba(201,168,76,.3)", color: GOLD, fontWeight: 600 }}>§ {q.section_title}</span>
                    )}
                    <span style={{ fontSize: 11, padding: "3px 10px", borderRadius: 20, background: "rgba(201,168,76,.3)", color: GOLD, fontWeight: 800, marginLeft: "auto" }}>{q.points || 1} {t("pts", "نقطة")}</span>
                  </div>
                  <button onClick={() => toggleFlag(q.id)}
                    style={{ width: 38, height: 38, borderRadius: 10, border: "none", background: answers[q.id]?.flagged ? "#dc2626" : "rgba(255,255,255,.18)", color: "#fff", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "all .15s" }}>
                    <Flag style={{ width: 16, height: 16 }} />
                  </button>
                </div>

                {/* Question body */}
                <div style={{ padding: "16px 12px 10px" }}>
                  {/* Reading passage — optional, shown above the question (comprehension type) */}
                  {(q.reading_passage || q.reading_passage_ar) && (
                    <div style={{ marginBottom: 16, padding: "16px 20px", background: "#fffbeb", borderRadius: 14, border: `1px solid ${GOLD}44`, borderLeft: `4px solid ${GOLD}` }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: GOLD, letterSpacing: 1, marginBottom: 8 }}>📖 {t("READING PASSAGE", "نص القراءة")}</div>
                      {q.reading_passage && (
                        <div dir="auto" style={{ fontSize: 16, lineHeight: 2, color: G, fontFamily: "'Amiri',serif" }} dangerouslySetInnerHTML={{ __html: sanitizeHtml(q.reading_passage) }} />
                      )}
                      {q.reading_passage_ar && (
                        <div dir="rtl" style={{ fontSize: 16, lineHeight: 2, color: G, fontFamily: "'Amiri',serif", marginTop: q.reading_passage ? 10 : 0 }} dangerouslySetInnerHTML={{ __html: sanitizeHtml(q.reading_passage_ar) }} />
                      )}
                    </div>
                  )}
                  {/* Instruction — optional, shown above the question when set.
                      Flat (no card fill/border) — just a thin accent so it reads
                      as background text, not a boxed element. */}
                  {(q.instruction_text || q.instruction_text_ar) && (
                    <div style={{ marginBottom: 14, padding: "2px 0 2px 12px", borderLeft: `3px solid ${BORDER}` }}>
                      {q.instruction_text_ar && (
                        <p dir="rtl" style={{ fontFamily: "'Amiri',serif", fontSize: 14, color: "#4b5563", margin: 0, fontWeight: 600 }}>{q.instruction_text_ar}</p>
                      )}
                      {q.instruction_text && (
                        <p style={{ fontSize: 13, color: "#6b7280", margin: q.instruction_text_ar ? "4px 0 0" : 0, fontStyle: "italic" }}>{q.instruction_text}</p>
                      )}
                    </div>
                  )}
                  {/* Question text — Arabic first, English below, brackets removed */}
                  <div style={{ marginBottom: 20 }}>
                    {(q.question_text || q.question_text_ar)
                      ? <QText text={sanitizeHtml(q.question_text||'')} textAr={sanitizeHtml(q.question_text_ar||'')} />
                      : <p style={{ color: "#9ca3af", fontStyle: "italic", fontSize: 14 }}>Question text missing.</p>
                    }
                    {/* Media */}
                    {q.media_url && (q.question_type === "audio" || q.question_type === "dictation" || q.question_type === "audio_dictation") && (
                      <div style={{ marginTop: 12 }}>
                        <AudioPlayer src={q.media_url} title={t("Listen carefully", "استمع بعناية")} maxPlays={3} />
                        {/* Fallback native player in case AudioPlayer fails */}
                        <audio controls preload="metadata" src={q.media_url} crossOrigin="anonymous"
                          style={{ width: "100%", marginTop: 6, borderRadius: 8, display: "block" }}
                          onError={e => { (e.target as HTMLAudioElement).style.display = "block"; }}
                        />
                      </div>
                    )}
                    {q.media_url && q.question_type === "video" && <div style={{ marginTop: 12, borderRadius: 12, overflow: "hidden" }}><video controls src={q.media_url} style={{ width: "100%", maxHeight: 240, background: "#000" }} /></div>}
                    {q.media_url && isImageUrl(q.media_url) && !["audio", "dictation", "video"].includes(q.question_type) && <img src={q.media_url} alt="" style={{ marginTop: 12, maxHeight: 240, borderRadius: 10, objectFit: "contain", display: "block" }} />}
                    {q.media_url && !isImageUrl(q.media_url) && !["audio", "dictation", "video"].includes(q.question_type) && <div style={{ marginTop: 12 }}><AudioPlayer src={q.media_url} title="Audio" /></div>}
                  </div>

                  {/* MCQ */}
                  {(q.question_type === "mcq" || q.question_type === "image_mcq" || q.question_type === "comprehension") && q.options && (
                    <div style={{ display: "flex", flexDirection: "column", gap: 11 }}>
                      {(q.options as any[]).map((opt: any, idx: number) => {
                        const sel = answers[q.id]?.text === opt.id;
                        return (
                          <div key={opt.id} onClick={() => setAnswer(q.id, opt.id)}
                            style={{ display: "flex", alignItems: "center", gap: 14, padding: "15px 18px", borderRadius: 14, cursor: "pointer", transition: "all .15s", background: sel ? "#f0fff4" : "#f8fafb", border: `2px solid ${sel ? "#22c55e" : BORDER}`, boxShadow: sel ? "0 2px 12px rgba(34,197,94,.2)" : "0 1px 4px rgba(0,0,0,.04)" }}>
                            <div style={{ width: 36, height: 36, borderRadius: "50%", background: sel ? GM : "rgba(15,45,31,.08)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 900, color: sel ? "#fff" : G, flexShrink: 0, border: `2px solid ${sel ? GM : BORDER}` }}>
                              {String.fromCharCode(65 + idx)}
                            </div>
                            {opt.image_url && <img src={opt.image_url} alt="" style={{ height: 64, borderRadius: 8, objectFit: "contain" }} />}
                            <div style={{ flex: 1 }}>
                              {opt.text_ar && opt.text_ar !== opt.text && <div dir="rtl" style={{ fontSize: 18, fontFamily: "'Amiri Quran',serif", color: G, lineHeight: 2.1, marginBottom: 3 }} dangerouslySetInnerHTML={{ __html: sanitizeHtml(opt.text_ar) }} />}
                              {opt.text && <div dir="ltr" style={{ fontSize: 16, fontWeight: sel ? 700 : 500, color: sel ? G : "#374151", fontFamily: "'Amiri',serif", lineHeight: 1.9 }} dangerouslySetInnerHTML={{ __html: sanitizeHtml(opt.text) }} />}
                            </div>
                            <div style={{ width: 24, height: 24, borderRadius: "50%", background: sel ? "#22c55e" : "transparent", border: `2px solid ${sel ? "#22c55e" : BORDER}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "all .15s" }}>
                              {sel && <span style={{ color: "#fff", fontSize: 14, fontWeight: 900 }}>✓</span>}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Multi-select */}
                  {q.question_type === "multi_select" && (
                    <MultiSelectQuestion question={q} answer={answers[q.id]} onAnswer={(text, data) => setAnswer(q.id, text, data)} />
                  )}

                  {/* True/False */}
                  {q.question_type === "true_false" && (
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                      {[{ v: "true", l: t("True", "صح"), e: "✓", c: "#22c55e" }, { v: "false", l: t("False", "خطأ"), e: "✗", c: "#ef4444" }].map(opt => {
                        const sel = answers[q.id]?.text === opt.v;
                        return (
                          <div key={opt.v} onClick={() => setAnswer(q.id, opt.v)}
                            style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "24px 12px", borderRadius: 16, cursor: "pointer", background: sel ? opt.c + "18" : "#f8fafb", border: `2px solid ${sel ? opt.c : BORDER}`, boxShadow: sel ? `0 2px 12px ${opt.c}33` : "none", transition: "all .15s" }}>
                            <span style={{ fontSize: 38, marginBottom: 8 }}>{opt.e}</span>
                            <span style={{ fontSize: 20, fontWeight: 800, color: sel ? opt.c : G, fontFamily: "'Amiri',serif" }}>{opt.l}</span>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Fill blank */}
                  {q.question_type === "fill_blank" && (
                    <input dir="auto" placeholder={t("Type your answer here…", "اكتب إجابتك هنا…")} value={answers[q.id]?.text || ""} onChange={e => setAnswer(q.id, e.target.value)}
                      style={{ width: "100%", padding: "15px 16px", borderRadius: 14, border: `2px solid ${BORDER}`, fontSize: 17, outline: "none", color: G, background: "#f8fafb", fontFamily: "'Amiri',serif", transition: "border .15s" }}
                      onFocus={e => (e.target.style.borderColor = GM)} onBlur={e => (e.target.style.borderColor = BORDER)} />
                  )}

                  {/* Essay/Short */}
                  {(q.question_type === "short_answer" || q.question_type === "essay") && (
                    <>
                      <textarea dir="auto" rows={q.question_type === "essay" ? 8 : 5} placeholder={t("Write your answer here…", "اكتب إجابتك هنا…")} value={answers[q.id]?.text || ""} onChange={e => setAnswer(q.id, e.target.value)}
                        style={{ width: "100%", padding: "15px 16px", borderRadius: 14, border: `2px solid ${BORDER}`, fontSize: 17, outline: "none", color: G, background: "#f8fafb", resize: "vertical", lineHeight: 1.9, fontFamily: "'Amiri',serif", transition: "border .15s" }}
                        onFocus={e => (e.target.style.borderColor = GM)} onBlur={e => (e.target.style.borderColor = BORDER)} />
                      {q.question_type === "essay" && exam?.word_limit && (
                        <div style={{ fontSize: 11, color: "#9ca3af", marginTop: 4, textAlign: "right" }}>
                          {(answers[q.id]?.text || "").split(/\s+/).filter(Boolean).length} / {exam.word_limit} words
                        </div>
                      )}
                    </>
                  )}

                  {/* Audio/Dictation */}
                  {(q.question_type === "audio" || q.question_type === "dictation") && (
                    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                      {q.audio_response_type === "audio" ? (
                        <p style={{ fontSize: 12, color: "#9ca3af" }}>{t("Recite the text above clearly, then record your answer:", "اقرأ النص أعلاه بوضوح، ثم سجّل إجابتك:")}</p>
                      ) : (
                        <>
                          <textarea dir="auto" rows={4} placeholder={t("Write what you heard…", "اكتب ما سمعته…")} value={answers[q.id]?.text || ""} onChange={e => setAnswer(q.id, e.target.value)}
                            style={{ padding: "15px 16px", borderRadius: 14, border: `2px solid ${BORDER}`, fontSize: 17, outline: "none", color: G, background: "#f8fafb", resize: "none", fontFamily: "'Amiri',serif" }} />
                          <p style={{ fontSize: 12, color: "#9ca3af" }}>{t("Or record your answer:", "أو سجّل إجابتك:")}</p>
                        </>
                      )}
                      <AudioRecorder onRecordingComplete={async (blob, url) => {
                        if (!blob.size) { toast({ title: "Recording empty.", variant: "destructive" }); return; }
                        // Determine extension from the actual blob MIME type
                        const ext = blob.type.includes("mp4") ? "mp4"
                          : blob.type.includes("ogg") ? "ogg"
                          : blob.type.includes("webm") ? "webm"
                          : "mp4";  // safe fallback for Android
                        const path = `student-answers/${user!.id}/${attemptId}_${q.id}.${ext}`;
                        // The recording only exists as an in-memory blob: URL
                        // (`url`) until this upload succeeds — blob: URLs die
                        // the moment this tab closes, so if we give up after
                        // one failed attempt and quietly save that URL, the
                        // recording is gone forever the next time the page
                        // loads (this is exactly what happened to graders
                        // seeing "Audio file unavailable or corrupted" for
                        // otherwise-valid submissions). Retry a few times —
                        // most failures here are a flaky connection, not a
                        // permanent one — before falling back. Uploads go to
                        // Cloudflare R2 (via the exam-audio-url edge function)
                        // instead of Supabase's exam-media bucket.
                        let result: Awaited<ReturnType<typeof uploadExamAudioToR2>> | null = null;
                        for (let attempt = 1; attempt <= 3; attempt++) {
                          result = await uploadExamAudioToR2(path, blob);
                          if (!("error" in result)) break;
                          if (attempt < 3) await new Promise(r => setTimeout(r, 1000 * attempt));
                        }
                        if (result && !("error" in result)) {
                          setAnswer(q.id, "[audio_recorded]", { audioUrl: result.url, fileType: "audio", storagePath: result.storagePath });
                        } else {
                          toast({ title: "Upload failed: " + (result?.error || "Unknown error"), description: "Your recording is only saved on this device right now — please try recording again before submitting.", variant: "destructive" });
                          // Store the blob URL so the student can still hear
                          // their own take, and flag it so the warning below
                          // stays visible (not just a toast that disappears)
                          // and so this doesn't get mistaken for a real,
                          // persisted answer.
                          setAnswer(q.id, "[audio_recorded]", { audioUrl: url, fileType: "audio", uploadFailed: true });
                        }
                      }} existingUrl={answers[q.id]?.data?.audioUrl} />
                      {answers[q.id]?.data?.uploadFailed && (
                        <div style={{ padding: "8px 12px", borderRadius: 10, background: "#FEF2F2", border: "1px solid #FECACA", fontSize: 12, color: "#DC2626", fontWeight: 600 }}>
                          {t(
                            "⚠️ This recording didn't upload — it will be lost when you leave this page. Please re-record before submitting.",
                            "⚠️ لم يتم رفع هذا التسجيل — سيُفقد عند مغادرة هذه الصفحة. يُرجى إعادة التسجيل قبل الإرسال."
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Matching */}
                  {q.question_type === "matching" && (
                    <MatchingQuestion question={q} answer={answers[q.id]} onAnswer={(text, data) => setAnswer(q.id, text, data)} />
                  )}

                  {/* Ordering */}
                  {q.question_type === "ordering" && (
                    <OrderingQuestion question={q} answer={answers[q.id]} onAnswer={(text, data) => setAnswer(q.id, text, data)} />
                  )}

                  {/* Reading comprehension */}
                  {q.question_type === "reading" && (
                    <ReadingQuestion question={q} answer={answers[q.id]} onAnswer={(text, data) => setAnswer(q.id, text, data)} />
                  )}

                  {/* Confidence selector */}
                  {answers[q.id]?.text && (
                    <ConfidenceSelector value={answers[q.id]?.confidence || null} onChange={c => setConfidence(q.id, c)} />
                  )}
                </div>

                {/* Navigation footer */}
                <div style={{ padding: "14px 20px", borderTop: `1px solid ${BORDER}`, display: "flex", alignItems: "center", gap: 10, background: "#fafafa" }}>
                  <button onClick={() => setIdx(p => Math.max(0, p - 1))} disabled={currentIdx === 0}
                    style={{ display: "flex", alignItems: "center", gap: 6, padding: "11px 18px", borderRadius: 12, background: "#fff", border: `1.5px solid ${BORDER}`, color: currentIdx === 0 ? "#d1d5db" : G, fontSize: 14, fontWeight: 700, cursor: currentIdx === 0 ? "not-allowed" : "pointer", opacity: currentIdx === 0 ? 0.5 : 1, fontFamily: "'Cairo',sans-serif", boxShadow: "0 1px 4px rgba(0,0,0,.06)" }}>
                    <ChevronLeft style={{ width: 15, height: 15 }} />{t("Previous", "السابق")}
                  </button>
                  <span style={{ flex: 1, textAlign: "center", fontSize: 13, color: "#6b7280", fontWeight: 600 }}>{currentIdx + 1} of {questions.length}</span>
                  {currentIdx === questions.length - 1 ? (
                    <button onClick={() => { saveAnswers(true); setPhase("review"); }}
                      style={{ display: "flex", alignItems: "center", gap: 6, padding: "11px 18px", borderRadius: 12, background: G, border: "none", color: "#fff", fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'Cairo',sans-serif", boxShadow: `0 2px 8px rgba(15,45,31,.3)` }}>
                      <Eye style={{ width: 14, height: 14 }} />{t("Review & Submit", "مراجعة وتقديم")}
                    </button>
                  ) : (
                    <button onClick={() => setIdx(p => Math.min(questions.length - 1, p + 1))}
                      style={{ display: "flex", alignItems: "center", gap: 6, padding: "11px 18px", borderRadius: 12, background: G, border: "none", color: "#fff", fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'Cairo',sans-serif", boxShadow: `0 2px 8px rgba(15,45,31,.3)` }}>
                      {t("Next", "التالي")}<ChevronRight style={{ width: 15, height: 15 }} />
                    </button>
                  )}
                </div>
              </div>
              </div>
            </div>
          )}

        </div>

        {/* RIGHT: Summary + timer (desktop) */}
        {!isMobile && (
          <div style={{ width: 180, background: "#fff", borderLeft: `1px solid ${BORDER}`, display: "flex", flexDirection: "column", flexShrink: 0, padding: 12, gap: 10, overflow: "hidden" }}>
            <div style={{ textAlign: "center", background: timerBg, borderRadius: 12, padding: "12px 8px", border: `1.5px solid ${timerColor}44` }}>
              <div style={{ fontSize: 9, fontWeight: 700, color: "#9ca3af", letterSpacing: 1.5, marginBottom: 3 }}>TIME LEFT</div>
              <div style={{ fontSize: 28, fontWeight: 900, color: timerColor, fontVariantNumeric: "tabular-nums", animation: isTimeCrit ? "pulseTimer 1s infinite" : "none" }}>{fmt(timeLeft)}</div>
            </div>
            <div style={{ background: "#f8fafb", borderRadius: 12, padding: "10px", display: "flex", flexDirection: "column", gap: 7, border: `1px solid ${BORDER}` }}>
              {[{ l: t("Answered", "مُجاب"), v: answeredCount, c: "#22c55e" }, { l: t("Flagged", "مُعلّم"), v: flaggedCount, c: GOLD }, { l: t("Unanswered", "غير مُجاب"), v: questions.length - answeredCount, c: "#ef4444" }, { l: t("Confident", "واثق"), v: confidentCount, c: "#6366f1" }].map((s, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", fontSize: 11 }}>
                  <span style={{ color: "#9ca3af" }}>{s.l}</span><span style={{ fontWeight: 800, color: s.c }}>{s.v}</span>
                </div>
              ))}
              <div style={{ height: 5, borderRadius: 3, background: "#f0f4f0", overflow: "hidden", marginTop: 2 }}>
                <div style={{ height: "100%", width: `${progressPct}%`, background: `linear-gradient(90deg,${GM},${GOLD})`, transition: "width .5s", borderRadius: 3 }} />
              </div>
            </div>
            {deductedPoints > 0 && (
              <div style={{ background: "#fff5f5", borderRadius: 10, padding: "8px 10px", border: "1px solid #fca5a5", fontSize: 11, color: "#ef4444", fontWeight: 700, textAlign: "center" }}>
                −{deductedPoints} pts<br /><span style={{ fontWeight: 400, fontSize: 9, color: "#9ca3af" }}>proctoring violations</span>
              </div>
            )}
            <button onClick={() => saveAnswers(false)} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 5, padding: "8px 0", borderRadius: 10, background: "#f8fafb", border: `1px solid ${BORDER}`, color: G, fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: "'Cairo',sans-serif" }}>
              <Save style={{ width: 11, height: 11 }} />{saving ? "Saving…" : "Save Now"}
            </button>
            <div style={{ fontSize: 9, color: "#9ca3af", display: "flex", flexDirection: "column", gap: 3, marginTop: "auto", paddingTop: 6, borderTop: `1px solid ${BORDER}` }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}><span>Pass Mark</span><span style={{ fontWeight: 700, color: G }}>{exam?.passing_score}%</span></div>
              <div style={{ display: "flex", justifyContent: "space-between" }}><span>Total Qs</span><span style={{ fontWeight: 700, color: G }}>{questions.length}</span></div>
            </div>
          </div>
        )}
      </div>

      {/* MOBILE BOTTOM NAV */}
      {isMobile && (
        <div style={{ background: "#fff", borderTop: `1px solid ${BORDER}`, flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "6px 12px 0" }}>
            <span style={{ fontSize: 10, fontWeight: 700, color: "#7a9e88" }}>
              {answeredCount}/{questions.length} answered{flaggedCount > 0 && ` · ${flaggedCount} flagged`}
            </span>
            <button onClick={() => setShowNav(v => !v)} style={{ fontSize: 10, fontWeight: 700, color: G, background: "none", border: "none", cursor: "pointer" }}>
              {showNav ? "▲ Hide" : "▼ All Questions"}
            </button>
          </div>
          {showNav ? (
            <div style={{ padding: "8px 10px 10px" }}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(34px,1fr))", gap: 5 }}>
                {questions.map((qq, i) => {
                  const a = answers[qq.id];
                  return (
                    <button key={qq.id} onClick={() => { setIdx(i); setShowNav(false); }}
                      style={{ height: 34, borderRadius: 8, border: "none", fontSize: 11, fontWeight: 800, cursor: "pointer", background: i === currentIdx ? G : a?.flagged ? "#fffbeb" : a?.text ? "#f0fff4" : "#f8fafb", color: i === currentIdx ? "#fff" : a?.flagged ? GOLD : a?.text ? "#22c55e" : "#7a9e88", outline: i === currentIdx ? `2px solid ${GOLD}` : "" }}>
                      {i + 1}
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            <div style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 10px 8px", overflowX: "auto" }}>
              {questions.map((qq, i) => {
                const a = answers[qq.id];
                return (
                  <button key={qq.id} onClick={() => setIdx(i)}
                    style={{ width: 32, height: 32, borderRadius: 8, border: "none", fontSize: 11, fontWeight: 800, cursor: "pointer", flexShrink: 0, background: i === currentIdx ? G : a?.flagged ? "#fffbeb" : a?.text ? "#f0fff4" : "#f8fafb", color: i === currentIdx ? "#fff" : a?.flagged ? GOLD : a?.text ? "#22c55e" : "#7a9e88", transform: i === currentIdx ? "scale(1.1)" : "scale(1)" }}>
                    {i + 1}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ExamTaking;
