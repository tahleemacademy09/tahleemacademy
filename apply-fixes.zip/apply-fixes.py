#!/usr/bin/env python3
"""Run from the repo root:  python3 apply-fixes.py
1) Splash screen: show the brand logo, remove the mosque emoji + name text.
2) Live class: a class no longer survives the app being closed, so the floating
   class bubble is gone after a cold start until you join a class again."""
import re, sys, pathlib

def edit(path, fn):
    p = pathlib.Path(path)
    if not p.exists():
        sys.exit(f"ERROR: {path} not found - run this from the repo root")
    s = p.read_text(encoding="utf-8")
    new = fn(s)
    if new == s:
        print(f"- {path}: already up to date")
    else:
        p.write_text(new, encoding="utf-8"); print(f"- {path}: updated")

# ---------- 1. splash ----------
def splash(s):
    if "ta-splash-logo" in s:
        return s
    # markup: icon box + english name + arabic name  ->  logo image only
    pat = re.compile(r'<div class=(\\?")ta-splash-icon\1>.*?</div><div class=\1ta-splash-name\1>.*?</div><div class=\1ta-splash-ar\1>.*?</div>', re.S)
    m = pat.search(s)
    if not m:
        sys.exit("ERROR: splash markup not found in index.html (it may have been changed)")
    q = m.group(1)
    s = s[:m.start()] + f'<img class={q}ta-splash-logo{q} src={q}/brand-logo.png{q} alt={q}{q}>' + s[m.end():]
    # css for the logo, inserted before the old icon rule
    css = ("      .ta-splash-logo {\n        width: 200px;\n        height: 200px;\n        object-fit: contain;\n"
           "        filter: drop-shadow(0 4px 24px rgba(201,168,76,0.25));\n      }\n")
    s = s.replace("      .ta-splash-icon {", css + "      .ta-splash-icon {", 1)
    # preload so it paints instantly
    if 'rel="preload" as="image" href="/brand-logo.png"' not in s:
        s = s.replace("    <style>\n      #ta-splash {", '    <link rel="preload" as="image" href="/brand-logo.png" />\n    <style>\n      #ta-splash {', 1)
    return s
edit("index.html", splash)

# ---------- 2. live class must not survive app close ----------
def ctx(s):
    if "does NOT survive the app being closed" in s:
        return s
    pat = re.compile(r'function restore\(\): LiveClassState \| null \{.*?\n\}\n', re.S)
    m = pat.search(s)
    if not m:
        sys.exit("ERROR: restore() not found in LiveClassContext.tsx")
    body = ('function restore(): LiveClassState | null {\n'
            '  // A live class does NOT survive the app being closed: on a cold start we wipe any\n'
            '  // saved call so the floating class bubble stays gone until the user joins a class anew.\n'
            '  // (Plain backgrounding keeps JS alive, so the in-memory state / bubble is untouched.)\n'
            '  clearPersist();\n'
            '  return null;\n'
            '}\n')
    return s[:m.start()] + body + s[m.end():]
edit("src/contexts/LiveClassContext.tsx", ctx)
print("Done.")
