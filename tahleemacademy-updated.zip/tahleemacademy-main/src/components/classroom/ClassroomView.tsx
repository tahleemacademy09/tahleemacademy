/*
  ClassroomView.tsx — Tahleem Academy Live Classroom
  Google Meet-style UI · iOS-safe · Persistent call context
  (split 2026-07: the large pile of standalone helper hooks/components that
  used to live in this same file now lives in ./classroomComponents.tsx —
  this file only holds the main ClassroomView component + its three tiny
  room-context bridge wrappers at the bottom.)
*/

import {
  LiveKitRoom, useRoomContext, RoomAudioRenderer, StartAudio,
  useParticipants, useLocalParticipant, useTracks,
} from "@livekit/components-react";
// @ts-ignore
import "@livekit/components-styles";
import { Track, RoomEvent, ConnectionState, ConnectionQuality, RemoteTrackPublication, RemoteParticipant } from "livekit-client";
// BUG FIX — this import was missing entirely. Every hook below (useState,
// useEffect, useRef, useCallback) was relying on a global that doesn't
// exist, throwing "useState is not defined" the instant this component
// tried to render — which is every single time "Join Class" was pressed,
// on every role, since they all go through this one component.
import { useState, useEffect, useRef, useCallback } from "react";
import { createPortal } from "react-dom";
import { supabase } from "@/integrations/supabase/client";
import HifdhReviewPanel,{isHifdhReviewRoom} from "@/components/hifdh/HifdhReviewPanel";
import HifdhMemorizationPanel from "@/components/hifdh/HifdhMemorizationPanel";
import HifdhFollowAlong from "@/components/hifdh/HifdhFollowAlong";
import { Capacitor } from "@capacitor/core";
import { canNativeScreenShare, startNativeScreenShare, stopNativeScreenShare, onNativeScreenShareStopped, isScreenBot } from "@/lib/nativeScreenShare";
import { StatusBar } from "@capacitor/status-bar";
import { storageSupabase } from "../../integrations/supabase/storageClient";
import { getSignedUrl } from "../../integrations/supabase/storageClient";
import { isInlineLessonRow } from "./lessonBuilder";
import { playJoinSound, playLeaveSound, playRecordingStartSound, playRecordingStopSound } from "@/lib/soundUtils";
import NetworkGuard from "@/components/classroom/NetworkGuard";
import { isSlowLink } from "@/lib/slowNetwork";
import { getActiveRecorder } from "@/lib/directRecorder";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useLiveClass } from "@/contexts/LiveClassContext";
import { useIsMobile } from "@/hooks/use-mobile";
import { toast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Mic, MicOff, Video, VideoOff, Phone, Hand,
  PenTool, MessageCircle, MoreVertical, BookOpen,
  Circle, Loader2, X, Smile, Play, Pause,
  Volume2, ChevronDown, ChevronLeft, ChevronRight, Users, Eye,
  LayoutGrid, AlignJustify, Columns, Rows, Maximize2,
  SwitchCamera, Settings, Check, Wifi,
  Monitor, MonitorOff, Pin, Timer, UserCheck, Crosshair,
  Zap, ClipboardList, Bell, Radio, Layers,
} from "lucide-react";
import ClassLobby        from "./ClassLobby";
import ClassChatPanel    from "./ClassChatPanel";
import MobileChatSheet   from "./MobileChatSheet";
import ClassParticipants from "./ClassParticipants";
import ClassPolls        from "./ClassPolls";
import ClassEndScreen    from "./ClassEndScreen";
import AttendanceQuickReview from "./AttendanceQuickReview";
import ClassControls     from "./ClassControls";
import ParticipantDrawer from "./ParticipantDrawer";
import { PrivateChatListener, ChatPopupLayer, chatStore, usePrivateChat } from "./privateChatStore";
import { DropdownMenuItem } from "@/components/ui/dropdown-menu";
import LiveQuizOverlay   from "./LiveQuizOverlay";
import PDFViewer, { prewarmPDF } from "./PDFViewer";
import LiveClassFilePanel from "./LiveClassFilePanel";
import {
  ClassroomViewProps,
  LayoutMode,
  FloatingEmoji,
  RaisedHand,
  TEAL,
  TEAL2,
  DARK,
  GLASS,
  GLASSB,
  GREEN,
  RED,
  BAR_H,
  CSS,
  WS_DROP_DEBOUNCE_MS,
  ReconnectingOverlay,
  useAudioOnlyMode,
  useConnectionHeartbeat,
  pendingDataQueue,
  flushDataQueue,
  DataQueueFlusher,
  useScreenWakeLock,
  ReconnectMonitor,
  ConnectionStateBanner,
  AudioOnlyBridge,
  CameraLockBridge,
  ProfileSyncBridge,
  HeartbeatBridge,
  WbSyncBridge,
  TeacherMaterialFollower,
  AdminMuteListener,
  BASE_GAIN,
  VolumeBooster,
  MediaAutoPublish,
  RoomDataListener,
  FloatingEmojiLayer,
  RaisedHandsOverlay,
  JoinLeaveOverlay,
  GroupRecitePermDialog,
  LAYOUT_OPTIONS,
  LayoutSwitcher,
  MicKeepAlive,
  MicKeepAliveFromContext,
  GroupReciteAutoMic,
  WBTool,
  WBStroke,
  WBShape,
  WBText,
  WBImage,
  WBElement,
  drawElement,
  canvasCache,
  Whiteboard,
  WhiteboardBridge,
  MaterialPicker,
  MAT_TYPE_ICON,
  toMaterialEmbedUrl,
  RESUME_KEY,
  saveResume,
  loadResume,
  InClassMaterialViewer,
  SURAH_PAGE,
  PAGE_SURAH,
  QuranMode,
  SURAHS_LIST,
  QURAN_PAGE_KEY,
  InClassQuranReader,
  MAT_UPLOAD_BUCKET,
  detectMaterialType,
  SubjectMaterialsPanel,
  MaterialViewer,
  RecController,
  RoomSettingsModal,
  QUALITY_LABELS,
  SignalBars,
  useNetworkQuality,
  NetworkQualityBadge,
  NetworkAdaptiveEngine,
  ParticipantSignalIcon,
  ParticipantTile,
  VideoGrid,
  DuoPipLayout,
  GRID_PAGE_SIZE,
  PagedGrid,
  BottomBar,
  BottomBarBridge,
  RoomToContextBridge,
  syncManualAttendanceFromSession,
  queuePublish,
  ClassroomAdminContext,
  JoinRequestBanner,
  CameraUnmirrorEngine,
} from "./classroomComponents";

export * from "./classroomComponents";

// FIX ("interface shakes, particularly the participants number"): this used
// to be defined AS A NESTED FUNCTION inside ClassroomView's own render body
// (`const ParticipantCountBadge=()=>{...}` re-created every render). React
// identifies component types by function identity, so a fresh function every
// render looks like a brand-new component type to React — it tore down and
// remounted this badge (and its useParticipants() subscription) on every
// single re-render of ClassroomView, which happens every second just from
// the class-duration timer ticking. That teardown/remount is what showed up
// as the participant-count badge visibly flickering/shaking. Hoisting it out
// here gives it a stable identity across renders — normal prop changes no
// longer force a remount.
const ParticipantCountBadge=({participantCountRef,onOpen}:{participantCountRef:{current:number};onOpen:()=>void})=>{
  const all=useParticipants().filter(p=>!isScreenBot(p.identity));   // hide phone screen-share helpers
  useEffect(()=>{if(all.length>participantCountRef.current)participantCountRef.current=all.length;},[all.length,participantCountRef]);
  if(all.length===0)return null;
  return(
    <div className="gm-badge" style={{background:"rgba(255,255,255,.06)",border:"1px solid rgba(255,255,255,.1)",color:"rgba(255,255,255,.8)",flexShrink:0,cursor:"pointer"}} onClick={onOpen}>
      <Users style={{width:12,height:12,opacity:.7}}/>
      <span style={{fontSize:12,fontWeight:500,fontFamily:"'Google Sans',sans-serif"}}>{all.length}</span>
    </div>
  );
};

// The class clock ticks in its OWN tiny component. It used to be state at the top of
// ClassroomView, so every second re-rendered the whole classroom (video grid, panels,
// controls) - a constant background load that heats a phone. Now only this text updates.
const ClassClock=({durationRef}:{durationRef:{current:number}})=>{
  const[,tick]=useState(0);
  useEffect(()=>{const id=setInterval(()=>tick(n=>n+1),1000);return()=>clearInterval(id);},[]);
  const s=durationRef.current;
  return <>{`${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`}</>;
};

// Set to false to go back to the default VP8 codec on phones (see publishDefaults).
const USE_H264_ON_MOBILE=true;

const ClassroomView=({subject,onLeave,onMinimize,autoJoin=false}:ClassroomViewProps)=>{
  const{user,hasRole}=useAuth();const{t}=useLanguage();const isMobile=useIsMobile();const isPrivileged=hasRole("admin")||hasRole("teacher");const isAdmin=hasRole("admin");
  const{setHasConnected,leaveSessionFnRef,minimized,setMinimized}=useLiveClass();
  const[phase,setPhase]=useState<"lobby"|"live"|"ended"|"waiting">("lobby");
  const[waitingMessage,setWaitingMessage]=useState<string|null>(null);
  const[waitingDenied,setWaitingDenied]=useState(false);
  const waitingSessionIdRef=useRef<string|null>(null);
  const[token,setToken]=useState<string|null>(null);const[wsUrl,setWsUrl]=useState<string|null>(null);
  const[error,setError]=useState<string|null>(null);const[loading,setLoading]=useState(false);
  const[reconnecting,setReconnecting]=useState(false);
  // The full-screen "Checking connection…" overlay may block the class for at most
  // 5 seconds. After that it shrinks to a small non-blocking pill while retries continue.
  const[overlayExpired,setOverlayExpired]=useState(false);
  useEffect(()=>{
    if(!reconnecting){setOverlayExpired(false);return;}
    const t=setTimeout(()=>setOverlayExpired(true),5_000);
    return()=>clearTimeout(t);
  },[reconnecting]);
  /* ── reconnect state ── */
  const[roomKey,setRoomKey]=useState(0);          // bump to remount <LiveKitRoom> with fresh token
  // Use refs instead of state so autoReconnect useCallback never needs them as deps.
  // State-based count was causing useCallback to recreate on every attempt, which
  // destabilised ReconnectMonitor's event listeners and caused the infinite reconnect loop.
  const autoReconnectCountRef=useRef(0);
  const isReconnectingRef=useRef(false);           // guard against concurrent autoReconnect calls
  const backgroundReconnectRef=useRef(false);      // reset hidden-tab retry history after resume
  const intentionalLeaveRef=useRef(false);         // true on manual leave → skip auto-reconnect
  const participantCountRef=useRef(0);              // tracks peak live participant count for ClassEndScreen

  // ── Eager materials prewarm ───────────────────────────────────────────
  // CHANGED: previously, materials only started loading/rendering the moment
  // the user opened the Materials panel AND then tapped a specific document —
  // a fully cold pdf.js load happening right when they wanted to see it.
  // Now we fetch the material list and start caching/rendering PDFs in the
  // background from the moment the classroom mounts (lobby included — that's
  // free head-start time while the user is choosing mic/camera), staggered
  // so it doesn't compete with the actual class connection. By the time the
  // user opens Materials and taps a document, PDFViewer's own cache (see
  // PDFViewer.tsx) usually already has it — instant, and works offline.
  useEffect(()=>{
    if(!subject?.id)return;
    let cancelled=false;
    const timers:ReturnType<typeof setTimeout>[]=[];
    supabase.from("subject_materials" as any).select("file_url,material_type").eq("subject_id",subject.id)
      .then(({data}:{data:any[]|null})=>{
        if(cancelled||!data)return;
        const pdfs=data.filter(m=>m.file_url&&(m.material_type==="PDF"||m.material_type==="document"||(m.file_url||"").toLowerCase().split("?")[0].endsWith(".pdf")));
        // FIX ("slow to load once the class connects"): this used to start
        // downloading PDFs almost immediately (i*600ms, so the first one
        // began well under a second after mount) — right when the LiveKit
        // token fetch and ICE/DTLS handshake are also competing for the
        // connection. Pushing the first prewarm out and spacing the rest
        // further apart gives the actual class connection priority; PDFs
        // still finish caching well before a student realistically opens
        // the Materials panel.
        pdfs.forEach((m,i)=>{
          timers.push(setTimeout(()=>{ if(!cancelled) prewarmPDF(m.file_url); },4000+i*1200));
        });
      },()=>{}); // best-effort — Materials panel will still load normally if this fails
    return ()=>{ cancelled=true; timers.forEach(clearTimeout); };
  },[subject?.id]);

  /* ── lobby media choices ── */
  const[lobbyMic,setLobbyMic]=useState(false); // OFF by default — user must explicitly enable
  const[lobbyCam,setLobbyCam]=useState(false); // OFF by default — user must explicitly enable
  // ── Class Settings from the lobby (Waiting Room / Mute on entry / Chat /
  // Hand raising) — these used to be written to live_sessions and never read
  // back anywhere, so every toggle was purely decorative. livekit-token now
  // enforces Waiting Room itself (returns {pending:true} instead of a token)
  // and echoes the rest back on every successful token response; this holds
  // that echoed copy so the rest of the UI (chat tabs, hand-raise button,
  // initial mic state below) can actually honor it. Defaults match the
  // column defaults everyone had before this was wired up, so nothing
  // changes for a session whose settings we haven't heard back for yet.
  const[sessionSettings,setSessionSettings]=useState({mute_on_entry:false,chat_enabled:true,hand_raise_enabled:true,allow_video:true});
  // FIX ("lobby mic/cam choice doesn't reflect in class"): MediaAutoPublish used to decide
  // whether this was a first-join (apply lobby choice) vs a reconnect (apply last-known toggle
  // state) by reading `hasConnected` from LiveClassContext. But connect() below calls
  // setHasConnected(true) in the exact same synchronous tick as setPhase("live") — the state
  // update that mounts <LiveKitRoom> (and therefore MediaAutoPublish) in the first place. React
  // batches both updates into one commit, so by MediaAutoPublish's FIRST-EVER render,
  // hasConnected already reads true — making every first join look like a reconnect, so it
  // silently ignored the mic/cam the user picked in the lobby (students, teachers, admins
  // alike) and fell back to the default OFF/OFF state instead.
  // Fix: track "was this the first connect() call" in a plain ref, frozen the moment connect()
  // runs (before any state changes), and pass it down as an explicit prop instead of relying on
  // the reactive (and, in this exact spot, already-stale) context value.
  const everConnectedRef=useRef(false);
  const isFirstJoinPropRef=useRef(true);
  // Background keep-alive (silent <audio>, WakeLock, MediaSession) is started/stopped
  // from GlobalClassroomOverlay via useBackgroundAudio.ts based on `hasConnected` —
  // no per-component keep-alive needed here anymore.
  // Feature 7: Screen wake lock — keep screen on during class so Android doesn't kill audio
  // (Separate from GlobalClassroomOverlay's wake lock — that one only activates after minimize)
  // (Wake lock is now taken after audioOnlyActive is declared, below — audio-only mode lets the screen sleep.)

  // ── Full-screen while in a live class ─────────────────────────────────
  // Web: requests the browser's real Fullscreen API (hides the address bar/
  // browser chrome) the moment the call goes live, and exits it again the
  // moment it doesn't (ended/left/minimized) — never left engaged behind.
  // Capacitor native app: there's no page chrome to hide, but the OS status
  // bar still floats over the top of the WebView, so it's hidden the same
  // way for the same "edge-to-edge" effect, and restored on the way out.
  useEffect(()=>{
    const isLive = phase === "live";
    if (Capacitor.isNativePlatform()) {
      (isLive ? StatusBar.hide() : StatusBar.show()).catch(()=>{});
    } else if (typeof document !== "undefined") {
      if (isLive && !document.fullscreenElement) {
        document.documentElement.requestFullscreen?.().catch(()=>{});
      } else if (!isLive && document.fullscreenElement) {
        document.exitFullscreen?.().catch(()=>{});
      }
    }
    return ()=>{
      if (Capacitor.isNativePlatform()) StatusBar.show().catch(()=>{});
      else if (document.fullscreenElement) document.exitFullscreen?.().catch(()=>{});
    };
  },[phase]);

  const[sessionId,setSessionId]=useState<string|null>(null);const[sessionInfo,setSessionInfo]=useState<any>(null);
  const[showAttendanceReview,setShowAttendanceReview]=useState(false);
  const[attendanceId,setAttendanceId]=useState<string|null>(null);const[joinedAt]=useState(Date.now());
  // FIX: when a student disconnects (logs out, force-closes the app, hard network
  // drop) and later rejoins, we now reuse their EXISTING attendance_logs row for
  // this session instead of inserting a second one — previously every rejoin
  // created a brand-new row, so the same student could show up multiple times in
  // the admin's "Auto-Logged" list with their time split across separate entries.
  // attPriorDurationRef holds whatever duration was already banked on that row
  // from earlier stints in this same session, so the next time they leave we
  // write back prior + this-stint duration instead of overwriting it.
  const attPriorDurationRef=useRef(0);
  const[savingRec,setSavingRec]=useState(false);const[isSessionLive,setIsSessionLive]=useState(false);const durationRef=useRef(0);
  const recStopRef=useRef<()=>Promise<void>>(async()=>{});
  // BUG FIX — see onBeforeUnload below: recStopRef.current is ALWAYS a
  // function (a no-op placeholder until RecController mounts, then the real
  // stopRec) — so checking "is it a function" is always true and can never
  // distinguish "recording active" from "never recorded at all". This ref
  // is the real source of truth, kept in sync by RecController itself.
  const isRecordingRef=useRef(false);
  // Auto-save on pagehide (tab close / refresh / navigate away).
  // pagehide fires synchronously; stopRec is async but the browser allows
  // async work initiated from pagehide as long as we don't await across
  // microtask boundaries that the browser kills. We kick it off and let it run.
  useEffect(()=>{
    // Direct recording is persisted on the device chunk-by-chunk and uploaded in the
    // background, so closing/refreshing the page no longer needs to "stop" anything:
    // leftovers are finalized and uploaded the next time the app opens on this device.
    const onPageHide=()=>{};
    const onBeforeUnload=(e:BeforeUnloadEvent)=>{
      // BUG FIX — "recording in progress" warning was showing on EVERY
      // leave/refresh/close, for every teacher AND every student, even when
      // no recording had ever been started. The old check tested whether
      // recStopRef.current was a function — which it always is (either the
      // no-op placeholder or the real stopRec) — so this fired unconditionally.
      // Now gated on the actual recording state.
      if(isRecordingRef.current){
        e.preventDefault();
        e.returnValue="A recording is in progress. Are you sure you want to leave?";
      }
    };
    window.addEventListener("pagehide",onPageHide);
    window.addEventListener("beforeunload",onBeforeUnload);
    return()=>{
      window.removeEventListener("pagehide",onPageHide);
      window.removeEventListener("beforeunload",onBeforeUnload);
    };
  },[]);
  const[chatOpen,setChatOpen]=useState(false);const[partOpen,setPartOpen]=useState(false);const[chatUnread,setChatUnread]=useState(0);
  // Header + footer now own their own reserved strips and are always visible, so nothing is ever covered.
  const uiHidden=false;const setUiHidden=(_v?:any)=>{};
  const privChat=usePrivateChat();
  const privateUnread=Object.values(privChat.threads).reduce((n,th)=>n+th.unread,0);
  useEffect(()=>()=>{chatStore.reset();},[]);
  const onStageTap=(e:any)=>{
    if(e?.target?.closest?.("button,a,input,textarea,select,[data-tile-control]"))return;
    setUiHidden(v=>!v);
  };
  useEffect(()=>{
    const h=()=>setUiHidden(v=>!v);
    window.addEventListener("classroom:toggle-ui",h);
    return()=>window.removeEventListener("classroom:toggle-ui",h);
  },[]);
  useEffect(()=>{
    try{document.body.dataset.classUi=uiHidden?"hidden":"shown";}catch{}
    window.dispatchEvent(new CustomEvent("classroom:ui-state",{detail:{hidden:uiHidden}}));
  },[uiHidden]);
  // Measure the real header + control bar so the stage/panels sit exactly between them.
  useEffect(()=>{
    const root=document.documentElement;
    const apply=()=>{
      const h=document.querySelector("[data-class-header]") as HTMLElement|null;
      const f=document.querySelector(".cx-control-bar") as HTMLElement|null;
      if(h&&h.offsetHeight)root.style.setProperty("--cls-top",h.offsetHeight+"px");
      if(f&&f.offsetHeight)root.style.setProperty("--cls-bottom",f.offsetHeight+"px");
    };
    apply();
    const iv=window.setInterval(apply,600);
    window.addEventListener("resize",apply);
    window.addEventListener("orientationchange",apply);
    return()=>{window.clearInterval(iv);window.removeEventListener("resize",apply);window.removeEventListener("orientationchange",apply);root.style.removeProperty("--cls-top");root.style.removeProperty("--cls-bottom");};
  },[]);
  const openChatFrom=(peer?:{id:string;name:string})=>{
    setChatOpen(true);setSideTab("chat");setChatUnread(0);
    if(peer)chatStore.requestOpen(peer);
  };
  // Incoming class-chat message shown as a banner over the class (✕ to dismiss); it also stays in the chat box.
  const[chatBanner,setChatBanner]=useState<{id:string;name:string;text:string}|null>(null);
  const chatOpenRef=useRef(false);
  useEffect(()=>{chatOpenRef.current=chatOpen;if(chatOpen)setChatBanner(null);},[chatOpen]);
  useEffect(()=>{
    if(!chatBanner)return;
    const tm=setTimeout(()=>setChatBanner(cur=>cur&&cur.id===chatBanner.id?null:cur),10000);
    return()=>clearTimeout(tm);
  },[chatBanner]);
  useEffect(()=>{
    if(!sessionId||phase!=="live")return;
    const ch=supabase.channel(`chat-unread-${sessionId}`)
      .on("postgres_changes",{event:"INSERT",schema:"public",table:"class_chat_messages",filter:`session_id=eq.${sessionId}`},
        async(payload:any)=>{
          if(payload.new?.sender_id===user?.id)return;
          if(payload.new?.type==="system"||payload.new?.type==="reaction"||payload.new?.type==="emoji")return;
          setChatUnread(n=>{const panelClosed=!chatOpenRef.current;return panelClosed?n+1:0;});
          if(chatOpenRef.current||payload.new?.type==="reaction")return;
          const m=payload.new||{};
          let nm="Class chat";
          try{
            const{data}=await supabase.from("profiles").select("full_name").eq("user_id",m.sender_id).maybeSingle();
            if(data?.full_name)nm=data.full_name;
          }catch{}
          if(!chatOpenRef.current)setChatBanner({id:String(m.id||Date.now()),name:nm,text:String(m.message||"")});
        })
      .subscribe();
    return()=>{supabase.removeChannel(ch);};
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[sessionId,phase,user?.id]);
  const[sideTab,setSideTab]=useState<"chat"|"polls">("chat");const[showEnd,setShowEnd]=useState(false);
  // "Enable chat" Class Setting: only gates non-privileged participants — an
  // admin/teacher can always chat with their own class regardless of the
  // toggle they set for students. If a student is sitting on the Chat tab
  // when this turns out to be off (or the host flips it off mid-class, once
  // sessionSettings updates), bump them to Polls instead of leaving a
  // disabled tab open.
  const chatAllowed=isPrivileged||sessionSettings.chat_enabled;
  useEffect(()=>{if(!chatAllowed&&sideTab==="chat")setSideTab("polls");},[chatAllowed,sideTab]);
  // FIX ("student can exit with a single accidental tap"): the Leave button
  // (both the phone-icon button and its dropdown twin) called leaveSession()
  // directly with zero confirmation — one mis-tap dropped a student straight
  // out of class. Teachers already get a confirm step via the End-class
  // dialog; students now get an equivalent lightweight confirm before
  // leaveSession() actually runs.
  const[showLeaveConfirm,setShowLeaveConfirm]=useState(false);
  // FIX BUG 2: quizOpen state — LiveQuizOverlay was permanently disabled with hardcoded isOpen={false}
  const[quizOpen,setQuizOpen]=useState(false);
  const[wbOpen,setWbOpen]=useState(false);const[matOpen,setMatOpen]=useState<any>(null);const[matPicker,setMatPicker]=useState(false);const[matPanelOpen,setMatPanelOpen]=useState(false);
  // Track whether SubjectMaterialsPanel has any open/minimized materials — keep it mounted if so
  const[matPanelHasPip,setMatPanelHasPip]=useState(false);
  // Imperative ref to panel — lets us call showList() without toggling mount state
  const matPanelRef=useRef<{showList:()=>void}|null>(null);
  // Smart toggle: if panel is mounted (has pip or is open), just call showList(); else open it
  const toggleMatPanel=()=>{
    if(matPanelHasPip||matPanelOpen){
      // Panel is alive — tell it to show the list, and make sure it's "open"
      setMatPanelOpen(true);
      matPanelRef.current?.showList();
    } else {
      setMatPanelOpen(true);
    }
  };
  const[matMinimized,setMatMinimized]=useState(false);
  const[matPipPos,setMatPipPos]=useState({x:20,y:120});
  const matPipDragging=useRef(false);
  const matPipDragStart=useRef({px:0,py:0,ox:0,oy:0});
  const onMatPipPointerDown=(e:React.PointerEvent)=>{matPipDragging.current=true;matPipDragStart.current={px:e.clientX,py:e.clientY,ox:matPipPos.x,oy:matPipPos.y};(e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);};
  const onMatPipPointerMove=(e:React.PointerEvent)=>{if(!matPipDragging.current)return;setMatPipPos({x:matPipDragStart.current.ox+(e.clientX-matPipDragStart.current.px),y:matPipDragStart.current.oy+(e.clientY-matPipDragStart.current.py)});};
  const onMatPipPointerUp=()=>{matPipDragging.current=false;};
  const[groupRecite,setGroupRecite]=useState(false);const[canStudentWrite,setCanStudentWrite]=useState(false);const[canStudentRec,setCanStudentRec]=useState(false);
  // Student recording — lifted here so SubjectMaterialsPanel can also trigger it
  const[stuRec,setStuRec]=useState(false);
  const stuMrRefTop=useRef<MediaRecorder|null>(null);
  // FIX ("students say they only hear their own voice back in the
  // recording"): the old implementation called getUserMedia({audio:true})
  // and recorded THAT stream directly — which is just the student's own
  // microphone, nothing else. It never touched any audio from the teacher
  // or other students, so of course played-back recordings only ever had
  // the recording student's own voice on them.
  //
  // Fix: mix the student's mic together with every OTHER participant's
  // subscribed audio track (what the student is actually hearing through
  // their speakers/headphones right now) into one Web Audio destination
  // node, and record THAT combined stream instead. Tracks that
  // subscribe/unsubscribe mid-recording (someone unmutes, a late student
  // joins, etc.) are added/removed from the mix live.
  const stuAudioCtxRef=useRef<AudioContext|null>(null);
  const stuDestRef=useRef<MediaStreamAudioDestinationNode|null>(null);
  const stuBusRef=useRef<AudioNode|null>(null); // start of the speech-cleanup chain; every source plugs in here
  const stuLocalMicStreamRef=useRef<MediaStream|null>(null);
  const stuSourceNodesRef=useRef<Map<string,MediaStreamAudioSourceNode>>(new Map());
  const stuRoomListenersRef=useRef<{onSub:(...a:any[])=>void;onUnsub:(...a:any[])=>void}|null>(null);
  // Feature 2: Audio-only mode (manual + auto on poor network)
  const[audioOnlyActive,setAudioOnlyActive]=useState(false);
  useScreenWakeLock(phase==="live"&&!audioOnlyActive);
  // Admin/teacher-wide forced audio-only — when true, EVERY participant's camera is
  // off and locked (grey/disabled Cam button) until the admin/teacher reverts it.
  // Broadcast via LiveKit data channel ("force_audio_only") so it applies to
  // everyone in the room, not just the person who toggled it.
  const[forcedAudioOnly,setForcedAudioOnly]=useState(false);
  const toggleForcedAudioOnly=()=>{
    const next=!forcedAudioOnly;
    setForcedAudioOnly(next);
    setAudioOnlyActive(next); // drives AudioOnlyBridge to actually flip the admin's own camera
    try{roomRef.current?.localParticipant?.publishData(new TextEncoder().encode(JSON.stringify({type:"force_audio_only",active:next})),{reliable:true});}catch{}
    toast({title:next?"📵 Audio-only mode ON for everyone — cameras locked off":"🎥 Audio-only mode ended — cameras unlocked"});
  };
  // ── "Allow student video" — live teacher/admin class setting ──
  // Broadcast over the LiveKit data channel for instant effect, and saved into
  // live_sessions.class_settings so a student who joins or reconnects later gets the same answer.
  const applyAllowVideo=useCallback((allow:boolean)=>{
    setSessionSettings(prev=>prev.allow_video===allow?prev:{...prev,allow_video:allow});
  },[]);
  const toggleStudentVideo=async()=>{
    const next=!sessionSettings.allow_video;
    applyAllowVideo(next);
    try{roomRef.current?.localParticipant?.publishData(new TextEncoder().encode(JSON.stringify({type:"allow_video",allow:next})),{reliable:true});}catch{}
    toast({title:next?"🎥 Student video allowed":"📵 Student video turned off",description:next?"Students can turn their cameras on again.":"Student cameras are off and locked until you allow video again."});
    if(!sessionId)return;
    try{
      // Merge — never replace — class_settings, so other keys (mute_on_entry …) survive.
      const{data}=await supabase.from("live_sessions").select("class_settings").eq("id",sessionId).maybeSingle();
      await supabase.from("live_sessions").update({class_settings:{...((data as any)?.class_settings||{}),allow_video:next}} as any).eq("id",sessionId);
    }catch(err){console.warn("[allow_video] could not save class setting:",err);}
  };
  // Keep the setting in step with the database: picks up the saved value on (re)join and any change made
  // from another tab/device, even if a data-channel message was missed.
  useEffect(()=>{
    if(!sessionId||phase!=="live")return;
    let cancelled=false;
    const take=(cs:any)=>{ if(!cancelled&&typeof cs?.allow_video==="boolean")applyAllowVideo(cs.allow_video); };
    supabase.from("live_sessions").select("class_settings").eq("id",sessionId).maybeSingle()
      .then(({data}:any)=>take(data?.class_settings),()=>{});
    const ch=supabase.channel(`class-settings-${sessionId}`)
      .on("postgres_changes",{event:"UPDATE",schema:"public",table:"live_sessions",filter:`id=eq.${sessionId}`},
        (payload:any)=>take(payload.new?.class_settings))
      .subscribe();
    return()=>{cancelled=true;supabase.removeChannel(ch);};
  },[sessionId,phase,applyAllowVideo]);
  // Data-channel message from the teacher: apply it, and tell the student what just happened.
  const onAllowVideoMsg=useCallback((allow:boolean)=>{
    applyAllowVideo(allow);
    if(!isPrivileged)toast({title:allow?"🎥 Teacher allowed student video":"📵 Teacher turned off student video",description:allow?"You can turn your camera on now.":"Your camera is off for now."});
  },[applyAllowVideo,isPrivileged]);
  const stuChunksTop=useRef<Blob[]>([]);
  const stuAddRemoteTrack=(track:any,pub:any)=>{
    try{
      const ac=stuAudioCtxRef.current,dest=stuDestRef.current;
      if(!ac||!dest||!track?.mediaStreamTrack)return;
      if(stuSourceNodesRef.current.has(pub.trackSid))return; // already mixed in
      const ms=new MediaStream([track.mediaStreamTrack]);
      const node=ac.createMediaStreamSource(ms);
      node.connect(stuBusRef.current||dest);
      stuSourceNodesRef.current.set(pub.trackSid,node);
    }catch{}
  };
  const stuRemoveRemoteTrack=(_track:any,pub:any)=>{
    try{
      stuSourceNodesRef.current.get(pub.trackSid)?.disconnect();
      stuSourceNodesRef.current.delete(pub.trackSid);
    }catch{}
  };
  const stuTeardownAudioGraph=()=>{
    const room=roomRef.current;
    if(room&&stuRoomListenersRef.current){
      room.off(RoomEvent.TrackSubscribed,stuRoomListenersRef.current.onSub);
      room.off(RoomEvent.TrackUnsubscribed,stuRoomListenersRef.current.onUnsub);
    }
    stuRoomListenersRef.current=null;
    stuSourceNodesRef.current.forEach(node=>{try{node.disconnect();}catch{}});
    stuSourceNodesRef.current.clear();
    try{stuLocalMicStreamRef.current?.getTracks().forEach(t=>t.stop());}catch{}
    stuLocalMicStreamRef.current=null;
    try{stuAudioCtxRef.current?.close();}catch{}
    stuAudioCtxRef.current=null;
    stuDestRef.current=null;
    stuBusRef.current=null;
  };
  const toggleStuRecordTop=async()=>{
    if(stuRec){
      stuMrRefTop.current?.stop();
      stuMrRefTop.current!.onstop=()=>{
        const mt=stuMrRefTop.current?.mimeType||"audio/webm";
        const blob=new Blob(stuChunksTop.current,{type:mt});
        const url=URL.createObjectURL(blob);
        const a=document.createElement("a");a.href=url;a.download=`class-${Date.now()}.webm`;a.click();URL.revokeObjectURL(url);stuChunksTop.current=[];
        stuTeardownAudioGraph();
      };setStuRec(false);
    }else{
      try{
        const AC=(window as any).AudioContext||(window as any).webkitAudioContext;
        const ac:AudioContext=new AC();
        const dest=ac.createMediaStreamDestination();
        stuAudioCtxRef.current=ac;stuDestRef.current=dest;
        // Speech-cleanup chain (same idea as the teacher's class recording): everyone sums into
        // one bus -> cut rumble -> lift consonants -> even out loud/quiet voices -> limiter -> recorder.
        const bus=ac.createGain();
        const hp=ac.createBiquadFilter();hp.type="highpass";hp.frequency.value=100;
        const presence=ac.createBiquadFilter();presence.type="peaking";presence.frequency.value=3000;presence.Q.value=0.8;presence.gain.value=2;
        const comp=ac.createDynamicsCompressor();comp.threshold.value=-26;comp.knee.value=24;comp.ratio.value=4;comp.attack.value=0.005;comp.release.value=0.25;
        const makeup=ac.createGain();makeup.gain.value=1.6;
        const limiter=ac.createDynamicsCompressor();limiter.threshold.value=-3;limiter.knee.value=0;limiter.ratio.value=20;limiter.attack.value=0.001;limiter.release.value=0.1;
        bus.connect(hp);hp.connect(presence);presence.connect(comp);comp.connect(makeup);makeup.connect(limiter);limiter.connect(dest);
        stuBusRef.current=bus;

        // Own mic — explicit echo/noise cleanup (the other voices are mixed in separately below)
        const localStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true,channelCount:1}});
        stuLocalMicStreamRef.current=localStream;
        ac.createMediaStreamSource(localStream).connect(bus);

        // Everyone else already in the room — teacher + other students —
        // whose audio is currently subscribed (i.e. audible to this student).
        const room=roomRef.current;
        if(room){
          room.remoteParticipants?.forEach?.((p:any)=>{
            p.trackPublications?.forEach?.((pub:any)=>{
              if(pub?.kind==="audio"&&pub.track)stuAddRemoteTrack(pub.track,pub);
            });
          });
          const onSub=(track:any,pub:any)=>{if(track?.kind==="audio")stuAddRemoteTrack(track,pub);};
          const onUnsub=(track:any,pub:any)=>{if(track?.kind==="audio")stuRemoveRemoteTrack(track,pub);};
          room.on(RoomEvent.TrackSubscribed,onSub);
          room.on(RoomEvent.TrackUnsubscribed,onUnsub);
          stuRoomListenersRef.current={onSub,onUnsub};
        }

        const mime=["audio/webm;codecs=opus","audio/webm","audio/mp4","audio/ogg"].find(t2=>{try{return MediaRecorder.isTypeSupported(t2);}catch{return false;}})||"";
        const mr=new MediaRecorder(dest.stream,mime?{mimeType:mime,audioBitsPerSecond:64000}:{audioBitsPerSecond:64000});
        stuChunksTop.current=[];mr.ondataavailable=e=>{if(e.data.size>0)stuChunksTop.current.push(e.data);};
        mr.start(1000);stuMrRefTop.current=mr;setStuRec(true);
      }catch{
        stuTeardownAudioGraph();
        toast({title:"Microphone access denied"});
      }
    }
  };
  // Safety net: if the component unmounts while a student recording is still
  // running (navigated away, minimized past unmount, etc.), stop the mic
  // stream and close the AudioContext instead of leaking them.
  useEffect(()=>{
    return()=>{
      try{stuMrRefTop.current?.stop();}catch{}
      stuTeardownAudioGraph();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[]);
  const[floatingEmojis,setFloatingEmojis]=useState<FloatingEmoji[]>([]);
  const[raisedHands,setRaisedHands]=useState<RaisedHand[]>([]);
  const[layout,setLayout]=useState<LayoutMode>("grid");
  const[groupReciteDialog,setGroupReciteDialog]=useState(false);
  const emojiIdRef=useRef(0);
  const wbBuffer=useRef<any[]|null>(null);
  // FIX BUG 10: roomRef stores the LiveKit Room object via RoomDataListener — replaces __lkRoom__ global
  const roomRef=useRef<any>(null);
  // FIX BUG 8: ref to hold the session-end channel so we can subscribe immediately on join
  const sessionEndChannelRef=useRef<any>(null);

  // ══ NEW FEATURES ══
  // Feature 1: Screen share
  const[screenSharing,setScreenSharing]=useState(false);
  // Feature 3: Desktop participants panel
  const[partPanelOpen,setPartPanelOpen]=useState(false);
  // Feature 5: Live attendance view
  const[attendanceOpen,setAttendanceOpen]=useState(false);
  const[liveAttendees,setLiveAttendees]=useState<any[]>([]);
  // Feature 9: Spotlight a participant
  const[spotlightId,setSpotlightId]=useState<string|null>(null);
  // Feature 10: Countdown timer
  const[timerOpen,setTimerOpen]=useState(false);
  const[timerSeconds,setTimerSeconds]=useState(0);
  const[timerRunning,setTimerRunning]=useState(false);
  const[timerInput,setTimerInput]=useState("5");
  const timerRef=useRef<any>(null);
  // Feature 11: LiveClassFilePanel (in-class materials)
  const[liveFilesOpen,setLiveFilesOpen]=useState(false);
  // Feature 13: Hand queue management
  const[handQueueOpen,setHandQueueOpen]=useState(false);
  // Feature 15: Recording indicator for students
  const[teacherIsRecording,setTeacherIsRecording]=useState(false);
  // Feature 8: Whiteboard laser pointer
  const[laserActive,setLaserActive]=useState(false);
  // Feature 17: Session summary
  const[summaryOpen,setSummaryOpen]=useState(false);
  const[sessionSummary,setSessionSummary]=useState<any>(null);
  // FIX BUG 6: prefetch includes a fetchedAt timestamp so stale tokens can be detected
  const prefetch=useRef<{token:string;url:string;fetchedAt:number;mute_on_entry?:boolean;chat_enabled?:boolean;hand_raise_enabled?:boolean;allow_video?:boolean}|null>(null);
  useEffect(()=>{
    // Initial prefetch
    // prefetch:true tells livekit-token this is only a background warm-up, so a blocked
    // student sitting on the lobby doesn't file a "wants to rejoin" request until they press Join.
    const doFetch=()=>{supabase.functions.invoke("livekit-token",{body:{subject_id:subject.id,action:isPrivileged?"start_session":"join",prefetch:true}}).then(({data})=>{if(data?.token&&data?.url)prefetch.current={token:data.token,url:data.url,fetchedAt:Date.now(),mute_on_entry:data.mute_on_entry,chat_enabled:data.chat_enabled,hand_raise_enabled:data.hand_raise_enabled,allow_video:data.allow_video};}).catch(()=>{});};
    doFetch();
    // Feature 8: Re-fetch every 2.5 min so lobby users never have a stale token
    const iv=setInterval(()=>{if(phase==="lobby")doFetch();},2.5*60_000);
    return()=>clearInterval(iv);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[subject.id,isPrivileged]);
  // AUTO-JOIN (opened from a ring / "Join" link): this used to try exactly ONCE, 120ms after mount. If the
  // user profile or the first render wasn't ready at that instant it silently did nothing — and since the lobby
  // is hidden for auto-join, the screen looked like you were in class while you were not connected, until you
  // opened the lobby and pressed Join Class yourself. Now it keeps trying until everything is ready, shows
  // "Connecting…" meanwhile, and falls back to the normal lobby after 6s so you can always join by hand.
  const autoTriedRef=useRef(false);
  const[autoJoinGaveUp,setAutoJoinGaveUp]=useState(false);
  useEffect(()=>{
    if(!autoJoin||autoTriedRef.current)return;
    if(phase!=="lobby"||loading||error||!user)return;
    const t=setTimeout(()=>{
      if(autoTriedRef.current)return;
      autoTriedRef.current=true;
      connect(isPrivileged?"start_session":"join");
    },120);
    return()=>clearTimeout(t);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[autoJoin,phase,loading,error,user?.id]);
  useEffect(()=>{
    if(!autoJoin)return;
    const g=setTimeout(()=>setAutoJoinGaveUp(true),6000);
    return()=>clearTimeout(g);
  },[autoJoin]);
  useEffect(()=>{const check=async()=>{const{data}=await supabase.from("live_sessions").select("*").eq("subject_id",subject.id).eq("status","live").maybeSingle();if(data){setSessionInfo(data);setSessionId(data.id);setIsSessionLive(true);}else setIsSessionLive(false);};check();const iv=setInterval(check,4000);return()=>clearInterval(iv);},[subject.id]);

  /* ── Student auto-kick: watch DB for session.status → "ended" ────────────
     Two-pronged approach: LiveKit data channel (fast) + Supabase realtime (backup).
     Both converge on setPhase("ended") which shows ClassEndScreen.
     FIX BUG 8: The channel is also stored in sessionEndChannelRef so connect() can
     subscribe immediately when the fresh sessionId is known — before this effect runs. */
  useEffect(()=>{
    if(!sessionId||isPrivileged||phase!=="live")return;
    // BUG FIX — real Supabase Realtime channel leak: this channel is usually
    // created by connect() itself (to close a race-condition window — see
    // BUG FIX 8 comment there), which runs synchronously before this effect
    // even gets a chance to fire. That meant this effect's own subscribe
    // branch was always skipped (`if(sessionEndChannelRef.current)return`),
    // so its cleanup — which only existed inside that same skipped branch —
    // never got registered either. Net effect: the channel connect() opened
    // was NEVER removed by anything, not when the class ended, not even on
    // component unmount. Every class join permanently leaked one open
    // realtime subscription for the lifetime of the tab.
    // Fix: register the cleanup unconditionally, based on whatever is
    // currently in the ref — regardless of which code path put it there —
    // so it's reliably torn down exactly once whenever sessionId/phase
    // changes away from this state, or on unmount.
    if(!sessionEndChannelRef.current){
      const ch=supabase.channel(`session-end-${sessionId}`)
        .on("postgres_changes",{event:"UPDATE",schema:"public",table:"live_sessions",filter:`id=eq.${sessionId}`},
          (payload:any)=>{
            if(payload.new?.status==="ended"&&!intentionalLeaveRef.current){
              // Teacher ended the class
              setPhase("ended");
            }
          })
        .subscribe();
      sessionEndChannelRef.current=ch;
    }
    return()=>{
      if(sessionEndChannelRef.current){supabase.removeChannel(sessionEndChannelRef.current);sessionEndChannelRef.current=null;}
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[sessionId,isPrivileged,phase]);
  useEffect(()=>{if(phase!=="live")return;const ti=setInterval(()=>{durationRef.current+=1;},1000);return()=>clearInterval(ti);},[phase]);

  /* ── Student safety net: poll the session row so a missed data packet / realtime event
     (backgrounded tab, flaky network) can never leave a student stuck in a class the admin ended. ── */
  useEffect(()=>{
    if(!sessionId||isPrivileged||phase!=="live")return;
    const poll=async()=>{
      try{
        const{data}=await supabase.from("live_sessions").select("status").eq("id",sessionId).maybeSingle();
        if(data?.status==="ended"&&!intentionalLeaveRef.current)setPhase("ended");
      }catch{}
    };
    const iv=setInterval(poll,5000);
    return()=>clearInterval(iv);
  },[sessionId,isPrivileged,phase]);

  /* ── Class ended (by the admin/teacher "End for all") → fully close the live state ──
     Before, phase flipped to "ended" but hasConnected stayed true in LiveClassContext, so the
     foreground service, keep-alive audio and the round "live" bubble all kept running and the
     class still looked live. Clearing it here removes all of that; un-minimizing makes sure the
     person lands on the end screen instead of a stale bubble. */
  useEffect(()=>{
    if(phase!=="ended")return;
    setHasConnected(false);
    setMinimized(false);
    setShowEnd(false);setShowLeaveConfirm(false);
    try{playLeaveSound();}catch{}
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[phase]);

  /* ── Minimizing must not leave dialogs/panels floating over the app ──
     These render through createPortal(document.body), which is OUTSIDE the translated overlay,
     so they stayed on screen after minimize and tapping the round icon appeared to show the
     "End class for everyone?" dialog instead of the class. Close them when minimizing. */
  useEffect(()=>{
    if(!minimized)return;
    setShowEnd(false);setShowLeaveConfirm(false);setMatPicker(false);
    setPartPanelOpen(false);setAttendanceOpen(false);setTimerOpen(false);
    setLiveFilesOpen(false);setHandQueueOpen(false);setSummaryOpen(false);
  },[minimized]);
  // NOTE: mediaSession metadata/playbackState/action-handlers are now owned
  // exclusively by GlobalClassroomOverlay + useBackgroundAudio.ts (driven off
  // hasConnected). This component used to ALSO write directly to the same
  // navigator.mediaSession singleton here — two independent writers racing
  // on the same global object, with different metadata (title/album text)
  // and conflicting action handlers (this block nulled out play/pause,
  // silently breaking "tap notification to resume"; the overlay's own
  // stop-handler skipped the recording-save/attendance-log cleanup that
  // leaveSession() below does). That's the most likely cause of the
  // persistent-notification-not-showing / notification-buttons-doing-nothing
  // reports — whichever effect happened to run last won, unpredictably.
  // leaveSession() below is now bridged to the overlay via leaveSessionFnRef
  // so the notification's "stop" button gets the exact same full cleanup as
  // the in-app Leave button, without a second writer touching mediaSession.

  const connect=async(action:string,settings?:any,mediaSettings?:{micOn:boolean;cameraOn:boolean})=>{
    // FIX: capture first-join status in a ref BEFORE setHasConnected(true)/setPhase("live")
    // fire below — see the comment on isFirstJoinPropRef above for why this must happen here.
    isFirstJoinPropRef.current=!everConnectedRef.current;
    everConnectedRef.current=true;
    if(mediaSettings){setLobbyMic(mediaSettings.micOn);setLobbyCam(mediaSettings.cameraOn);}
    // Guard: user must be loaded before inserting attendance rows
    if(!user){setError("Session expired. Please refresh the page.");return;}
    setLoading(true);setError(null);
    try{
      // FIX BUG 6: Consume and clear the prefetch so it is never reused stale.
      // Also check freshness — tokens older than 5 min are discarded (room state may have changed).
      // Token expires — use prefetch only if <3min old (lobby waits can exceed this)
      const isFresh=prefetch.current&&(Date.now()-prefetch.current.fetchedAt)<3*60_000;
      let tk=isFresh?prefetch.current!.token:null;
      let url=isFresh?prefetch.current!.url:null;
      // Class Settings echoed back alongside the token — see the prefetch/livekit-token
      // comments above for why these two are the only places this ever gets set.
      let newSettings={mute_on_entry:false,chat_enabled:true,hand_raise_enabled:true,allow_video:true};
      if(isFresh)newSettings={
        mute_on_entry:!!prefetch.current!.mute_on_entry,
        chat_enabled:prefetch.current!.chat_enabled??true,
        hand_raise_enabled:prefetch.current!.hand_raise_enabled??true,
        allow_video:prefetch.current!.allow_video??true,
      };
      prefetch.current=null; // always clear after reading so Try Again fetches a new token
      if(!tk||!url){
        const{data,error:e}=await supabase.functions.invoke("livekit-token",{body:{subject_id:subject.id,action}});
        if(e)throw e;
        // WAITING-ROOM FLOW: either the host has Waiting Room enabled for this
        // class and this is this student's first join attempt, or an admin/
        // teacher removed-and-blocked this student earlier. Either way,
        // livekit-token returns {pending:true} and records the request
        // server-side so the host's JoinRequestBanner can show an Admit/Deny
        // prompt. Show a "waiting for host" screen here and poll
        // class_participants until it changes.
        if(data?.pending){
          setLoading(false);
          setWaitingDenied(false);
          setWaitingMessage(data.message||"Waiting for the host to respond...");
          waitingSessionIdRef.current=data.session_id||null;
          setPhase("waiting");
          return;
        }
        if(data?.error)throw new Error(data.error);
        tk=data.token;url=data.url;
        newSettings={
          mute_on_entry:!!data.mute_on_entry,
          chat_enabled:data.chat_enabled??true,
          hand_raise_enabled:data.hand_raise_enabled??true,
          allow_video:data.allow_video??true,
        };
      }
      setToken(tk!);setWsUrl(url!);
      setSessionSettings(newSettings);
      // "Allow student video" OFF: a student never starts with their camera on, whatever they picked in the lobby.
      if(!newSettings.allow_video&&!isPrivileged)setLobbyCam(false);
      // Slow / data-saver link: a student starts audio-only (they can still switch the camera on themselves).
      if(isSlowLink()&&!isPrivileged)setLobbyCam(false);
      // "Mute on entry": force the initial mic publish off for a non-privileged
      // joiner, regardless of what they picked in the lobby — same pattern as
      // camLocked's forced-audio-only further down, just applied once up front
      // instead of broadcast live. An admin/teacher is never muted by their
      // own class's setting.
      if(newSettings.mute_on_entry&&!isPrivileged)setLobbyMic(false);

      // FIX ("takes a while before showing my full details"): flip to the live
      // phase — which is what actually tells <LiveKitRoom> to connect — the
      // moment we have a token, instead of waiting on the session lookup +
      // attendance_logs + class_participants writes below. Those are DB
      // bookkeeping, not prerequisites for joining the room (the LiveKit room
      // itself is keyed off subject.id, not session_id), so they used to add
      // 3-4 extra sequential network round trips before anyone saw video/name.
      // They now run in the background (see bookkeeping IIFE below) and just
      // fill in sessionId/attendanceId/etc. a moment later.
      setPhase("live");
      setHasConnected(true);   // unlock overlay PiP/minimize — user is now in the class
      try { playJoinSound(); } catch {}

      // ── Background session bookkeeping — does NOT block the room connecting ──
      (async()=>{
        try{
          // FIX: pick the session that is ACTUALLY live/active first, only falling back to a
          // merely-scheduled row if none is live. Sorting by scheduled_at alone was wrong: a
          // future pre-scheduled occurrence of a recurring class always has a later scheduled_at
          // than today's already-live session, so it was being picked instead — causing students'
          // attendance_logs/class_participants rows to be written against the wrong session_id.
          // The LiveKit call itself still worked (room name is keyed off subject_id, not session
          // id), but the admin dashboard's participant count — looked up by the real live
          // session's id — found nothing, showing 0 while people were actually in the class.
          const{data:liveRows}=await supabase.from("live_sessions").select("*").eq("subject_id",subject.id).in("status",["live","active"]).order("actual_start_time",{ascending:false,nullsFirst:false}).limit(1);
          let sessions=liveRows;
          if(!sessions?.length){
            // FIX: was ordering scheduled rows by scheduled_at DESCENDING, which
            // picked the FURTHEST-FUTURE occurrence of a recurring class instead
            // of today's — same class of bug as the live-row fix above, just
            // inverted. Whoever joined first (before anyone flipped status to
            // "live") got attached to that future row, which then got marked
            // live and absorbed all the real class_participants/attendance
            // writes, while today's session card stayed stuck at 0 forever.
            // Nearest-to-now (soonest upcoming, or most-recently-overdue)
            // is what "today's session" actually means here.
            const{data:scheduledRows}=await supabase.from("live_sessions").select("*").eq("subject_id",subject.id).eq("status","scheduled").order("scheduled_at",{ascending:true,nullsFirst:false}).limit(1);
            sessions=scheduledRows;
          }
          if(sessions?.length){
            const freshSessionId=sessions[0].id;
            // FIX BUG 1: Apply class settings using the freshly-retrieved session ID, not the
            // stale sessionId state (which is null when a teacher starts a new class for the first time).
            // FIX: a session must flip to "live" whenever ANYONE connects to the room — student,
            // teacher, or admin — not only when settings are present (which used to mean only the
            // start_session action, i.e. teacher/admin, could ever move status out of "scheduled").
            // A student joining an unstarted-but-scheduled class now marks it live too.
            const alreadyLive=sessions[0].status==="live"||sessions[0].status==="active";
            const liveUpdate:any={...(settings||{})};
            // MERGE class_settings instead of replacing the whole JSON column — the lobby only knows a few keys,
            // and a plain replace wiped anything the admin had saved when scheduling (e.g. allow_video).
            if(settings?.class_settings)liveUpdate.class_settings={...(sessions[0].class_settings||{}),...settings.class_settings};
            if(!alreadyLive){liveUpdate.status="live";liveUpdate.actual_start_time=sessions[0].actual_start_time||new Date().toISOString();}
            if(Object.keys(liveUpdate).length){await supabase.from("live_sessions").update(liveUpdate).eq("id",freshSessionId);}
            setSessionId(freshSessionId);setSessionInfo(alreadyLive?sessions[0]:{...sessions[0],...liveUpdate});
            // Students can't UPDATE live_sessions / INSERT notifications under RLS, so the old client-side
            // "mark live" silently failed for them. This RPC (SECURITY DEFINER) flips the class live for
            // ANY joiner and notifies: student joined -> admins + class teacher; teacher/admin joined -> students.
            // Deduped per (session,user) server-side, so rejoining after a drop never re-notifies.
            try{(supabase as any).rpc("announce_class_join",{_subject_id:subject.id,_session_id:freshSessionId}).then((r:any)=>{if(r?.error)console.warn("[announce_class_join]",r.error.message);},()=>{});}catch{}
            // FIX: check for an attendance_logs row this student already has for
            // this exact session (from an earlier stint that disconnected/logged
            // out) before inserting a new one. Reusing it means a rejoin shows up
            // as ONE continuous attendance record instead of a duplicate entry.
            const{data:existingAtt}=await supabase.from("attendance_logs").select("id,duration_seconds").eq("session_id",freshSessionId).eq("user_id",user.id).maybeSingle();
            if(existingAtt){
              attPriorDurationRef.current=existingAtt.duration_seconds||0;
              setAttendanceId(existingAtt.id);
              await supabase.from("attendance_logs").update({left_at:null,device_info:navigator.userAgent}).eq("id",existingAtt.id);
            }else{
              attPriorDurationRef.current=0;
              const{data:att}=await supabase.from("attendance_logs").insert({session_id:freshSessionId,user_id:user.id,device_info:navigator.userAgent}).select("id").single();
              if(att)setAttendanceId(att.id);
            }
            {
              // FIX: this used to also send `left_minutes:null`, a column that does not exist on
              // class_participants. PostgREST rejected the whole upsert, and because supabase-js
              // returns {error} instead of throwing, it failed SILENTLY — no participant row was
              // ever saved, so the admin Live Classes page showed 0 while people were in the room.
              const{error:partErr}=await supabase.from("class_participants").upsert({session_id:freshSessionId,student_id:user.id,joined_at:new Date().toISOString(),is_muted:!isPrivileged,camera_on:true,left_at:null,duration_minutes:0},{onConflict:"session_id,student_id"});
              if(partErr)console.warn("[ClassroomView] class_participants upsert failed:",partErr.message);
            }
            // FIX BUG 8: Subscribe to session-end immediately here — before the useEffect cycle —
            // so there is no window where the teacher can end the class and students miss the event.
            if(!isPrivileged&&!sessionEndChannelRef.current){
              const endCh=supabase.channel(`session-end-${freshSessionId}`)
                .on("postgres_changes",{event:"UPDATE",schema:"public",table:"live_sessions",filter:`id=eq.${freshSessionId}`},
                  (payload:any)=>{if(payload.new?.status==="ended"&&!intentionalLeaveRef.current)setPhase("ended");})
                .subscribe();
              sessionEndChannelRef.current=endCh;
            }
          }
        }catch(bookkeepErr){
          // Non-fatal: the call itself is already connected. Attendance/participant
          // rows just won't be recorded for this join — log for diagnosis instead
          // of surfacing an error screen over an otherwise-working class.
          console.warn("[ClassroomView] session bookkeeping failed:",bookkeepErr);
        }
      })();
    }catch(e:any){setError(e?.message||"Failed to connect");}finally{setLoading(false);}
  };

  /* ══ AUTO-RECONNECT ══
     Fires when LiveKit emits Disconnected unexpectedly (e.g. Android tab suspension).
     Uses refs for count + in-progress flag so the useCallback is stable (no deps that
     change mid-session). A stable callback means ReconnectMonitor never re-registers
     its event listeners mid-reconnect — which was the root cause of the infinite loop. */
  const autoReconnect=useCallback(async()=>{
    // Guard 1: user manually left — never auto-reconnect
    if(intentionalLeaveRef.current)return;
    // Guard 2: already mid-reconnect — don't stack concurrent calls
    if(isReconnectingRef.current)return;

    // Guard 3: exhausted retries — give up and drop back to lobby.
    // CHANGED: the retry budget now depends on whether the tab is visible.
    // Foreground: fail fast (8 attempts, ~90s total) so a watching user gets
    // an honest "connection lost" message instead of an endless spinner.
    // Background: be far more patient (40 attempts, longer backoff cap) —
    // a minimized/locked-screen user can't see a spinner or an error either
    // way, so silently giving up after ~90s just means the call is dead by
    // the time they come back for no good reason. Give the network more
    // chances to recover first.
    const backgrounded   = document.visibilityState !== "visible";
    // Attempts made while Android had the WebView backgrounded must not spend
    // the foreground retry budget. Otherwise returning after a long lock could
    // immediately send the user to the lobby before the first visible retry.
    if(!backgrounded&&backgroundReconnectRef.current){
      backgroundReconnectRef.current=false;
      autoReconnectCountRef.current=0;
    }
    if(backgrounded)backgroundReconnectRef.current=true;
    // Foreground retries are now quick (first one instant, cap 2s), so the budget
    // is counted in attempts of ~2s each: 30 attempts ≈ a minute of trying.
    const maxAttempts     = backgrounded ? 40 : 30;
    const backoffCapMs    = backgrounded ? 30_000 : 2_000;
    if(autoReconnectCountRef.current>=maxAttempts){
      setReconnecting(false);
      setError("Connection lost after several attempts. Please try again.");
      setPhase("lobby");
      setHasConnected(false);
      return;
    }
    isReconnectingRef.current=true;
    setReconnecting(true);
    // Exponential backoff, capped higher while backgrounded so we don't
    // hammer the token endpoint for minutes on end. Base lowered from 1000ms
    // to 400ms so the FIRST retry (by far the most common case — a brief
    // network blip) fires almost immediately: combined with the 1s drop
    // debounce above, a normal reconnect now completes in ~2-3s instead of
    // several seconds, while later attempts still back off further apart.
    // Foreground: first retry fires immediately (0ms), then 0.6s, 0.9s, 1.4s, 2s…
    // Background keeps the old patient exponential schedule.
    const backoffMs=(!backgrounded&&autoReconnectCountRef.current===0)
      ?0
      :Math.min(400*Math.pow(backgrounded?2:1.5,autoReconnectCountRef.current),backoffCapMs);
    await new Promise(r=>setTimeout(r,backoffMs));
    try{
      const{data}=await supabase.functions.invoke("livekit-token",{body:{subject_id:subject.id,action:isPrivileged?"start_session":"join"}});
      // Banned from this specific session by an admin/teacher (or Waiting Room
      // caught them again after a drop) — don't burn through the retry budget,
      // the answer won't change until the host responds. Drop straight to the
      // waiting screen instead of a generic "connection lost" after ~90s of
      // pointless retries.
      if(data?.pending){
        isReconnectingRef.current=false;
        setReconnecting(false);
        setWaitingDenied(false);
        setWaitingMessage(data.message||"Waiting for the host to respond...");
        waitingSessionIdRef.current=data.session_id||null;
        setPhase("waiting");
        setHasConnected(false);
        return;
      }
      if(data?.error&&/removed from this class/i.test(data.error)){
        isReconnectingRef.current=false;
        setReconnecting(false);
        setError(data.error);
        setPhase("lobby");
        setHasConnected(false);
        return;
      }
      if(data?.token&&data?.url){
        prefetch.current={token:data.token,url:data.url,fetchedAt:Date.now(),mute_on_entry:data.mute_on_entry,chat_enabled:data.chat_enabled,hand_raise_enabled:data.hand_raise_enabled,allow_video:data.allow_video};
        setSessionSettings({mute_on_entry:!!data.mute_on_entry,chat_enabled:data.chat_enabled??true,hand_raise_enabled:data.hand_raise_enabled??true,allow_video:data.allow_video??true});
        autoReconnectCountRef.current+=1;  // ref — won't trigger useCallback recreation
        setToken(data.token);
        setWsUrl(data.url);
        setRoomKey(k=>k+1); // remount LiveKitRoom with fresh token
        // Do NOT setReconnecting(false) here — overlay stays up until the new room
        // fires Connected, which triggers onReconnected → setReconnecting(false).
      }else{
        // Token fetch returned no usable data — retry rather than giving up
        // on the very first failure (this used to bail immediately, which
        // meant a single network blip — common while backgrounded — killed
        // the whole retry budget instead of using it).
        autoReconnectCountRef.current+=1;
        isReconnectingRef.current=false;
        autoReconnect();
      }
    }catch{
      // Network/edge-function error — same reasoning: retry through the
      // normal backoff loop instead of surrendering on attempt 1.
      autoReconnectCountRef.current+=1;
      isReconnectingRef.current=false;
      autoReconnect();
    }
    // No finally{setReconnecting(false)} — success path is cleared by onReconnected
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[subject.id,isPrivileged]); // stable — refs handle mutable values

  /* ══ REMOVED BY THE HOST ══
     Fired by ReconnectMonitor when LiveKit reports PARTICIPANT_REMOVED (the host
     used "Remove from call" / "Remove & block"). That is a deliberate removal, not
     a network drop, so we must NOT run autoReconnect (it would fetch a new token
     and put the student straight back in, leaving them on "Disconnected —
     reconnecting…"). Instead: end the live call and return the student to the
     lobby — the screen they saw before joining. From there, a plain removal lets
     them press Join again; a block sends them to the "waiting for the host"
     screen (livekit-token), and the host gets an Admit / Deny prompt. */
  const handleRemovedByHost=useCallback(()=>{
    isReconnectingRef.current=false;
    autoReconnectCountRef.current=0;
    prefetch.current=null;       // never reuse a token minted before the removal
    setReconnecting(false);
    setHasConnected(false);
    setToken(null);
    setPhase("lobby");
    toast({title:"You were removed from the class by the host",variant:"destructive"});
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[]);

  useEffect(()=>()=>{
    if(attendanceId){const d=attPriorDurationRef.current+Math.floor((Date.now()-joinedAt)/1000);supabase.from("attendance_logs").update({left_at:new Date().toISOString(),duration_seconds:d}).eq("id",attendanceId);}
    if(sessionId&&user)supabase.from("class_participants").update({left_at:new Date().toISOString(),duration_minutes:Math.floor((Date.now()-joinedAt)/60000)}).eq("session_id",sessionId).eq("student_id",user.id);
  },[attendanceId,joinedAt,sessionId,user]);

  const endSession=async()=>{
    // FAST PATH ("takes time before it can close"): the old version awaited the recording
    // upload (up to ~21s) BEFORE telling anyone the class was over, so the class stayed
    // "live" for everybody and the button looked frozen. Now: tell the room + DB first,
    // show the end screen immediately, and let the recording finish saving in the background
    // (DirectRecorder keeps the file on-device and retries, so nothing is lost).
    intentionalLeaveRef.current=true; // prevent auto-reconnect on disconnect
    setShowEnd(false);
    const nowIso=new Date().toISOString();
    const endPatch={status:"ended",ended_at:nowIso,actual_end_time:nowIso};
    // Start stopping the recorder now (MediaRecorder stops synchronously inside), don't wait for the upload.
    let recDone:Promise<any>=Promise.resolve();
    try{recDone=Promise.resolve(recStopRef.current?.()).catch(()=>{});}catch{}
    // 1) Broadcast over LiveKit so connected students leave instantly (works even if sessionId is still unresolved).
    const room=roomRef.current;
    try{room?.localParticipant?.publishData(new TextEncoder().encode(JSON.stringify({type:"class_ended"})),{reliable:true});}catch(err){console.warn("[endSession] LiveKit broadcast failed:",err);}
    // 2) End EVERY live/active session of this subject, not only the one we think we're in — a stale or
    //    unresolved sessionId (or a duplicate live row) is what left classes showing "live" after ending.
    const dbDone=(async()=>{
      try{
        await supabase.from("live_sessions").update(endPatch as any).eq("subject_id",subject.id).in("status",["live","active"]);
        if(sessionId)await supabase.from("live_sessions").update(endPatch as any).eq("id",sessionId).neq("status","ended");
      }catch(e:any){console.error("[endSession] DB error (continuing anyway):",e?.message);}
    })();
    if(isPrivileged)setShowAttendanceReview(true); // pop up immediately instead of waiting on the notification
    // Give the data packet a beat to leave the socket, then close the room and show the end screen.
    await new Promise(r=>setTimeout(r,250));
    try{room?.disconnect();}catch{}
    setPhase("ended");
    // 3) Everything else is bookkeeping — run it after the screen has already switched.
    (async()=>{
      await dbDone;
      if(sessionId){
        if(user)syncManualAttendanceFromSession(sessionId,subject,user.id).catch(()=>{});
        if(user){try{await supabase.from("class_chat_messages").insert({session_id:sessionId,sender_id:user.id,message:t("Class has ended","انتهت الحصة"),type:"system"});}catch{}}
        setTimeout(async()=>{
          try{await supabase.from("class_chat_messages").delete().eq("session_id",sessionId);}
          catch(e){console.warn("[endSession] chat clear failed:",e);}
        },4000);
      }
      await recDone;
    })();
  };

  const leaveSession=async()=>{
    intentionalLeaveRef.current=true; // prevent auto-reconnect on disconnect
    // Stop the recorder now but DON'T wait for the upload (up to ~21s) before closing —
    // that wait is why Leave/End felt frozen. DirectRecorder keeps the file on-device and
    // finishes uploading in the background, so nothing is lost.
    // Leave (not End): KEEP the recording open — it pauses now and continues in the same file when
    // the teacher rejoins. Only if there's nothing to keep do we stop it the old way.
    let recKept=false;
    try{recKept=!!(sessionId&&getActiveRecorder(sessionId)?.suspendForLeave());}catch{}
    if(!recKept){try{void Promise.resolve(recStopRef.current?.()).catch(()=>{});}catch{}}
    try{playLeaveSound();}catch{}
    if(attendanceId){const d=attPriorDurationRef.current+Math.floor((Date.now()-joinedAt)/1000);supabase.from("attendance_logs").update({left_at:new Date().toISOString(),duration_seconds:d}).eq("id",attendanceId);}
    if(sessionId&&user)supabase.from("class_participants").update({left_at:new Date().toISOString(),duration_minutes:Math.floor((Date.now()-joinedAt)/60000)}).eq("session_id",sessionId).eq("student_id",user.id);
    onLeave();
  };

  // Bridge leaveSession() up to GlobalClassroomOverlay via context ref, so
  // the lock-screen notification's "stop" button (and the Android foreground
  // service, if it ever needs to trigger a leave) run this exact same
  // recording-save / attendance-log / leave-sound cleanup instead of a bare
  // leaveClass() that would silently skip all of it.
  useEffect(()=>{
    leaveSessionFnRef.current=leaveSession;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[leaveSession]);

  const handlePermChange=(type:"write"|"rec",allow:boolean,room?:any)=>{
    if(type==="write"){setCanStudentWrite(allow);try{room?.localParticipant?.publishData(new TextEncoder().encode(JSON.stringify({type:"wb_allow_write",allow})),{reliable:true});}catch{}toast({title:allow?"✅ Students can now write on the board":"🔒 Write access revoked"});}
    else{setCanStudentRec(allow);try{room?.localParticipant?.publishData(new TextEncoder().encode(JSON.stringify({type:"rec_allowed",allow})),{reliable:true});}catch{}toast({title:allow?"✅ Students can now record":"🔒 Record permission revoked"});}
  };
  const addFloatingEmoji=(emoji:string,sender:string="")=>{
    const id=++emojiIdRef.current;
    const x=5+Math.random()*70;
    setFloatingEmojis(prev=>[...prev,{id,emoji,x,sender}]);
    setTimeout(()=>setFloatingEmojis(prev=>prev.filter(fe=>fe.id!==id)),2800);
  };
  const handleHandRaise=(identity:string,name:string,raised:boolean)=>{
    setRaisedHands(prev=>{
      if(raised)return prev.some(h=>h.identity===identity)?prev:[...prev,{identity,name,raisedAt:Date.now()}];
      return prev.filter(h=>h.identity!==identity);
    });
  };
  const handleGroupRecite=async(room?:any)=>{
    const n=!groupRecite;
    setGroupRecite(n);
    toast({title:n?"🎙️ Group Recitation ON — all mics enabled":"🔇 Group Recitation ended"});
    try{room?.localParticipant?.publishData(new TextEncoder().encode(JSON.stringify({type:"group_recite",active:n})),{reliable:true});}catch{}
    if(sessionId&&user)await supabase.from("class_chat_messages").insert({session_id:sessionId,sender_id:user.id,message:n?"🎙️ Group Recitation Mode — all mics ON":"🔇 Recitation ended",type:"system"});
  };
  const handleGroupReciteFromTeacher=(active:boolean)=>{
    setGroupRecite(active);
    if(active&&!isPrivileged){setGroupReciteDialog(true);}
    else if(!active&&!isPrivileged){setGroupReciteDialog(false);}
  };

  // ══ Feature 1: Screen Share ══
  // Android app: the WebView can't capture the screen, so a native plugin does it
  useEffect(()=>{
    if(!canNativeScreenShare())return;
    const off=onNativeScreenShareStopped(()=>{setScreenSharing(false);toast({title:"Screen share stopped"});});
    return()=>{off();stopNativeScreenShare();};
  },[]);

  const toggleScreenShare=async()=>{
    const room=roomRef.current;
    if(!room?.localParticipant)return;
    if(canNativeScreenShare()){
      try{
        if(screenSharing){
          await stopNativeScreenShare();
          setScreenSharing(false);
          toast({title:"Screen share stopped"});
        }else{
          await startNativeScreenShare({subjectId:subject?.id,sessionId});
          setScreenSharing(true);
          toast({title:"Screen sharing started",description:"The class can now see your whole screen"});
        }
      }catch(e:any){
        setScreenSharing(false);
        const cancelled=e?.code==="DENIED"||/denied|cancel/i.test(e?.message||"");
        toast({title:cancelled?"Screen share cancelled":"Screen share failed",description:cancelled?"Tap Share again and allow screen capture":(e?.message||"Could not start screen share"),variant:"destructive"});
      }
      return;
    }
    try{
      if(screenSharing){
        await room.localParticipant.setScreenShareEnabled(false);
        setScreenSharing(false);
        toast({title:"Screen share stopped"});
      }else{
        await room.localParticipant.setScreenShareEnabled(true,{audio:true,systemAudio:"exclude",resolution:{width:1920,height:1080,frameRate:15},contentHint:"detail"} as any);
        setScreenSharing(true);
        toast({title:"📺 Screen sharing started"});
      }
    }catch(e:any){
      setScreenSharing(false);
      if(e?.name==="NotAllowedError"||e?.name==="PermissionDeniedError"){
        toast({title:"Screen share permission denied",description:"Allow screen capture in your browser settings",variant:"destructive"});
      }else if(e?.name==="NotSupportedError"||e?.message?.includes("not supported")||e?.message?.includes("getDisplayMedia")){
        toast({title:"Screen share not supported",description:"Screen sharing isn't available on this device yet.",variant:"destructive"});
      }else{
        toast({title:"Screen share failed",description:e?.message||"Could not start screen share",variant:"destructive"});
      }
    }
  };

  // ══ Feature 5: Live Attendance ══
  useEffect(()=>{
    if(!sessionId||!isPrivileged||!attendanceOpen)return;
    const load=async()=>{
      const{data}=await supabase.from("class_participants").select("student_id, joined_at, profiles!inner(full_name)").eq("session_id",sessionId);
      setLiveAttendees(data||[]);
    };
    load();
    const ch=supabase.channel(`attendance-live-${sessionId}`)
      .on("postgres_changes",{event:"INSERT",schema:"public",table:"class_participants",filter:`session_id=eq.${sessionId}`},load)
      .subscribe();
    return()=>{supabase.removeChannel(ch);};
  },[sessionId,isPrivileged,attendanceOpen]);

  // ══ Waiting-room: student side — listen for the host's Admit/Deny ══
  // While phase==="waiting" we don't hold a LiveKit connection at all (we
  // were refused a token), so a data-channel message from the host isn't
  // possible here — Postgres realtime on our own class_participants row is
  // the only channel available. is_banned flips false → host admitted us,
  // auto-retry the join immediately. join_request_status flips to 'denied'
  // → tell the student plainly instead of leaving them waiting forever.
  useEffect(()=>{
    if(phase!=="waiting"||!user||!waitingSessionIdRef.current)return;
    const sid=waitingSessionIdRef.current;
    const check=async()=>{
      const{data}=await supabase.from("class_participants")
        .select("is_banned, join_request_status")
        .eq("session_id",sid).eq("student_id",user.id).maybeSingle();
      if(!data)return;
      if(!data.is_banned){
        toast({title:"✅ You've been admitted — joining..."});
        setPhase("lobby");
        connect("join");
      }else if(data.join_request_status==="denied"){
        setWaitingDenied(true);
        setWaitingMessage("The host declined your request to join.");
      }
    };
    const ch=supabase.channel(`join-request-${sid}-${user.id}`)
      .on("postgres_changes",{event:"UPDATE",schema:"public",table:"class_participants",filter:`session_id=eq.${sid}`},check)
      .subscribe();
    // Run once immediately too — the row may already reflect admit/deny from
    // before this screen even mounted (e.g. a previously-denied request, or
    // an admit that landed while we were still fetching the token), instead
    // of only finding out on the next realtime event or the 5s backstop poll.
    check();
    // Realtime can occasionally miss an event on a flaky connection — a slow
    // poll as a backstop costs nothing while just sitting on a waiting screen.
    const iv=setInterval(check,5000);
    return()=>{supabase.removeChannel(ch);clearInterval(iv);};
  },[phase,user]);

  // ══ Feature 10: Countdown Timer ══
  useEffect(()=>{
    if(!timerRunning||timerSeconds<=0)return;
    timerRef.current=setInterval(()=>{
      setTimerSeconds(s=>{
        if(s<=1){
          clearInterval(timerRef.current);
          setTimerRunning(false);
          toast({title:"⏰ Time's up!"});
          // Broadcast bell sound via data channel
          try{roomRef.current?.localParticipant?.publishData(
            new TextEncoder().encode(JSON.stringify({type:"class_bell",message:"Time's up!"})),{reliable:true}
          );}catch{}
          return 0;
        }
        return s-1;
      });
    },1000);
    return()=>clearInterval(timerRef.current);
  },[timerRunning]);

  const startTimer=()=>{
    const secs=parseInt(timerInput)*60;
    if(!secs||secs<1)return;
    setTimerSeconds(secs);
    setTimerRunning(true);
    setTimerOpen(false);
    // Broadcast to students
    try{roomRef.current?.localParticipant?.publishData(
      new TextEncoder().encode(JSON.stringify({type:"timer_start",seconds:secs})),{reliable:true}
    );}catch{}
    toast({title:`⏱️ ${timerInput}-minute timer started`});
  };
  const stopTimer=()=>{clearInterval(timerRef.current);setTimerRunning(false);setTimerSeconds(0);};
  const fmtTimer=(s:number)=>`${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`;

  // ══ Feature 15: Recording start/stop — sound + spoken announcement ══
  // heard by EVERYONE in the room (admin/teacher included), driven off the
  // is_recording flag on live_sessions rather than a local click handler —
  // that way it's one consistent source of truth instead of the person who
  // clicked Record getting a different (or no) notification than everyone
  // else. Previously this subscription only ran for students and only drove
  // a silent visual indicator; no one — including the person recording —
  // ever heard anything.
  useEffect(()=>{
    if(!sessionId)return;
    let cancelled=false;
    // Tracks the last known is_recording value so we can tell a genuine
    // start/stop transition apart from the live_sessions row being updated
    // for some unrelated reason (which would otherwise re-announce the same
    // state). Seeded from a one-time fetch on mount so joining an
    // already-recording class doesn't fire a false "started" announcement.
    const lastKnown:{current:boolean|null}={current:null};
    supabase.from("live_sessions").select("is_recording").eq("id",sessionId).maybeSingle()
      .then(({data}:any)=>{
        if(cancelled)return;
        const initial=typeof data?.is_recording==="boolean"?data.is_recording:false;
        lastKnown.current=initial;
        setTeacherIsRecording(initial);
      },()=>{});
    const ch=supabase.channel(`rec-indicator-${sessionId}`)
      .on("postgres_changes",{event:"UPDATE",schema:"public",table:"live_sessions",filter:`id=eq.${sessionId}`},
        (payload:any)=>{
          const next=payload.new?.is_recording;
          if(typeof next!=="boolean")return;
          setTeacherIsRecording(next);
          if(lastKnown.current!==null&&lastKnown.current!==next){
            try{ next?playRecordingStartSound():playRecordingStopSound(); }catch{}
          }
          lastKnown.current=next;
        }
      ).subscribe();
    return()=>{cancelled=true;supabase.removeChannel(ch);};
  },[sessionId]);

  // ══ Feature 17: Session Summary ══
  const generateSessionSummary=async()=>{
    if(!sessionId)return;
    const[{data:msgs},{data:pollData},{data:attendData}]=await Promise.all([
      supabase.from("class_chat_messages").select("*").eq("session_id",sessionId).order("created_at"),
      supabase.from("class_polls").select("*,class_poll_answers(*)").eq("session_id",sessionId),
      supabase.from("class_participants").select("student_id,joined_at,profiles!inner(full_name)").eq("session_id",sessionId),
    ]);
    setSessionSummary({
      duration:fmtT(durationRef.current),
      messageCount:msgs?.length||0,
      pollCount:pollData?.length||0,
      attendeeCount:attendData?.length||0,
      attendees:attendData||[],
      polls:pollData||[],
      highlights:(msgs||[]).filter((m:any)=>m.is_pinned),
    });
    setSummaryOpen(true);
  };
  const fmtT=(s:number)=>`${String(Math.floor(s/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`;

  // ── Device-aware video quality ──────────────────────────────────────────
  // "clear on PC, but shouldn't eat mobile data": with simulcast, the
  // SENDER encodes and uploads every listed layer simultaneously — the
  // SFU then hands each individual VIEWER whichever single layer suits
  // their own downlink, so a viewer's download cost was already adaptive.
  // What wasn't adaptive is the PUBLISHER'S upload cost: a mobile student
  // publishing their camera was uploading the exact same 3-layer stack
  // (180p+360p+720p, up to ~2.15 Mbps combined) as someone on a PC/WiFi,
  // regardless of the mobile connection or data plan underneath them.
  // Capture *resolution* (videoCaptureDefaults below) doesn't itself cost
  // network data — it's purely local, feeding the encoder — the actual
  // data cost is the encoded bitrate of each simulcast layer, which is
  // what differs between these two profiles.
  // Teachers/admins are the one or two people everyone is watching full-screen, so they
  // always publish the sharp PC-grade stack, even from a phone (480p upscaled onto a
  // portrait phone screen is what made the admin's video look blurry).
  const lowDataProfile = isMobile && !isPrivileged;
  // Teachers/admins on a PHONE: still sharp (540p) for what they show — handwriting, notebook —
  // but 2 layers / 24fps / ~700kbps instead of the 3-layer 720p@30 PC stack, which a phone
  // cannot encode without overheating. PC/laptop teachers are unchanged.
  const privilegedMobile = isMobile && isPrivileged;
  const videoQualityProfile = privilegedMobile ? {
    videoEncoding:{maxBitrate:700_000,maxFramerate:24},
    simulcastLayers:[
      {width:320,height:180,resolution:{width:320,height:180,frameRate:15},encoding:{maxBitrate:150_000,maxFramerate:15}},
      {width:960,height:540,resolution:{width:960,height:540,frameRate:24},encoding:{maxBitrate:700_000,maxFramerate:24}},
    ],
  } : lowDataProfile ? {
    // Mobile: two layers instead of three, capped well below PC's — this
    // roughly halves worst-case upload versus the PC profile, while the
    // top layer (480p@30fps/500kbps) is still clearly sharp for a phone
    // screen or a name-pill-sized tile on someone else's grid.
    videoEncoding:{maxBitrate:450_000,maxFramerate:20},
    simulcastLayers:[
      {width:180,height:180,resolution:{width:180,height:180,frameRate:15},encoding:{maxBitrate:90_000,maxFramerate:15}},
      {width:480,height:480,resolution:{width:480,height:480,frameRate:20},encoding:{maxBitrate:320_000,maxFramerate:20}},
    ],
  } : {
    // PC/laptop: unchanged from before — full 3-layer stack, sharp 720p top.
    videoEncoding:{maxBitrate:1_500_000,maxFramerate:30},
    simulcastLayers:[
      {width:320,height:180,resolution:{width:320,height:180,frameRate:15},encoding:{maxBitrate:150_000,maxFramerate:15}},
      {width:640,height:360,resolution:{width:640,height:360,frameRate:24},encoding:{maxBitrate:500_000,maxFramerate:24}},
      {width:1280,height:720,resolution:{width:1280,height:720,frameRate:30},encoding:{maxBitrate:1_500_000,maxFramerate:30}},
    ],
  };

  if(phase==="ended")return<>
    <ClassEndScreen subject={subject} session={sessionInfo} duration={durationRef.current} participantCount={participantCountRef.current} onGoToDashboard={onLeave} onGoToRevision={()=>{window.location.href=`/student/revision/${subject.id}`;}} />
    {isPrivileged&&showAttendanceReview&&sessionId&&(
      <AttendanceQuickReview sessionId={sessionId} subject={subject} onDone={()=>setShowAttendanceReview(false)} />
    )}
  </>;
  if(phase==="waiting")return(
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:16,height:"100dvh",background:"#202124",padding:24,textAlign:"center"}}>
      {!waitingDenied&&<Loader2 style={{width:36,height:36,color:"#8696a0",animation:"spin 1.2s linear infinite"}}/>}
      <p style={{color:"#fff",fontSize:16,fontWeight:600,maxWidth:420}}>
        {waitingDenied?"Request declined":"Waiting for the host"}
      </p>
      <p style={{color:"rgba(255,255,255,.6)",fontSize:13,maxWidth:360}}>{waitingMessage}</p>
      <div style={{display:"flex",gap:10,marginTop:8}}>
        {waitingDenied&&(
          <Button onClick={()=>connect("join")}>Ask again</Button>
        )}
        <Button variant="outline" onClick={onLeave}>Leave</Button>
      </div>
    </div>
  );
  if(phase==="lobby"&&!loading&&!error&&(!autoJoin||autoJoinGaveUp))return<ClassLobby subject={subject} session={sessionInfo} onStartClass={(s:any,media?:any)=>connect("start_session",s,media)} onJoinClass={(media?:any)=>connect("join",undefined,media)} onBack={onLeave} isLive={isSessionLive}/>;
  if(loading||(phase==="lobby"&&autoJoin&&!autoJoinGaveUp&&!error))return(
    <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"100dvh",background:"#202124"}}>
      <style>{CSS}</style>
      <div style={{textAlign:"center"}}>
        <div style={{width:56,height:56,border:"3px solid rgba(138,180,248,.2)",borderTopColor:"#8ab4f8",borderRadius:"50%",animation:"cv-spin .8s linear infinite",margin:"0 auto 20px"}}/>
        <p style={{color:"rgba(255,255,255,.55)",fontSize:15,fontFamily:"'Google Sans',sans-serif",fontWeight:500}}>{t("Connecting…","جاري الاتصال…")}</p>
      </div>
    </div>
  );
  if(error)return(
    <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"100dvh",background:"#202124"}}>
      <style>{CSS}</style>
      <div style={{textAlign:"center",maxWidth:340,padding:32}}>
        <div style={{width:68,height:68,borderRadius:"50%",background:"rgba(234,67,53,.1)",border:"1px solid rgba(234,67,53,.2)",display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 20px"}}>
          <X style={{width:28,height:28,color:"#ea4335"}}/>
        </div>
        <h2 style={{fontSize:22,fontWeight:500,color:"#e8eaed",marginBottom:10,fontFamily:"'Google Sans Display',sans-serif"}}>Connection failed</h2>
        <p style={{color:"rgba(255,255,255,.45)",fontSize:14,marginBottom:28,lineHeight:1.6,fontFamily:"'Google Sans',sans-serif"}}>{error}</p>
        <div style={{display:"flex",gap:12,justifyContent:"center"}}>
          <button onClick={()=>{
            intentionalLeaveRef.current=false;
            isReconnectingRef.current=false;
            autoReconnectCountRef.current=0;
            setError(null);setToken(null);setWsUrl(null);
            connect(isPrivileged?"start_session":"join");
          }} style={{
            padding:"10px 24px",borderRadius:24,background:"#8ab4f8",border:"none",
            color:"#202124",fontSize:14,cursor:"pointer",fontWeight:600,
            fontFamily:"'Google Sans',sans-serif",
          }}>Try again</button>
          <button onClick={onLeave} style={{
            padding:"10px 24px",borderRadius:24,background:"rgba(255,255,255,.08)",
            border:"1px solid rgba(255,255,255,.15)",color:"#e8eaed",fontSize:14,
            cursor:"pointer",fontFamily:"'Google Sans',sans-serif",
          }}>Go back</button>
        </div>
      </div>
    </div>
  );
  return(
    <div data-classroom-root style={{height:"100dvh",display:"flex",flexDirection:"column",background:"#000",overflow:"hidden"}}>
      <style>{CSS}</style>
      {token&&wsUrl&&(
        // key={roomKey} forces a full remount whenever autoReconnect bumps the key,
        // ensuring LiveKit starts with a fresh connection and token.
        <LiveKitRoom key={roomKey} serverUrl={wsUrl} token={token} connect={phase==="live"} audio={false} video={false}
          // Weak links need longer than the 15s defaults to finish the websocket + ICE handshake;
          // timing out early just triggers the heavy full-rebuild reconnect path.
          connectOptions={{websocketTimeout:30_000,peerConnectionTimeout:45_000}}
          options={{
            adaptiveStream:{pixelDensity:isMobile?1:"screen"},
            dynacast:true,
            disconnectOnPageLeave:false,
            // BUG FIX — "reconnects too much on low network":
            // No reconnectPolicy was set, so LiveKit fell back to its default
            // (~10 attempts, short backoff cap). That internal reconnect is
            // CHEAP — it resumes the existing peer connection / ICE without
            // touching local tracks or remote subscriptions. Once it's
            // exhausted, LiveKit fires Disconnected, and our own autoReconnect
            // below takes over with a FULL rebuild: new token, brand new Room,
            // re-subscribe every participant from scratch. That's expensive
            // and visible to the user — and on a flaky/low-bandwidth
            // connection the default budget ran out constantly, so this heavy
            // path was firing far more often than it should.
            // Giving LiveKit's own lightweight reconnect much more patience
            // means most low-network hiccups now resolve quietly without ever
            // reaching the app-level rebuild.
            reconnectPolicy:{
              nextRetryDelayInMs:(context:{retryCount:number;elapsedMs:number})=>{
                // CHANGED: only try the cheap in-place resume for ~4s. Waiting
                // 2 minutes here is what left users staring at "Checking
                // connection…" for ages. After 4s we let Disconnected fire so
                // autoReconnect rebuilds the room with a fresh token right away.
                // BUT only while the tab is visible. A minimized/hidden browser tab
                // has its network frozen by the phone; giving up after 4s there forces
                // a full room rebuild that tries to grab the mic while hidden (which
                // Chrome forbids) — that is what made "everything stop" on minimize.
                // While hidden, keep the old patient in-place resume (2 min).
                const hidden=typeof document!=="undefined"&&document.visibilityState!=="visible";
                if(context.elapsedMs>(hidden?120_000:4_000))return -1; // negative = give up, let Disconnected fire
                // Quick, cheap retries: 0, .3s, .6s, .9s, then 1s (gentler 1.5s→8s while hidden).
                if(hidden)return Math.min(500*Math.pow(1.5,context.retryCount),8_000);
                return Math.min(300*context.retryCount,1_000);
              },
            },
            audioCaptureDefaults:{
              echoCancellation:true,noiseSuppression:true,autoGainControl:true,
              sampleRate:48000,channelCount:1,
              // Chrome/Android: stronger voice-only isolation (cuts speaker bleed + room noise).
              ...({voiceIsolation:true} as any),
            },
            publishDefaults:{
              // BUG FIX — "students can't hear well" / dropped word-beginnings:
              // DTX (discontinuous transmission) skips sending audio packets
              // during silence to save bandwidth — but on resuming after a
              // pause, most Opus/WebRTC implementations take a moment to
              // switch back from comfort-noise to real encoding, clipping the
              // first syllable. That's a minor annoyance in casual chat; in a
              // Qur'an class where teachers deliberately pause between words
              // for tajweed correction, it can eat exactly the sound a
              // student needs to hear. Bandwidth savings aren't worth it here.
              audioPreset:{maxBitrate:isSlowLink()?32000:64000,priority:"high" as const}, // voice always wins the uplink over video; leaner on slow links. // mono voice at 64kbps has real headroom for the pronunciation detail (madd, ghunnah, makharij) that matters in recitation, still light on data
              dtx:false,  // was true — see note above
              red:true,   // redundant audio encoding — recovers from packet loss
              stopMicTrackOnMute:false,
              // Base (top) encoding layer — device-specific, see
              // videoQualityProfile above (PC: sharp/high-bitrate,
              // mobile: capped to protect mobile data plans).
              videoEncoding:videoQualityProfile.videoEncoding,
              backupCodec:true,
              // HEAT FIX: on phones publish H.264 so the phone's HARDWARE encoder is used
              // (VP8, the default, is software-encoded on most phones and runs the CPU hot).
              // backupCodec above keeps non-H.264 devices working. Flip USE_H264_ON_MOBILE to
              // false (top of this file) to revert in one line. PC/laptop is untouched.
              ...(isMobile&&USE_H264_ON_MOBILE?{videoCodec:"h264" as const}:{}),
              // Writing-friendly: if the encoder is stressed, drop frame-rate before resolution,
              // so a notebook / handwriting stays readable.
              ...({degradationPreference:"maintain-resolution"} as any),
              // SIMULCAST — this is the correct, LiveKit-native way to adapt
              // video quality to each viewer's network, replacing the old
              // approach of the sender repeatedly disabling/re-enabling their
              // own camera at a lower resolution whenever ANYONE's network
              // dipped. With simulcast, three layers are encoded and sent to
              // the server at once; the SFU hands each *viewer* whichever
              // layer suits their own connection, entirely server-side, with
              // no renegotiation and no visible freeze on the sender's end.
              // This is what actually fixes "hanging/delayed video" — the
              // old logic's setCameraEnabled(false)+setCameraEnabled(true)
              // cycles were themselves a source of stalls, since each one
              // renegotiates the peer connection.
              simulcast:true,
              videoSimulcastLayers:videoQualityProfile.simulcastLayers,
              // Screen share: ONE full-quality layer, no low simulcast layer. With the
              // default extra low layer + adaptiveStream, a viewer whose share tile is
              // small (PC screen on a phone) was handed the tiny layer: blurry, unreadable.
              screenShareEncoding:{maxBitrate:2_500_000,maxFramerate:15},
              screenShareSimulcastLayers:[],
            },
            videoCaptureDefaults:{
              // PC captures at a genuine 720p; mobile captures a bit lower
              // (960×540) since its top published layer is 480p anyway —
              // capturing far above what's ever actually encoded just burns
              // CPU/battery on the phone for no visible or data benefit.
              resolution:privilegedMobile?{width:960,height:540,frameRate:24}:lowDataProfile?{width:640,height:360,frameRate:20}:{width:1280,height:720,frameRate:isMobile?24:30},
              facingMode:"user",
              // Explicit ideal aspect ratio — without this, a phone's front
              // camera (which is very often natively 3:4 / 4:3, not 16:9)
              // gets forced into the requested 16:9 box by cropping the
              // image tighter than the sensor's real field of view. That
              // crop is what makes a phone's picture look "zoomed in" next
              // to a laptop webcam (which is natively 16:9 already) — the
              // person has to physically back away just to appear the same
              // size as they would on a desktop. Asking for 16:9 as an
              // "ideal" (not exact) lets the browser choose the closest
              // native mode instead of aggressively cropping every device
              // the same way.
              aspectRatio:16/9,
            } as any,
          }} style={{flex:1,display:"flex",flexDirection:"column",minHeight:0,position:"relative"}} data-lk-theme="default">
          {/* FIX ("waveform shows but no voice is heard", and vice versa): this used to be
              VolumeBooster — a hand-built Web Audio pipeline (GainNode + DynamicsCompressor +
              a manually-created <audio> element) routing every remote mic track. That pipeline
              could silently stop passing real audio (suspended AudioContext, a stale
              MediaStreamTrack reference after a reconnect, autoplay policy) while the in-tile
              waveform kept animating regardless — it's driven independently by LiveKit's own
              speaking-detection, not by this pipeline. RoomAudioRenderer is LiveKit's own
              battle-tested audio renderer — the exact same one GuestClassroom already uses
              with no reports of this bug — and re-attaches automatically on reconnects/track
              changes, so waveform and actual audio can no longer drift apart. */}
          <RoomAudioRenderer/>
          {/* SAFETY NET: browsers can silently block RoomAudioRenderer's <audio>
              elements from actually playing (autoplay policy) even though everything
              connected fine — the room shows "canPlaybackAudio: false" instead of
              throwing anywhere visible. When that happens NOBODY hears ANYBODY
              (exactly this symptom), while speaking waveforms keep animating since
              those come from LiveKit's audio-level detection, not from playback.
              StartAudio renders nothing when playback is already fine, and shows a
              single tap-to-enable banner the moment the room detects it's blocked —
              tapping it calls room.startAudio() and immediately unblocks every
              participant's audio, no reconnect needed. */}
          <div style={{position:"fixed",top:0,left:0,right:0,zIndex:9500,display:"flex",justifyContent:"center"}}>
            <StartAudio label="🔊 Tap to enable classroom audio"/>
          </div>
          <RoomToContextBridge />
          <PrivateChatListener/>
          <ChatPopupLayer sessionId={sessionId||""} onOpen={openChatFrom}/>
          {chatBanner&&!chatOpen&&(
            <div style={{position:"fixed",top:"calc(env(safe-area-inset-top, 0px) + 64px)",left:12,right:12,zIndex:70,display:"flex",justifyContent:"center",pointerEvents:"none"}}>
              <div onClick={()=>{setChatBanner(null);openChatFrom();}} style={{pointerEvents:"auto",maxWidth:420,width:"100%",display:"flex",alignItems:"flex-start",gap:10,padding:"10px 12px",borderRadius:14,background:"rgba(32,33,36,.94)",backdropFilter:"blur(10px)",border:"1px solid rgba(255,255,255,.12)",boxShadow:"0 8px 28px rgba(0,0,0,.5)",cursor:"pointer"}}>
                <span style={{fontSize:18,lineHeight:"22px"}}>💬</span>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:12,fontWeight:700,color:"#8ab4f8",fontFamily:"system-ui,sans-serif",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{chatBanner.name}</div>
                  <div style={{fontSize:13,color:"#fff",fontFamily:"system-ui,sans-serif",lineHeight:1.35,display:"-webkit-box",WebkitLineClamp:3,WebkitBoxOrient:"vertical" as any,overflow:"hidden",wordBreak:"break-word"}}>{chatBanner.text}</div>
                </div>
                <button onClick={(e:any)=>{e.stopPropagation();setChatBanner(null);}} aria-label="Dismiss" style={{width:26,height:26,flexShrink:0,borderRadius:"50%",border:"none",background:"rgba(255,255,255,.14)",color:"#fff",cursor:"pointer",fontSize:14,lineHeight:1,display:"flex",alignItems:"center",justifyContent:"center"}}>✕</button>
              </div>
            </div>
          )}
          <MediaAutoPublish lobbyMic={lobbyMic} lobbyCam={lobbyCam} isFirstJoin={isFirstJoinPropRef.current}/>
          <MicKeepAliveFromContext />
          <WbSyncBridge wbOpen={wbOpen} isTeacher={isPrivileged}/>
          <AdminMuteListener isPrivileged={isPrivileged}/>
          <JoinRequestBanner sessionId={sessionId} isPrivileged={isPrivileged}/>
          {isPrivileged&&isHifdhReviewRoom(subject)&&<HifdhReviewPanel subject={subject}/>}
          {isPrivileged&&!isHifdhReviewRoom(subject)&&<HifdhMemorizationPanel subject={subject}/>}
          {!isPrivileged&&!isHifdhReviewRoom(subject)&&<HifdhFollowAlong subject={subject}/>}
          <GroupReciteAutoMic active={groupRecite} isPrivileged={isPrivileged}/>
          {/* onDisconnected wired to autoReconnect — handles Android tab suspension */}
          <ReconnectMonitor
            onReconnecting={()=>setReconnecting(true)}
            onReconnected={()=>{
              // New room is fully connected — clear overlay and reset all reconnect state
              isReconnectingRef.current=false;
              autoReconnectCountRef.current=0;
              setReconnecting(false);
            }}
            onDisconnected={autoReconnect}
            onRemoved={handleRemovedByHost}
          />
          {/* Feature 2: audio-only bridge — applies camera/bitrate changes from outside LiveKitRoom */}
          <AudioOnlyBridge active={audioOnlyActive}/>
          {/* "Allow student video" OFF → a student's camera is switched off and kept off */}
          <CameraLockBridge locked={!isPrivileged&&!sessionSettings.allow_video}/>
          <ProfileSyncBridge/>
          {/* Feature 5: heartbeat — proactively degrades video before LiveKit detects drop */}
          <HeartbeatBridge sessionId={sessionId} active={phase==="live"}/>
          {/* Feature 9: data channel queue flusher — replays queued messages on reconnect */}
          <DataQueueFlusher roomRef={roomRef}/>
          <JoinLeaveOverlay/>
          <RoomDataListener onWbOpen={()=>setWbOpen(true)} onWbClose={()=>setWbOpen(false)} strokesBuffer={wbBuffer} onMatOpen={mat=>{setMatOpen(mat);setMatMinimized(false);}} onMatClose={()=>{setMatOpen(null);setMatMinimized(false);}} onWbAllowWrite={allow=>setCanStudentWrite(allow)} onRecAllowed={allow=>setCanStudentRec(allow)} onEmojiReact={(emoji:string,sender:string)=>addFloatingEmoji(emoji,sender)} onGroupRecite={handleGroupReciteFromTeacher} onHandRaise={handleHandRaise} onAdminMuteAll={()=>{}} onForceAudioOnly={(active:boolean)=>{setForcedAudioOnly(active);setAudioOnlyActive(active);}} onAllowVideo={onAllowVideoMsg}
            onClassEnded={!isPrivileged?()=>setPhase("ended"):undefined} roomRef={roomRef}/>{/* FIX BUG 10: pass roomRef */}
          {reconnecting&&!overlayExpired&&<ReconnectingOverlay attempt={autoReconnectCountRef.current}/>}
          {reconnecting&&overlayExpired&&(
            <div style={{position:"fixed",top:"calc(env(safe-area-inset-top, 0px) + 62px)",left:0,right:0,zIndex:9400,display:"flex",justifyContent:"center",pointerEvents:"none"}}>
              <div style={{display:"flex",alignItems:"center",gap:8,padding:"6px 14px",borderRadius:20,background:"rgba(217,119,6,.95)",color:"#fff",fontSize:12,fontWeight:600,fontFamily:"'Google Sans',sans-serif",boxShadow:"0 4px 16px rgba(0,0,0,.4)"}}>
                <span style={{width:10,height:10,borderRadius:"50%",border:"2px solid rgba(255,255,255,.6)",borderTopColor:"#fff",animation:"cv-spin .7s linear infinite"}}/>
                Reconnecting… still trying
              </div>
            </div>
          )}
          {/* ══ FEATURE 4: CONNECTION STATE BANNER — shown during LiveKit's own reconnect ══ */}
          <ConnectionStateBanner/>
          <NetworkGuard isPrivileged={isPrivileged} audioOnlyActive={audioOnlyActive} forcedAudioOnly={forcedAudioOnly} onAutoAudioOnly={(on:boolean)=>setAudioOnlyActive(on)}/>
          {/* ══ GOOGLE MEET STYLE TOP BAR ══ */}
          <div data-class-header="1" style={{
            position:"fixed",top:0,left:0,right:0,zIndex:60,
            height:56,boxSizing:"content-box",
            transform:uiHidden?"translateY(-100%)":"translateY(0)",
            opacity:uiHidden?0:1,
            pointerEvents:uiHidden?"none":"auto",
            transition:"transform .28s cubic-bezier(.4,0,.2,1), opacity .22s ease",
            willChange:"transform",
            background:"#14161b",borderBottom:"1px solid rgba(255,255,255,.1)",
            display:"flex",alignItems:"center",justifyContent:"space-between",
            padding:"env(safe-area-inset-top, 0px) 14px 0 16px",
            gap:8,
          }}>
            {/* LEFT — LIVE badge + subject title only (keeps mobile header uncluttered) */}
            <div style={{display:"flex",alignItems:"center",gap:6,flex:1,minWidth:0,overflow:"hidden",maxWidth:"calc(50% - 46px)"}}>
              <div className="gm-badge" style={{background:"rgba(234,67,53,.12)",border:"1px solid rgba(234,67,53,.25)",color:"#fff",flexShrink:1,minWidth:0,maxWidth:"100%"}}>
                <span style={{width:7,height:7,borderRadius:"50%",background:"#ea4335",display:"inline-block",flexShrink:0,animation:"pip-pulse 1.8s ease-in-out infinite"}}/>
                <span style={{minWidth:0,fontSize:13,fontWeight:500,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",fontFamily:"'Google Sans',sans-serif"}}>{subject.title}</span>
              </div>
              {/* Raised-hand count — admin only, compact dot badge */}
              {isPrivileged&&raisedHands.length>0&&(
                <div className="gm-badge" style={{background:"rgba(251,191,36,.12)",border:"1px solid rgba(251,191,36,.3)",color:"#fbbf24",flexShrink:0,padding:"3px 8px"}}>
                  <span style={{fontSize:12,animation:"hand-bounce 1.2s ease-in-out infinite"}}>✋</span>
                  <span style={{fontSize:11,fontWeight:600,fontFamily:"'Google Sans',sans-serif"}}>{raisedHands.length}</span>
                </div>
              )}
              {/* Feature 15: Recording indicator — students only (admin/teacher
                  already sees recording state via RecController on the right).
                  Lives in the header row itself now instead of a floating
                  banner over the content area, which used to sit on top of
                  the materials bar / video tiles and block them. */}
              {!isPrivileged&&teacherIsRecording&&(
                <div className="gm-badge" style={{background:"rgba(239,68,68,.14)",border:"1px solid rgba(239,68,68,.35)",color:"#fca5a5",flexShrink:0,padding:"3px 8px"}} title={t("This class is being recorded","يتم تسجيل هذه الحصة")}>
                  <Circle style={{width:7,height:7,fill:"#ef4444",color:"#ef4444",animation:"rec-pulse 1s ease-in-out infinite",flexShrink:0}}/>
                  <span style={{fontSize:11,fontWeight:700,fontFamily:"'Google Sans',sans-serif",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:isMobile?"22vw":"none"}}>{t("Recording","تسجيل")}</span>
                </div>
              )}
            </div>

            {/* CENTRE — session timer, dead-centre of the bar */}
            <div style={{position:"absolute",left:"50%",top:"env(safe-area-inset-top, 0px)",height:56,transform:"translateX(-50%)",display:"flex",alignItems:"center",pointerEvents:"none"}}>
              <div style={{display:"flex",alignItems:"center",gap:5,background:"rgba(0,0,0,.35)",border:"1px solid rgba(255,255,255,.12)",borderRadius:20,padding:"4px 10px",flexShrink:0}}>
                <Circle style={{width:6,height:6,fill:"#ea4335",color:"#ea4335",animation:"rec-pulse 1.4s ease-in-out infinite",flexShrink:0}}/>
                <span style={{fontSize:13,fontWeight:500,fontVariantNumeric:"tabular-nums",fontFamily:"'Google Sans',sans-serif",color:"rgba(255,255,255,.9)"}}><ClassClock durationRef={durationRef}/></span>
              </div>
            </div>

            {/* RIGHT — timer · network(degraded only) · participants · [layout] · [rec admin] */}
            <div style={{display:"flex",alignItems:"center",gap:4,flexShrink:0}}>
              {/* Network indicator moved to per-participant name pills (ParticipantSignalIcon)
                  so you can see everyone's connection at a glance instead of just your own
                  in the header — removed from here per request. Adaptive video/bitrate
                  engine is kept alive headlessly since it doesn't just feed this badge. */}
              <NetworkAdaptiveEngine/>
              <CameraUnmirrorEngine/>
              {/* Participant count */}
              <ParticipantCountBadge participantCountRef={participantCountRef} onOpen={()=>{setPartOpen(v=>!v);setPartPanelOpen(v=>!v);}}/>
              {/* Student "Record" control — moved here (beside the participant
                  badge) from a separate floating pill below the header, and
                  out of the ⋮ More menu before that. Only shown once
                  admin/teacher has granted "Allow Students to Record"; reuses
                  the same toggleStuRecordTop() state SubjectMaterialsPanel
                  already drives, so both stay in sync instead of tracking
                  two independent recordings. */}
              {!isPrivileged&&canStudentRec&&(
                <div className="gm-badge" onClick={toggleStuRecordTop} style={{
                  cursor:"pointer",flexShrink:0,
                  background: stuRec?"rgba(239,68,68,.9)":"rgba(239,68,68,.14)",
                  border:"1px solid rgba(239,68,68,.4)",
                  color: stuRec?"#fff":"#fca5a5",
                }}>
                  <Circle style={{width:8,height:8,fill: stuRec?"#fff":"#ef4444",color: stuRec?"#fff":"#ef4444",animation: stuRec?"rec-pulse 1s ease-in-out infinite":undefined}}/>
                  <span style={{fontSize:11,fontWeight:700,fontFamily:"'Google Sans',sans-serif"}}>{stuRec?"REC":"Record"}</span>
                </div>
              )}
              {/* Layout switcher — desktop only */}
              {!isMobile&&<LayoutSwitcher layout={layout} onChange={setLayout}/>}
              {/* RecController — admin only, icon-only on mobile */}
              {isPrivileged&&<RecController sessionId={sessionId} subjectId={subject.id} userEmail={user?.email||""} getRoom={()=>roomRef.current} onSavingChange={setSavingRec} stopRecRef={recStopRef} isRecordingRef={isRecordingRef}/>}
            </div>
          </div>
          {/* Content — material panels render here so footer always stays visible */}
          <div style={{flex:1,display:"flex",minHeight:0,overflow:"hidden",marginTop:"var(--cls-top, calc(56px + env(safe-area-inset-top, 0px)))",marginBottom:"var(--cls-bottom, calc(76px + env(safe-area-inset-bottom, 0px)))"}}>
            <div style={{flex:1,position:"relative",minWidth:0}}>
              <ClassroomAdminContext.Provider value={{isPrivileged,sessionId}}>
                {/* Full-bleed stage: the header (top) and control bar (bottom)
                    are their own `position:fixed` overlays with a
                    transparent-fading gradient background, designed to float
                    on top of the video rather than box it in — so the video
                    itself now runs edge-to-edge with no inset/rounding. */}
                <div style={{position:"absolute",inset:0}} onClick={onStageTap}>
                  <div style={{width:"100%",height:"100%",overflow:"hidden",background:"#000"}}>
                    <VideoGrid layout={layout} isMobile={isMobile} spotlightId={spotlightId}/>
                  </div>
                </div>
                <ParticipantDrawer isMobile={isMobile} dim={uiHidden}/>
              </ClassroomAdminContext.Provider>
              <FloatingEmojiLayer emojis={floatingEmojis}/>
              <RaisedHandsOverlay hands={raisedHands}/>
              {/* Materials panel — keep mounted when it has minimized PiP materials */}
              {(matPanelOpen||matPanelHasPip)&&<SubjectMaterialsPanel subjectId={subject.id} subject={subject} sessionId={sessionId} onClose={()=>setMatPanelOpen(false)} canStudentRec={canStudentRec} isPrivileged={isPrivileged} isAdmin={isAdmin} stuRec={stuRec} onToggleStuRecord={toggleStuRecordTop} onOpenMatsChange={(has:boolean)=>setMatPanelHasPip(has)} panelRef={matPanelRef}/>}
              {/* Every student sees whatever the teacher opens, immediately —
                  no "Subject Materials" click needed. Always mounted for the
                  whole live session, entirely independent of the panel above. */}
              {!isPrivileged&&phase==="live"&&<TeacherMaterialFollower sessionId={sessionId}/>}
              {/* Teacher-shared material viewer — absolute inside content */}
              {matOpen&&(
                <div style={{position:"absolute",inset:0,zIndex:55,display:matMinimized?"none":"block"}}>
                  <MatViewerInlineBridge material={matOpen} isPrivileged={isPrivileged} onMinimize={()=>setMatMinimized(true)} onClose={()=>{setMatOpen(null);setMatMinimized(false);}}/>
                </div>
              )}
              {/* Floating PiP for the teacher-shared material when minimized */}
              {matOpen&&matMinimized&&(
                <div
                  onPointerDown={onMatPipPointerDown}
                  onPointerMove={onMatPipPointerMove}
                  onPointerUp={onMatPipPointerUp}
                  onClick={()=>setMatMinimized(false)}
                  style={{
                    position:"absolute", left:matPipPos.x, top:matPipPos.y, zIndex:60,
                    width:54, height:54, borderRadius:"50%",
                    background:"linear-gradient(135deg,#0a7a5e,#1a73e8)",
                    boxShadow:"0 4px 20px rgba(0,0,0,.5)",
                    display:"flex", alignItems:"center", justifyContent:"center",
                    cursor:"grab", userSelect:"none", touchAction:"none",
                    border:"2px solid rgba(255,255,255,.2)",
                  }}
                  title={matOpen.title||"Open material"}
                >
                  <span style={{fontSize:20}}>{MAT_TYPE_ICON[matOpen.material_type||"document"]||"📄"}</span>
                </div>
              )}
              {/* Feature 11: Live class file panel (in-class materials) */}
              {liveFilesOpen&&createPortal(
                <div style={{position:"fixed",inset:0,zIndex:9000,background:"rgba(0,0,0,.6)",display:"flex",alignItems:"flex-end",justifyContent:"flex-end"}} onClick={()=>setLiveFilesOpen(false)}>
                  <div onClick={e=>e.stopPropagation()} style={{width:"min(420px,100vw)",height:"min(85vh,700px)",background:"#fff",borderRadius:"20px 0 0 0",overflow:"auto",display:"flex",flexDirection:"column",boxShadow:"-8px 0 40px rgba(0,0,0,.4)"}}>
                    <div style={{display:"flex",alignItems:"center",padding:"14px 16px",borderBottom:"1px solid #e5e7eb",flexShrink:0,background:"#1B4332"}}>
                      <span style={{flex:1,fontSize:14,fontWeight:700,color:"#fff"}}>📂 Class Materials</span>
                      <button onClick={()=>setLiveFilesOpen(false)} style={{background:"rgba(255,255,255,.15)",border:"none",color:"#fff",borderRadius:8,width:28,height:28,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}><X style={{width:14,height:14}}/></button>
                    </div>
                    <div style={{flex:1,overflow:"auto",padding:12}}><LiveClassFilePanel subjectId={subject.id}/></div>
                  </div>
                </div>,document.body
              )}
              {/* Feature 3: Desktop participants panel */}
              {partPanelOpen&&!isMobile&&createPortal(
                <div style={{position:"fixed",top:56,right:0,bottom:80,width:300,background:"#2D2E30",borderLeft:"1px solid rgba(255,255,255,.08)",zIndex:800,display:"flex",flexDirection:"column",animation:"slide-right .2s ease",overflow:"hidden"}}>
                  <div style={{display:"flex",alignItems:"center",padding:"12px 16px",borderBottom:"1px solid rgba(255,255,255,.07)",flexShrink:0}}>
                    <span style={{flex:1,fontSize:13,fontWeight:700,color:"#e8eaed",display:"flex",alignItems:"center",gap:6}}><Users style={{width:14,height:14}}/> Participants</span>
                    <button onClick={()=>setPartPanelOpen(false)} style={{background:"rgba(255,255,255,.08)",border:"none",color:"rgba(255,255,255,.6)",borderRadius:8,width:26,height:26,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}><X style={{width:12,height:12}}/></button>
                  </div>
                  <div style={{flex:1,overflow:"auto"}}>
                    <ClassParticipants sessionId={sessionId||""} isPrivileged={isPrivileged} room={roomRef.current} onSpotlight={(id:string)=>setSpotlightId(prev=>prev===id?null:id)} spotlightId={spotlightId}/>
                  </div>
                </div>,document.body
              )}
              {/* Feature 13: Hand queue panel */}
              {handQueueOpen&&isPrivileged&&createPortal(
                <div style={{position:"fixed",top:56,left:0,width:280,background:"#2D2E30",borderRight:"1px solid rgba(255,255,255,.08)",zIndex:800,maxHeight:"70vh",display:"flex",flexDirection:"column",animation:"slide-right .2s ease",borderRadius:"0 0 16px 0",overflow:"hidden"}}>
                  <div style={{display:"flex",alignItems:"center",padding:"12px 16px",borderBottom:"1px solid rgba(255,255,255,.07)",flexShrink:0}}>
                    <span style={{flex:1,fontSize:13,fontWeight:700,color:"#fbbf24",display:"flex",alignItems:"center",gap:6}}>✋ Hand Queue <span style={{fontSize:11,color:"rgba(255,255,255,.4)",fontWeight:400}}>({raisedHands.length})</span></span>
                    <button onClick={()=>setHandQueueOpen(false)} style={{background:"none",border:"none",color:"rgba(255,255,255,.4)",cursor:"pointer"}}><X style={{width:12,height:12}}/></button>
                  </div>
                  <div style={{flex:1,overflowY:"auto",padding:8}}>
                    {raisedHands.length===0&&<p style={{fontSize:12,color:"rgba(255,255,255,.3)",textAlign:"center",padding:"24px 16px"}}>No hands raised</p>}
                    {[...raisedHands].sort((a,b)=>a.raisedAt-b.raisedAt).map((h,i)=>(
                      <div key={h.identity} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",borderRadius:10,background:"rgba(251,191,36,.06)",border:"1px solid rgba(251,191,36,.12)",marginBottom:6}}>
                        <span style={{fontSize:13,fontWeight:700,color:"#fbbf24",width:18,flexShrink:0}}>{i+1}</span>
                        <span style={{animation:"hand-bounce 1.2s ease-in-out infinite",fontSize:16}}>✋</span>
                        <span style={{flex:1,fontSize:13,color:"#e8eaed",fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{h.name}</span>
                        <div style={{display:"flex",gap:4}}>
                          <button onClick={()=>{setSpotlightId(h.identity);setLayout("spotlight");setHandQueueOpen(false);toast({title:`📌 Spotlighting ${h.name}`,duration:2000});}}
                            style={{background:"rgba(26,115,232,.2)",border:"1px solid rgba(26,115,232,.3)",color:"#8ab4f8",borderRadius:6,padding:"3px 8px",fontSize:10,cursor:"pointer",fontWeight:700}}>
                            Call On
                          </button>
                          <button onClick={()=>{
                            try{roomRef.current?.localParticipant?.publishData(new TextEncoder().encode(JSON.stringify({type:"force_mute",target:h.identity})),{reliable:true});}catch{}
                            try{roomRef.current?.localParticipant?.publishData(new TextEncoder().encode(JSON.stringify({type:"hand_raise",identity:h.identity,name:h.name,raised:false})),{reliable:true});}catch{}
                            if(sessionId)supabase.from("class_participants").update({hand_raised:false,hand_raised_at:null}).eq("session_id",sessionId).eq("student_id",h.identity).then(()=>{},()=>{});
                            handleHandRaise(h.identity,h.name,false);
                          }}
                            style={{background:"rgba(255,255,255,.06)",border:"1px solid rgba(255,255,255,.1)",color:"rgba(255,255,255,.4)",borderRadius:6,padding:"3px 6px",fontSize:10,cursor:"pointer"}}>
                            ✕
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>,document.body
              )}
              {/* Feature 5: Live attendance panel */}
              {attendanceOpen&&isPrivileged&&createPortal(
                <div style={{position:"fixed",top:56,left:0,width:280,background:"#2D2E30",borderRight:"1px solid rgba(255,255,255,.08)",zIndex:800,maxHeight:"70vh",display:"flex",flexDirection:"column",animation:"slide-right .2s ease",borderRadius:"0 0 16px 0",overflow:"hidden"}}>
                  <div style={{display:"flex",alignItems:"center",padding:"12px 16px",borderBottom:"1px solid rgba(255,255,255,.07)",flexShrink:0}}>
                    <span style={{flex:1,fontSize:13,fontWeight:700,color:"#34d399",display:"flex",alignItems:"center",gap:6}}><UserCheck style={{width:14,height:14}}/> Live Attendance <span style={{fontSize:11,color:"rgba(255,255,255,.4)",fontWeight:400}}>({liveAttendees.length})</span></span>
                    <button onClick={()=>setAttendanceOpen(false)} style={{background:"none",border:"none",color:"rgba(255,255,255,.4)",cursor:"pointer"}}><X style={{width:12,height:12}}/></button>
                  </div>
                  <div style={{flex:1,overflowY:"auto",padding:8}}>
                    {liveAttendees.length===0&&<p style={{fontSize:12,color:"rgba(255,255,255,.3)",textAlign:"center",padding:"24px 16px"}}>Waiting for students…</p>}
                    {liveAttendees.map((a:any,i:number)=>(
                      <div key={a.student_id||i} style={{display:"flex",alignItems:"center",gap:8,padding:"9px 12px",borderRadius:8,marginBottom:4,background:"rgba(255,255,255,.04)"}}>
                        <div style={{width:8,height:8,borderRadius:"50%",background:"#22c55e",flexShrink:0,animation:"rec-pulse 2s ease-in-out infinite"}}/>
                        <span style={{flex:1,fontSize:13,color:"#e8eaed",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{a.profiles?.full_name||"Student"}</span>
                        <span style={{fontSize:10,color:"rgba(255,255,255,.3)"}}>{a.joined_at?new Date(a.joined_at).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):""}</span>
                      </div>
                    ))}
                  </div>
                </div>,document.body
              )}
              {/* Feature 10: Timer overlay */}
              {timerOpen&&isPrivileged&&createPortal(
                <div style={{position:"fixed",inset:0,zIndex:9500,background:"rgba(0,0,0,.6)",display:"flex",alignItems:"center",justifyContent:"center"}} onClick={()=>setTimerOpen(false)}>
                  <div onClick={e=>e.stopPropagation()} style={{background:"#2D2E30",borderRadius:20,padding:"28px 24px",width:300,boxShadow:"0 24px 60px rgba(0,0,0,.7)",border:"1px solid rgba(255,255,255,.1)",animation:"fade-in .18s ease",textAlign:"center"}}>
                    <div style={{fontSize:36,marginBottom:8}}>⏱️</div>
                    <p style={{fontSize:16,fontWeight:700,color:"#e8eaed",marginBottom:16}}>Countdown Timer</p>
                    {timerRunning?(
                      <>
                        <div style={{fontSize:48,fontWeight:900,color:"#fbbf24",fontVariantNumeric:"tabular-nums",letterSpacing:-2,marginBottom:20}}>{fmtTimer(timerSeconds)}</div>
                        <button onClick={stopTimer} style={{width:"100%",padding:"12px",borderRadius:12,border:"none",background:"#ef4444",color:"#fff",fontSize:14,fontWeight:700,cursor:"pointer"}}>Stop Timer</button>
                      </>
                    ):(
                      <>
                        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:16,justifyContent:"center"}}>
                          <input value={timerInput} onChange={e=>setTimerInput(e.target.value)} type="number" min="1" max="60"
                            style={{width:80,padding:"10px",borderRadius:10,border:"1px solid rgba(255,255,255,.15)",background:"rgba(255,255,255,.08)",color:"#fff",fontSize:20,fontWeight:700,textAlign:"center",outline:"none"}}/>
                          <span style={{fontSize:14,color:"rgba(255,255,255,.6)"}}>minutes</span>
                        </div>
                        <button onClick={startTimer} style={{width:"100%",padding:"12px",borderRadius:12,border:"none",background:"linear-gradient(135deg,#0a7c68,#064E3B)",color:"#fff",fontSize:14,fontWeight:700,cursor:"pointer"}}>▶ Start Timer</button>
                      </>
                    )}
                  </div>
                </div>,document.body
              )}
              {/* Feature 17: Session summary modal */}
              {summaryOpen&&sessionSummary&&createPortal(
                <div style={{position:"fixed",inset:0,zIndex:9600,background:"rgba(0,0,0,.75)",display:"flex",alignItems:"center",justifyContent:"center",padding:16}} onClick={()=>setSummaryOpen(false)}>
                  <div onClick={e=>e.stopPropagation()} style={{background:"#1e2535",borderRadius:20,padding:"28px 24px",maxWidth:440,width:"100%",maxHeight:"85vh",overflowY:"auto",boxShadow:"0 24px 60px rgba(0,0,0,.7)",border:"1px solid rgba(255,255,255,.1)",animation:"fade-in .18s ease"}}>
                    <div style={{textAlign:"center",marginBottom:20}}>
                      <div style={{fontSize:36,marginBottom:8}}>📋</div>
                      <p style={{fontSize:17,fontWeight:800,color:"#e8eaed",margin:0}}>Session Summary</p>
                      <p style={{fontSize:12,color:"rgba(255,255,255,.4)",margin:"4px 0 0"}}>{subject?.title}</p>
                    </div>
                    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>
                      {[["⏱️","Duration",sessionSummary.duration],["👥","Attendees",sessionSummary.attendeeCount],["💬","Messages",sessionSummary.messageCount],["📊","Polls",sessionSummary.pollCount]].map(([ic,lb,val])=>(
                        <div key={lb as string} style={{background:"rgba(255,255,255,.05)",borderRadius:12,padding:"12px 16px",textAlign:"center"}}>
                          <div style={{fontSize:22,marginBottom:4}}>{ic}</div>
                          <div style={{fontSize:20,fontWeight:800,color:"#e8eaed"}}>{val}</div>
                          <div style={{fontSize:11,color:"rgba(255,255,255,.4)"}}>{lb}</div>
                        </div>
                      ))}
                    </div>
                    {sessionSummary.highlights?.length>0&&(
                      <div style={{marginBottom:14}}>
                        <p style={{fontSize:12,fontWeight:700,color:"rgba(255,255,255,.5)",marginBottom:8,textTransform:"uppercase",letterSpacing:.5}}>📌 Pinned Messages</p>
                        {sessionSummary.highlights.map((m:any)=>(
                          <div key={m.id} style={{background:"rgba(201,168,76,.08)",border:"1px solid rgba(201,168,76,.15)",borderRadius:10,padding:"8px 12px",marginBottom:6,fontSize:13,color:"#e8eaed"}}>{m.message}</div>
                        ))}
                      </div>
                    )}
                    {sessionSummary.attendees?.length>0&&(
                      <div>
                        <p style={{fontSize:12,fontWeight:700,color:"rgba(255,255,255,.5)",marginBottom:8,textTransform:"uppercase",letterSpacing:.5}}>✅ Who Attended</p>
                        <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                          {sessionSummary.attendees.map((a:any)=>(
                            <span key={a.student_id} style={{fontSize:11,background:"rgba(34,197,94,.1)",color:"#4ade80",border:"1px solid rgba(34,197,94,.2)",borderRadius:20,padding:"3px 10px"}}>{a.profiles?.full_name||"Student"}</span>
                          ))}
                        </div>
                      </div>
                    )}
                    <button onClick={()=>setSummaryOpen(false)} style={{width:"100%",marginTop:20,padding:"12px",borderRadius:12,border:"1px solid rgba(255,255,255,.1)",background:"rgba(255,255,255,.06)",color:"rgba(255,255,255,.7)",fontSize:14,fontWeight:600,cursor:"pointer"}}>Close</button>
                  </div>
                </div>,document.body
              )}
            </div>
            {chatOpen&&!isMobile&&(
              <div className="gm-sidebar">
                <div style={{display:"flex",borderBottom:"1px solid rgba(255,255,255,.07)",flexShrink:0,background:"rgba(32,33,36,.97)"}}>
                  {[["chat","💬","Chat"],["polls","📊","Polls"]].filter(([k])=>k!=="chat"||chatAllowed).map(([k,ic,lb])=>(
                    <button key={k} onClick={()=>{setSideTab(k as any);if(k==="chat")setChatUnread(0);}} style={{
                      flex:1,padding:"14px 4px",background:"none",border:"none",
                      color:sideTab===k?"#8ab4f8":"rgba(255,255,255,.45)",
                      fontSize:13,fontWeight:sideTab===k?600:400,
                      borderBottom:sideTab===k?"2px solid #8ab4f8":"2px solid transparent",
                      cursor:"pointer",fontFamily:"'Google Sans',sans-serif",transition:"color .15s",
                    }}>{ic} {lb}</button>
                  ))}
                  <button onClick={()=>setChatOpen(false)} style={{background:"none",border:"none",color:"rgba(255,255,255,.3)",cursor:"pointer",padding:"0 14px",flexShrink:0}}>
                    <X style={{width:16,height:16}}/>
                  </button>
                </div>
                <div style={{flex:1,overflow:"hidden"}}>{sideTab==="chat"&&chatAllowed?<ClassChatPanel enablePrivate sessionId={sessionId||""} sessionStartedAt={sessionInfo?.started_at??sessionInfo?.actual_start_time}/>:<ClassPolls sessionId={sessionId||""}/>}</div>
              </div>
            )}
          </div>
          {wbOpen&&<WhiteboardBridge onClose={()=>setWbOpen(false)} isTeacher={isPrivileged} initialStrokes={wbBuffer.current} subjectId={subject.id} canStudentWrite={canStudentWrite}/>}
          {groupReciteDialog&&!isPrivileged&&(
            <GroupRecitePermDialog
              onAccept={()=>{setGroupReciteDialog(false);}}
              onDecline={()=>{setGroupReciteDialog(false);setGroupRecite(false);}}
            />
          )}
          {/* RESET TO GUESTROOM DEFAULT — same control bar, same props shape GuestClassroom
              already uses. There is only ONE three-dot button now — ClassControls' own —
              the classroom-only extras (whiteboard, materials, group recite, hand queue,
              attendance, audio-only) are passed in as extraMenuItems and render inside that
              same dropdown, right below its built-in options. */}
          <ClassControls
            sessionId={sessionId||""}
            isHostOverride={isPrivileged}
            onToggleChat={()=>{setChatOpen(v=>!v);if(!chatOpen)setChatUnread(0);}}
            onToggleParticipants={()=>{setPartOpen(v=>!v);setPartPanelOpen(v=>!v);}}
            onEndClass={()=>setShowEnd(true)}
            onLeaveClass={()=>setShowLeaveConfirm(true)}
            chatUnread={chatUnread+privateUnread}
            collapsed={uiHidden}
            onLaunchPoll={()=>{setChatOpen(true);setSideTab("polls");}}
            onLaunchQuiz={()=>setQuizOpen(true)}
            camLocked={forcedAudioOnly||(!isPrivileged&&!sessionSettings.allow_video)}
            camLockedReason={forcedAudioOnly?"audio_only":"no_video"}
            handRaiseEnabled={sessionSettings.hand_raise_enabled}
            extraMenuItems={
              <>
                <DropdownMenuItem onClick={()=>setWbOpen(v=>!v)} style={{margin:"0 4px",borderRadius:8}}>
                  <PenTool style={{width:16,height:16,marginRight:8}}/> {wbOpen?"Close Whiteboard":"Whiteboard"}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={toggleMatPanel} style={{margin:"0 4px",borderRadius:8}}>
                  <BookOpen style={{width:16,height:16,marginRight:8}}/> {matPanelOpen?"Close Materials":"Subject Materials"}
                </DropdownMenuItem>
                {isPrivileged&&(
                  <DropdownMenuItem onClick={()=>handleGroupRecite(roomRef.current)} style={{margin:"0 4px",borderRadius:8}}>
                    <Radio style={{width:16,height:16,marginRight:8}}/> {groupRecite?"Stop Group Recite":"Start Group Recite"}
                  </DropdownMenuItem>
                )}
                {isPrivileged&&(
                  <DropdownMenuItem onClick={()=>setHandQueueOpen(v=>!v)} style={{margin:"0 4px",borderRadius:8}}>
                    <Bell style={{width:16,height:16,marginRight:8}}/> Hand Queue
                  </DropdownMenuItem>
                )}
                {isPrivileged?(
                  // Admin/teacher: this is now a room-wide broadcast — turning it on
                  // forces every participant's camera off and greys out their Cam
                  // button until the admin turns it off again from right here.
                  <DropdownMenuItem onClick={toggleForcedAudioOnly} style={{margin:"0 4px",borderRadius:8}}>
                    <Zap style={{width:16,height:16,marginRight:8}}/> {forcedAudioOnly?"Exit Audio-Only Mode (All)":"Audio-Only Mode (All)"}
                  </DropdownMenuItem>
                ):(
                  // Student: personal bandwidth-saving toggle for their own camera only —
                  // disabled while the teacher has forced it room-wide.
                  <DropdownMenuItem
                    onClick={()=>{ if(!forcedAudioOnly) setAudioOnlyActive(v=>!v); }}
                    style={{margin:"0 4px",borderRadius:8,opacity:forcedAudioOnly?0.5:1,cursor:forcedAudioOnly?"not-allowed":"pointer"}}
                  >
                    <Zap style={{width:16,height:16,marginRight:8}}/> {forcedAudioOnly?"Audio-Only Mode (set by teacher)":audioOnlyActive?"Exit Audio-Only Mode":"Audio-Only Mode"}
                  </DropdownMenuItem>
                )}
                {isPrivileged&&(
                  // Live class setting: switch student cameras on/off for everyone. OFF → students see a
                  // dimmed, unavailable camera button and their cameras are turned off.
                  <DropdownMenuItem onClick={toggleStudentVideo} style={{margin:"0 4px",borderRadius:8,display:"flex",alignItems:"center"}}>
                    {sessionSettings.allow_video?<Video style={{width:16,height:16,marginRight:8}}/>:<VideoOff style={{width:16,height:16,marginRight:8}}/>}
                    <span style={{flex:1}}>Allow Student Video</span>
                    <span aria-hidden style={{width:34,height:19,borderRadius:10,marginLeft:10,position:"relative",flexShrink:0,background:sessionSettings.allow_video?"#34d399":"rgba(255,255,255,.2)",transition:"background .15s"}}>
                      <span style={{position:"absolute",top:2,left:sessionSettings.allow_video?17:2,width:15,height:15,borderRadius:"50%",background:"#fff",transition:"left .15s"}}/>
                    </span>
                  </DropdownMenuItem>
                )}
                {isPrivileged&&(
                  <DropdownMenuItem onClick={()=>handlePermChange("rec",!canStudentRec,roomRef.current)} style={{margin:"0 4px",borderRadius:8}}>
                    <Video style={{width:16,height:16,marginRight:8}}/> {canStudentRec?"Disallow Student Recording":"Allow Students to Record"}
                  </DropdownMenuItem>
                )}
              </>
            }
          />
          {isMobile&&chatOpen&&(<MobileChatSheet accent={TEAL} tabs={([["chat","💬","Chat"],["polls","📊","Polls"]] as [string,string,string][]).filter(([k])=>k!=="chat"||chatAllowed)} active={sideTab} onTab={k=>{setSideTab(k as any);if(k==="chat")setChatUnread(0);}} onClose={()=>setChatOpen(false)}>{sideTab==="chat"&&chatAllowed?<ClassChatPanel enablePrivate sessionId={sessionId||""} sessionStartedAt={sessionInfo?.started_at??sessionInfo?.actual_start_time}/>:<ClassPolls sessionId={sessionId||""}/>}</MobileChatSheet>)}
          {isMobile&&partOpen&&(<div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.65)",zIndex:50}} onClick={()=>setPartOpen(false)}><div style={{position:"absolute",bottom:BAR_H,left:0,right:0,background:"#13181f",borderRadius:"22px 22px 0 0",maxHeight:"65vh",overflow:"auto"}} onClick={e=>e.stopPropagation()}><div style={{width:40,height:4,borderRadius:2,background:"rgba(255,255,255,.18)",margin:"12px auto 6px"}}/><ClassParticipants sessionId={sessionId||""}/></div></div>)}
          {/* FIX BUG 2: LiveQuizOverlay now controlled by quizOpen state — was permanently disabled with hardcoded isOpen={false} */}
          <LiveQuizOverlay sessionId={sessionId||""} isOpen={quizOpen} onClose={()=>setQuizOpen(false)}/>
        </LiveKitRoom>
      )}
      {matPicker&&<MatPickerBridge subjectId={subject.id} onShare={async(mat:any,room:any)=>{
        // Show for the teacher immediately — they have direct storage access
        setMatOpen(mat);
        setMatMinimized(false);
        setMatPicker(false);
        // Pre-resolve the URL before broadcasting so every student receives a
        // ready https:// URL. InClassMaterialViewer skips getSignedUrl entirely
        // and mounts the PDFViewer (or other media) with zero network delay.
        let broadcastMat=mat;
        try{
          const rawUrl=mat.file_url||mat.url||"";
          if(rawUrl&&!rawUrl.startsWith("http")){
            const isSupabaseStorage=rawUrl.includes(".supabase.co/storage");
            if(isSupabaseStorage){
              const match=rawUrl.match(/\/storage\/v1\/object\/(?:public\/)?([^/?]+)\/(.+?)(\?.*)?$/);
              if(match){
                const [,bucketName,storagePath]=match;
                const {data:pub}=supabase.storage.from(bucketName).getPublicUrl(storagePath);
                if(pub?.publicUrl){
                  try{
                    const r=await fetch(pub.publicUrl,{method:"HEAD",signal:AbortSignal.timeout(4000)});
                    if(r.ok||r.status===304){broadcastMat={...mat,file_url:pub.publicUrl};}
                    else{throw new Error("not public");}
                  }catch{
                    const {data:signed}=await supabase.storage.from(bucketName).createSignedUrl(storagePath,604800);
                    if(signed?.signedUrl)broadcastMat={...mat,file_url:signed.signedUrl};
                  }
                }
              }
            }else{
              const signed=await getSignedUrl(rawUrl);
              if(signed)broadcastMat={...mat,file_url:signed};
            }
          }
        }catch{}
        // A lesson stored in the database: send only its id — students load the content themselves, so the live message stays small.
        if(isInlineLessonRow(mat))broadcastMat={...mat,content:null,inline_lesson:true};
        try{room?.localParticipant?.publishData(new TextEncoder().encode(JSON.stringify({type:"mat_open",material:broadcastMat})),{reliable:true});}catch{}
      }} onClose={()=>setMatPicker(false)}/>}
      {showEnd&&!minimized&&createPortal(
        <div style={{position:"fixed",inset:0,zIndex:9500,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,.6)",backdropFilter:"blur(8px)"}} onClick={()=>setShowEnd(false)}>
          <div style={{background:"#2D2E30",borderRadius:20,padding:"32px 28px 24px",width:"100%",maxWidth:380,margin:"0 16px",boxShadow:"0 24px 64px rgba(0,0,0,.7)",border:"1px solid rgba(255,255,255,.08)",animation:"fade-in .18s ease"}} onClick={e=>e.stopPropagation()}>
            <div style={{width:56,height:56,borderRadius:"50%",background:"rgba(234,67,53,.12)",border:"1px solid rgba(234,67,53,.2)",display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 18px"}}>
              <Phone style={{width:22,height:22,color:"#ea4335",transform:"rotate(135deg)"}}/>
            </div>
            <h2 style={{textAlign:"center",fontSize:18,fontWeight:500,color:"#e8eaed",marginBottom:8,fontFamily:"'Google Sans Display',sans-serif"}}>{t("End class for everyone?","إنهاء الحصة للجميع؟")}</h2>
            <p style={{textAlign:"center",fontSize:14,color:"rgba(255,255,255,.45)",marginBottom:28,lineHeight:1.6,fontFamily:"'Google Sans',sans-serif"}}>{t("This will disconnect all participants.","سيتم قطع الاتصال عن جميع المشاركين.")}</p>
            <div style={{display:"flex",flexDirection:"column",gap:10}}>
              <button onClick={endSession} style={{width:"100%",padding:"13px",borderRadius:24,border:"none",background:"#ea4335",color:"#fff",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"'Google Sans',sans-serif",boxShadow:"0 2px 12px rgba(234,67,53,.4)"}}>{t("End for all","إنهاء للجميع")}</button>
              <button onClick={()=>{setShowEnd(false);leaveSession();}} style={{width:"100%",padding:"12px",borderRadius:24,border:"1px solid rgba(255,255,255,.15)",background:"rgba(255,255,255,.06)",color:"rgba(255,255,255,.8)",fontSize:14,fontWeight:400,cursor:"pointer",fontFamily:"'Google Sans',sans-serif"}}>{t("Leave but keep open","غادر لكن أبقِ الحصة")}</button>
              <button onClick={()=>setShowEnd(false)} style={{width:"100%",padding:"12px",borderRadius:24,border:"none",background:"transparent",color:"rgba(255,255,255,.4)",fontSize:14,cursor:"pointer",fontFamily:"'Google Sans',sans-serif"}}>{t("Cancel","إلغاء")}</button>
            </div>
          </div>
        </div>,
        document.body
      )}
      {showLeaveConfirm&&!minimized&&createPortal(
        <div style={{position:"fixed",inset:0,zIndex:9500,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,.6)",backdropFilter:"blur(8px)"}} onClick={()=>setShowLeaveConfirm(false)}>
          <div style={{background:"#2D2E30",borderRadius:20,padding:"32px 28px 24px",width:"100%",maxWidth:380,margin:"0 16px",boxShadow:"0 24px 64px rgba(0,0,0,.7)",border:"1px solid rgba(255,255,255,.08)",animation:"fade-in .18s ease"}} onClick={e=>e.stopPropagation()}>
            <div style={{width:56,height:56,borderRadius:"50%",background:"rgba(234,67,53,.12)",border:"1px solid rgba(234,67,53,.2)",display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 18px"}}>
              <Phone style={{width:22,height:22,color:"#ea4335",transform:"rotate(135deg)"}}/>
            </div>
            <h2 style={{textAlign:"center",fontSize:18,fontWeight:500,color:"#e8eaed",marginBottom:8,fontFamily:"'Google Sans Display',sans-serif"}}>{t("Leave the class?","مغادرة الحصة؟")}</h2>
            <p style={{textAlign:"center",fontSize:14,color:"rgba(255,255,255,.45)",marginBottom:28,lineHeight:1.6,fontFamily:"'Google Sans',sans-serif"}}>{t("You can rejoin later while the class is still live.","يمكنك الانضمام مرة أخرى لاحقًا ما دامت الحصة مباشرة.")}{isPrivileged&&isRecordingRef.current?" "+t("Your recording will pause and continue when you rejoin.","سيتوقف التسجيل مؤقتًا ويستمر عند عودتك."):""}</p>
            <div style={{display:"flex",flexDirection:"column",gap:10}}>
              <button onClick={()=>{setShowLeaveConfirm(false);leaveSession();}} style={{width:"100%",padding:"13px",borderRadius:24,border:"none",background:"#ea4335",color:"#fff",fontSize:14,fontWeight:600,cursor:"pointer",fontFamily:"'Google Sans',sans-serif",boxShadow:"0 2px 12px rgba(234,67,53,.4)"}}>{t("Leave class","مغادرة الحصة")}</button>
              <button onClick={()=>setShowLeaveConfirm(false)} style={{width:"100%",padding:"12px",borderRadius:24,border:"1px solid rgba(255,255,255,.15)",background:"rgba(255,255,255,.06)",color:"rgba(255,255,255,.8)",fontSize:14,fontWeight:400,cursor:"pointer",fontFamily:"'Google Sans',sans-serif"}}>{t("Cancel","إلغاء")}</button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
};

const MatPickerBridge=({subjectId,onShare,onClose}:any)=>{const room=useRoomContext();return<MaterialPicker subjectId={subjectId} onShare={(mat:any)=>onShare(mat,room)} onClose={onClose}/>;};
// MatViewerBridge (legacy — kept for backwards compat, now delegates to InClassMaterialViewer)
const MatViewerBridge=({material,isTeacher,onClose}:any)=>{const room=useRoomContext();return<InClassMaterialViewer material={material} isTeacher={isTeacher} onClose={()=>onClose(room)}/>;};
// MatViewerInlineBridge — renders INSIDE LiveKitRoom (has room context) so mat_close can be broadcast
const MatViewerInlineBridge=({material,isPrivileged,onClose,onMinimize}:any)=>{
  const room=useRoomContext();
  return<InClassMaterialViewer material={material} isTeacher={isPrivileged} onMinimize={onMinimize} onClose={()=>{
    onClose();
    if(isPrivileged){try{room?.localParticipant?.publishData(new TextEncoder().encode(JSON.stringify({type:"mat_close"})),{reliable:true});}catch{}}
  }}/>;
};

export default ClassroomView;

